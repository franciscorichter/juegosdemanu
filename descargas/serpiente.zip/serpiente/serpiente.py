"""
SERPIENTE - un snake de Manu
=============================
Come manzanas para crecer. No choques con las paredes, los obstaculos, tu cola
ni la otra serpiente. Cada 5 manzanas cambia el nivel (y los obstaculos).

Modos: 1 jugador (con record guardado) o 2 jugadores en el mismo teclado.

Controles (se cambian en controles.txt):
    Jugador 1: flechas     Jugador 2: W A S D
    ESPACIO empezar / seguir    R reiniciar    ESC salir

Power-ups (aparecen de vez en cuando, duran poco):
    R  rayo      vas mas rapido (y cada manzana vale doble)
    T  tortuga   vas mas lento (mas facil de controlar)
    E  estrella  puntos x3
    X  tijeras   tu cola se acorta 3
    F  fantasma  atraviesas paredes y obstaculos (sales por el otro lado)

Los niveles se dibujan en niveles.txt ('.' libre, '#' obstaculo).
"""

import os
import random
import sys

import pygame

# ------------------------------------------------------------------ AJUSTES
COLS, FILAS = 32, 24          # tamano del tablero en casillas
CELDA = 25                    # pixeles por casilla
ALTO_HUD = 50                 # la franja de arriba con los puntos
FPS = 60
FRAMES_POR_PASO = 8           # cada cuantos frames avanza la serpiente (menos = mas rapido)
MANZANAS_POR_NIVEL = 5
LARGO_INICIAL = 4
CADA_CUANTO_POWERUP = 6       # segundos entre power-ups
DURA_POWERUP_EN_SUELO = 8     # segundos que se queda esperando
DURA_EFECTO = 7               # segundos que dura el efecto
PUNTOS_MANZANA = 10

POWERUPS = {
    "rayo":     {"letra": "R", "color": (255, 230, 60),  "texto": "¡Rayo! Rapido y doble puntos"},
    "tortuga":  {"letra": "T", "color": (90, 200, 120),  "texto": "Tortuga: mas lento"},
    "estrella": {"letra": "E", "color": (255, 150, 220), "texto": "¡Estrella! Puntos x3"},
    "tijeras":  {"letra": "X", "color": (200, 200, 210), "texto": "Tijeras: cola mas corta"},
    "fantasma": {"letra": "F", "color": (170, 170, 255), "texto": "¡Fantasma! Atraviesas paredes"},
}

# Colores
FONDO = (24, 26, 32)
FONDO_2 = (28, 30, 37)
OBSTACULO = (110, 100, 120)
MANZANA = (230, 60, 60)
BLANCO = (245, 245, 245)
GRIS = (150, 150, 160)
COLORES_JUGADOR = {1: (80, 220, 100), 2: (80, 160, 255)}

# ------------------------------------------------------------------ CONTROLES
CONTROLES_DEFECTO = {
    "j1_arriba": "up", "j1_abajo": "down", "j1_izquierda": "left", "j1_derecha": "right",
    "j2_arriba": "w", "j2_abajo": "s", "j2_izquierda": "a", "j2_derecha": "d",
    "continuar": "space", "reiniciar": "r", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una linea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(CARPETA, "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


CARPETA = os.path.dirname(os.path.abspath(__file__))
TECLA = {}   # se llena en main(), despues de pygame.init()


# ------------------------------------------------------------------ NIVELES Y RECORD
def cargar_niveles():
    """Lee niveles.txt: cada dibujo es un nivel; devuelve una lista de conjuntos de obstaculos."""
    niveles = []
    actual = []
    try:
        with open(os.path.join(CARPETA, "niveles.txt"), encoding="utf-8") as f:
            lineas = f.read().splitlines() + [""]
    except OSError:
        lineas = [""]
    for linea in lineas:
        if linea.startswith("#") and any(c not in "#." for c in linea):
            continue                      # comentario (tiene letras, no es un dibujo)
        if linea.strip():
            actual.append(linea)
        elif actual:
            obst = {(x, y) for y, fila in enumerate(actual) for x, c in enumerate(fila) if c == "#"}
            niveles.append(obst)
            actual = []
    return niveles or [set()]


def leer_record():
    try:
        with open(os.path.join(CARPETA, "record.txt"), encoding="utf-8") as f:
            return int(f.read().strip() or 0)
    except (OSError, ValueError):
        return 0


def guardar_record(puntos):
    try:
        with open(os.path.join(CARPETA, "record.txt"), "w", encoding="utf-8") as f:
            f.write(str(puntos))
    except OSError:
        pass


# ------------------------------------------------------------------ SERPIENTE
class Serpiente:
    def __init__(self, numero, cabeza, direccion):
        self.numero = numero
        self.color = COLORES_JUGADOR[numero]
        self.dir = direccion              # (dx, dy)
        self.proxima_dir = direccion
        x, y = cabeza
        # el cuerpo es una lista de casillas; la primera es la cabeza
        self.cuerpo = [(x - direccion[0] * i, y - direccion[1] * i) for i in range(LARGO_INICIAL)]
        self.crecer = 0
        self.puntos = 0
        self.viva = True
        self.efectos = {}                 # nombre -> frames que le quedan
        self.contador = 0                 # frames hasta el proximo paso

    @property
    def cabeza(self):
        return self.cuerpo[0]

    def girar(self, nueva):
        # no puedes darte vuelta 180 grados de golpe (te comerias tu cuello)
        if (nueva[0] + self.dir[0], nueva[1] + self.dir[1]) != (0, 0):
            self.proxima_dir = nueva

    def frames_por_paso(self):
        if "rayo" in self.efectos:
            return max(3, FRAMES_POR_PASO - 3)
        if "tortuga" in self.efectos:
            return FRAMES_POR_PASO + 5
        return FRAMES_POR_PASO

    def multiplicador(self):
        m = 1
        if "rayo" in self.efectos:
            m *= 2
        if "estrella" in self.efectos:
            m *= 3
        return m

    def aplicar(self, nombre):
        if nombre == "tijeras":
            self.cuerpo = self.cuerpo[:max(3, len(self.cuerpo) - 3)]
        else:
            self.efectos[nombre] = DURA_EFECTO * FPS

    def bajar_efectos(self):
        for k in list(self.efectos):
            self.efectos[k] -= 1
            if self.efectos[k] <= 0:
                del self.efectos[k]

    def dibujar(self, sup, desplazamiento):
        n = len(self.cuerpo)
        for i, (x, y) in enumerate(self.cuerpo):
            r = pygame.Rect(x * CELDA + 1, y * CELDA + 1 + desplazamiento, CELDA - 2, CELDA - 2)
            if "fantasma" in self.efectos:
                color = tuple(min(255, c + 60) for c in self.color)
            else:
                # la cola se va oscureciendo
                f = 1 - 0.5 * i / max(1, n)
                color = tuple(int(c * f) for c in self.color)
            pygame.draw.rect(sup, color, r, border_radius=6 if i == 0 else 4)
            if i == 0:
                # ojos mirando hacia donde va
                dx, dy = self.dir
                cx, cy = r.center
                for lado in (-1, 1):
                    ox = cx + dx * 6 + (dy * lado) * 5
                    oy = cy + dy * 6 + (dx * lado) * 5
                    pygame.draw.circle(sup, (20, 20, 20), (int(ox), int(oy)), 3)


# ------------------------------------------------------------------ JUEGO
class Juego:
    def __init__(self):
        self.fuente = pygame.font.SysFont(None, 28)
        self.fuente_chica = pygame.font.SysFont(None, 22)
        self.fuente_grande = pygame.font.SysFont(None, 64)
        self.niveles = cargar_niveles()
        self.record = leer_record()
        self.jugadores = 1
        self.victorias = {1: 0, 2: 0}
        self.ancho = COLS * CELDA
        self.alto = FILAS * CELDA + ALTO_HUD
        self.estado = "menu"      # "menu", "jugando", "fin"
        self.mensaje_fin = ""
        self.nuevo_record = False
        self.aviso = ""
        self.aviso_hasta = 0
        self.tiempo = 0

    # ---- preparar partida
    def empezar(self):
        self.nivel = 1
        self.manzanas_comidas = 0
        # cada uno sale en una fila distinta, para no chocar de frente al empezar
        fila1 = FILAS // 2 if self.jugadores == 1 else FILAS // 3
        self.serpientes = [Serpiente(1, (COLS // 4, fila1), (1, 0))]
        if self.jugadores == 2:
            self.serpientes.append(Serpiente(2, (COLS * 3 // 4, FILAS * 2 // 3), (-1, 0)))
        self.cargar_nivel()
        self.manzana = self.casilla_libre()
        self.powerup = None            # (casilla, nombre, frames que le quedan)
        self.proximo_powerup = CADA_CUANTO_POWERUP * FPS
        self.estado = "jugando"
        self.nuevo_record = False
        self.tiempo = 0
        self.avisar(f"Nivel {self.nivel}")

    def cargar_nivel(self):
        obst = self.niveles[(self.nivel - 1) % len(self.niveles)]
        ocupadas = {c for s in self.serpientes for c in s.cuerpo}
        # un obstaculo no puede aparecer encima de una serpiente ni justo delante de su cabeza
        for s in self.serpientes:
            for i in range(1, 4):
                ocupadas.add((s.cabeza[0] + s.dir[0] * i, s.cabeza[1] + s.dir[1] * i))
        self.obstaculos = {c for c in obst if c not in ocupadas}

    def casilla_libre(self):
        ocupadas = set(self.obstaculos)
        for s in self.serpientes:
            ocupadas.update(s.cuerpo)
        if getattr(self, "manzana", None):
            ocupadas.add(self.manzana)
        if getattr(self, "powerup", None):
            ocupadas.add(self.powerup[0])
        libres = [(x, y) for y in range(FILAS) for x in range(COLS) if (x, y) not in ocupadas]
        return random.choice(libres) if libres else (0, 0)

    def avisar(self, texto, segundos=2):
        self.aviso = texto
        self.aviso_hasta = self.tiempo + segundos * FPS

    # ---- entradas
    def tecla(self, key):
        if key == TECLA["reiniciar"]:
            self.estado = "menu"
            return
        if self.estado == "menu":
            if key in (pygame.K_1, pygame.K_2):
                self.jugadores = 1 if key == pygame.K_1 else 2
                self.empezar()
            elif key in (TECLA["j1_arriba"], TECLA["j1_abajo"], TECLA["j2_arriba"], TECLA["j2_abajo"]):
                self.jugadores = 2 if self.jugadores == 1 else 1
            elif key == TECLA["continuar"]:
                self.empezar()
        elif self.estado == "fin":
            if key == TECLA["continuar"]:
                self.empezar()
        elif self.estado == "jugando":
            s1 = self.serpientes[0]
            if key == TECLA["j1_arriba"]:
                s1.girar((0, -1))
            elif key == TECLA["j1_abajo"]:
                s1.girar((0, 1))
            elif key == TECLA["j1_izquierda"]:
                s1.girar((-1, 0))
            elif key == TECLA["j1_derecha"]:
                s1.girar((1, 0))
            if self.jugadores == 2:
                s2 = self.serpientes[1]
                if key == TECLA["j2_arriba"]:
                    s2.girar((0, -1))
                elif key == TECLA["j2_abajo"]:
                    s2.girar((0, 1))
                elif key == TECLA["j2_izquierda"]:
                    s2.girar((-1, 0))
                elif key == TECLA["j2_derecha"]:
                    s2.girar((1, 0))

    # ---- logica
    def actualizar(self):
        if self.estado != "jugando":
            return
        self.tiempo += 1

        # power-ups: aparecen y desaparecen
        if self.powerup:
            self.powerup[2] -= 1
            if self.powerup[2] <= 0:
                self.powerup = None
        else:
            self.proximo_powerup -= 1
            if self.proximo_powerup <= 0:
                nombre = random.choice(list(POWERUPS))
                self.powerup = [self.casilla_libre(), nombre, DURA_POWERUP_EN_SUELO * FPS]
                self.proximo_powerup = CADA_CUANTO_POWERUP * FPS

        # cada serpiente avanza a su ritmo
        for s in self.serpientes:
            s.bajar_efectos()
            s.contador += 1
            if s.contador >= s.frames_por_paso():
                s.contador = 0
                self.paso(s)

        # choques entre serpientes (se revisan despues de que todas se movieron)
        for s in self.serpientes:
            for otra in self.serpientes:
                if otra is s:
                    continue
                if s.cabeza in otra.cuerpo:
                    s.viva = False
            if s.cabeza in s.cuerpo[1:]:
                s.viva = False

        muertas = [s for s in self.serpientes if not s.viva]
        if muertas:
            self.terminar(muertas)

    def paso(self, s):
        """La serpiente avanza una casilla."""
        s.dir = s.proxima_dir
        x, y = s.cabeza
        nx, ny = x + s.dir[0], y + s.dir[1]
        fantasma = "fantasma" in s.efectos

        # paredes: chocas, o si eres fantasma sales por el otro lado
        if not (0 <= nx < COLS and 0 <= ny < FILAS):
            if fantasma:
                nx %= COLS
                ny %= FILAS
            else:
                s.viva = False
                return
        if (nx, ny) in self.obstaculos and not fantasma:
            s.viva = False
            return

        s.cuerpo.insert(0, (nx, ny))
        if s.crecer > 0:
            s.crecer -= 1
        else:
            s.cuerpo.pop()

        # ¿comio la manzana?
        if (nx, ny) == self.manzana:
            s.crecer += 1
            s.puntos += PUNTOS_MANZANA * s.multiplicador()
            self.manzanas_comidas += 1
            self.manzana = self.casilla_libre()
            if self.manzanas_comidas % MANZANAS_POR_NIVEL == 0:
                self.nivel += 1
                self.cargar_nivel()
                self.avisar(f"¡Nivel {self.nivel}!")

        # ¿agarro un power-up?
        if self.powerup and (nx, ny) == self.powerup[0]:
            nombre = self.powerup[1]
            s.aplicar(nombre)
            self.avisar(f"J{s.numero}: {POWERUPS[nombre]['texto']}")
            self.powerup = None

    def terminar(self, muertas):
        self.estado = "fin"
        if self.jugadores == 1:
            p = self.serpientes[0].puntos
            self.mensaje_fin = f"Perdiste con {p} puntos"
            if p > self.record:
                self.record = p
                self.nuevo_record = True
                guardar_record(p)
        else:
            if len(muertas) == 2:
                self.mensaje_fin = "¡Empate! Chocaron a la vez"
            else:
                ganador = 2 if muertas[0].numero == 1 else 1
                self.victorias[ganador] += 1
                self.mensaje_fin = f"¡Gana el Jugador {ganador}!"

    # ---- dibujo
    def dibujar(self, pantalla):
        if self.estado == "menu":
            self.dibujar_menu(pantalla)
            return
        pantalla.fill(FONDO)
        d = ALTO_HUD
        # tablero a cuadros
        for y in range(FILAS):
            for x in range(COLS):
                if (x + y) % 2:
                    pygame.draw.rect(pantalla, FONDO_2, (x * CELDA, y * CELDA + d, CELDA, CELDA))
        for (x, y) in self.obstaculos:
            pygame.draw.rect(pantalla, OBSTACULO, (x * CELDA + 1, y * CELDA + 1 + d, CELDA - 2, CELDA - 2), border_radius=3)
        # manzana
        mx, my = self.manzana
        cx, cy = mx * CELDA + CELDA // 2, my * CELDA + CELDA // 2 + d
        pygame.draw.circle(pantalla, MANZANA, (cx, cy), CELDA // 2 - 3)
        pygame.draw.line(pantalla, (90, 60, 30), (cx, cy - 8), (cx + 3, cy - 13), 3)
        # power-up (parpadea cuando esta por irse)
        if self.powerup and (self.powerup[2] > 2 * FPS or self.powerup[2] // 8 % 2 == 0):
            (px, py), nombre, _ = self.powerup
            info = POWERUPS[nombre]
            cx, cy = px * CELDA + CELDA // 2, py * CELDA + CELDA // 2 + d
            pygame.draw.circle(pantalla, info["color"], (cx, cy), CELDA // 2 - 2)
            self.texto(pantalla, info["letra"], self.fuente_chica, (20, 20, 30), (cx, cy), centrado=True)
        for s in self.serpientes:
            s.dibujar(pantalla, d)
        self.dibujar_hud(pantalla)
        if self.estado == "fin":
            self.dibujar_fin(pantalla)

    def dibujar_hud(self, pantalla):
        pygame.draw.rect(pantalla, (14, 15, 20), (0, 0, self.ancho, ALTO_HUD))
        s1 = self.serpientes[0]
        self.texto(pantalla, f"J1: {s1.puntos}", self.fuente, COLORES_JUGADOR[1], (12, 8))
        self.texto(pantalla, self.efectos_texto(s1), self.fuente_chica, GRIS, (12, 30))
        if self.jugadores == 2:
            s2 = self.serpientes[1]
            self.texto(pantalla, f"J2: {s2.puntos}", self.fuente, COLORES_JUGADOR[2], (self.ancho - 12, 8), derecha=True)
            self.texto(pantalla, self.efectos_texto(s2), self.fuente_chica, GRIS, (self.ancho - 12, 30), derecha=True)
            marcador = f"Victorias  J1 {self.victorias[1]} - {self.victorias[2]} J2"
        else:
            marcador = f"Record: {self.record}"
            self.texto(pantalla, marcador, self.fuente, (255, 220, 90), (self.ancho - 12, 8), derecha=True)
            marcador = ""
        centro = f"Nivel {self.nivel}   Manzanas: {self.manzanas_comidas}"
        self.texto(pantalla, centro, self.fuente, BLANCO, (self.ancho // 2, 16), centrado=True)
        if marcador:
            self.texto(pantalla, marcador, self.fuente_chica, (255, 220, 90), (self.ancho // 2, 38), centrado=True)
        elif self.tiempo < self.aviso_hasta:
            self.texto(pantalla, self.aviso, self.fuente_chica, (255, 240, 150), (self.ancho // 2, 38), centrado=True)
        if marcador and self.tiempo < self.aviso_hasta:
            self.texto(pantalla, self.aviso, self.fuente_chica, (255, 240, 150), (self.ancho // 2, ALTO_HUD + 12), centrado=True)

    def efectos_texto(self, s):
        partes = [f"{POWERUPS[k]['letra']} {v // FPS + 1}s" for k, v in s.efectos.items()]
        return "  ".join(partes)

    def dibujar_menu(self, pantalla):
        pantalla.fill(FONDO)
        cx, cy = self.ancho // 2, self.alto // 2
        self.texto(pantalla, "SERPIENTE", self.fuente_grande, COLORES_JUGADOR[1], (cx, cy - 140), centrado=True)
        for n, y in ((1, cy - 50), (2, cy)):
            elegido = self.jugadores == n
            color = BLANCO if elegido else GRIS
            nombre = "1 jugador  (flechas)" if n == 1 else "2 jugadores  (flechas y WASD)"
            self.texto(pantalla, f"{'> ' if elegido else '   '}{n}. {nombre}", self.fuente, color, (cx, y), centrado=True)
        self.texto(pantalla, "Arriba/abajo o 1-2 para elegir, ESPACIO para empezar", self.fuente_chica, GRIS, (cx, cy + 60), centrado=True)
        self.texto(pantalla, f"Record de 1 jugador: {self.record}", self.fuente_chica, (255, 220, 90), (cx, cy + 90), centrado=True)
        y = cy + 130
        for nombre, info in POWERUPS.items():
            self.texto(pantalla, f"{info['letra']} = {info['texto']}", self.fuente_chica, info["color"], (cx, y), centrado=True)
            y += 20

    def dibujar_fin(self, pantalla):
        velo = pygame.Surface((self.ancho, self.alto), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 160))
        pantalla.blit(velo, (0, 0))
        cx, cy = self.ancho // 2, self.alto // 2
        self.texto(pantalla, self.mensaje_fin, self.fuente_grande if len(self.mensaje_fin) < 22 else self.fuente, BLANCO, (cx, cy - 30), centrado=True)
        if self.nuevo_record:
            self.texto(pantalla, "¡NUEVO RECORD!", self.fuente, (255, 220, 90), (cx, cy + 15), centrado=True)
        self.texto(pantalla, "ESPACIO para jugar de nuevo  -  R para el menu  -  ESC para salir",
                   self.fuente_chica, GRIS, (cx, cy + 50), centrado=True)

    def texto(self, pantalla, cadena, fuente, color, pos, centrado=False, derecha=False):
        img = fuente.render(cadena, True, color)
        r = img.get_rect()
        if centrado:
            r.center = pos
        elif derecha:
            r.topright = pos
        else:
            r.topleft = pos
        pantalla.blit(img, r)


# ------------------------------------------------------------------ ARRANQUE
def main():
    global TECLA
    pygame.init()
    TECLA = cargar_controles()
    juego = Juego()
    pantalla = pygame.display.set_mode((juego.ancho, juego.alto))
    pygame.display.set_caption("Serpiente")
    reloj = pygame.time.Clock()

    corriendo = True
    while corriendo:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == TECLA["salir"]:
                    corriendo = False
                else:
                    juego.tecla(evento.key)
        juego.actualizar()
        juego.dibujar(pantalla)
        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
