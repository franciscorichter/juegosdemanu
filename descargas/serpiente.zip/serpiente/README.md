# Serpiente

Un snake hecho en Python con pygame, para **1 o 2 jugadores** en el mismo teclado.
Come manzanas para crecer. No choques con las paredes, los obstáculos, tu cola ni
la otra serpiente. Cada 5 manzanas cambia el nivel (y los obstáculos).

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 serpiente.py

En Windows: `python serpiente.py`. En Linux/Mac también sirve `./jugar.sh`.

- En el menú eliges **1 jugador** o **2 jugadores** (1-2 o arriba/abajo, ESPACIO para empezar).
- **Jugador 1** (verde): flechas · **Jugador 2** (azul): W A S D.
- **ESPACIO** vuelve a jugar · **R** vuelve al menú · **ESC** cierra.
- Con 1 jugador se guarda tu **récord** en `record.txt`. Con 2, gana el que no choca (si chocan a la vez, empate).

## Power-ups

Aparecen de vez en cuando y se van si nadie los agarra:

| Letra | Nombre | Qué hace |
|---|---|---|
| R | Rayo | vas más rápido y cada manzana vale doble |
| T | Tortuga | vas más lento (más fácil de controlar) |
| E | Estrella | puntos x3 |
| X | Tijeras | tu cola se acorta 3 |
| F | Fantasma | atraviesas paredes y obstáculos (sales por el otro lado) |

## Haz tus propios niveles

Los niveles están en `niveles.txt`. Cada dibujo de 32 columnas por 24 filas es un
nivel: `.` libre, `#` obstáculo. Se separan con una línea vacía. Cuando se acaban,
vuelven a empezar. Agrega el tuyo al final y guarda.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo, para que el
jugador 2 use I J K L:

```
j2_arriba    = i
j2_abajo     = k
j2_izquierda = j
j2_derecha   = l
```

Nombres válidos: letras (`a`, `b`...), flechas (`up`, `down`, `left`, `right`),
`space`, `return`, `tab`, números (`1`, `2`...).
Si escribes una tecla que no existe, el juego te avisa en la terminal y usa la de siempre.

## Para cambiar cosas

Arriba de `serpiente.py` están los ajustes: `FRAMES_POR_PASO` (velocidad),
`MANZANAS_POR_NIVEL`, `CADA_CUANTO_POWERUP`, `DURA_EFECTO`, `PUNTOS_MANZANA`...
Cambia un número, guarda, y vuelve a correrlo.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
