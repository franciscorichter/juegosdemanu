"""
Salto — runner rítmico de Manu
==============================
Un cubo corre solo. Tú solo decides cuándo saltar. Si tocas un pincho
o chocas de frente con un bloque, explotas y vuelves a empezar al tiro.

Controles:
  ESPACIO  -> saltar (si lo dejas apretado, salta apenas toca el suelo)
  R        -> reiniciar el nivel
  ESC      -> salir
  Todas las teclas se cambian en controles.txt (al lado de este archivo).

Los niveles están en nivel1.txt y nivel2.txt (lista NIVELES abajo).
Se dibujan con letras, y la última fila es la que va pegada al piso:
  #  bloque (puedes pararte encima; de frente te mata)
  ^  pincho (te mata)
  .  nada
El nivel termina donde termina el texto.
"""

import math
import os
import random

import pygame

# ---------- Ajustes (cámbialos y prueba qué pasa) ----------
NIVELES = ["nivel1.txt", "nivel2.txt"]
TILE = 40
ANCHO, ALTO = 800, 420
FPS = 60
SUELO_Y = 340                   # dónde está el piso (parte de arriba)
CUBO_X = 200                    # el cubo siempre se dibuja aquí; el mundo se mueve

VELOCIDAD = 6                   # qué tan rápido corre el cubo
GRAVEDAD = 0.7
SALTO = -11.5
LADO = 34                       # tamaño del cubo
CUADROS_EXPLOSION = 25          # cuánto dura la explosión antes de reiniciar
CUADROS_FESTEJO = 120           # cuánto se muestra "nivel completo"

# ---------- Colores ----------
FONDO_INICIO = (20, 30, 80)     # el fondo cambia de este color...
FONDO_FIN = (90, 20, 80)        # ...a este, según cuánto llevas del nivel
PISO = (30, 30, 50)
LINEA_PISO = (120, 220, 255)
BLOQUE = (40, 40, 60)
BLOQUE_BORDE = (120, 220, 255)
PINCHO = (240, 240, 250)
PINCHO_BORDE = (0, 0, 0)
CUBO = (255, 200, 40)
CUBO_BORDE = (0, 0, 0)
CUBO_OJO = (0, 0, 0)
BARRA_FONDO = (0, 0, 0)
BARRA = (120, 220, 255)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
VERDE = (90, 230, 120)


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {"saltar": "space", "reiniciar": "r", "salir": "escape"}


def carpeta():
    return os.path.dirname(os.path.abspath(__file__))


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(carpeta(), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}      # se llena en main(), después de pygame.init()


# ---------- Cargar un nivel desde el texto ----------
def cargar_nivel(ruta):
    with open(os.path.join(carpeta(), ruta), encoding="utf-8") as f:
        filas = [linea.rstrip("\n") for linea in f if linea.strip("\n")]
    alto = len(filas)
    bloques, pinchos = [], []
    for fy, fila in enumerate(filas):
        y = SUELO_Y - (alto - fy) * TILE     # la última fila queda sobre el piso
        for fx, letra in enumerate(fila):
            x = fx * TILE
            if letra == "#":
                bloques.append(pygame.Rect(x, y, TILE, TILE))
            elif letra == "^":
                pinchos.append(pygame.Rect(x, y, TILE, TILE))
    largo = max(len(f) for f in filas) * TILE
    return dict(bloques=bloques, pinchos=pinchos, largo=largo)


# ---------- Partículas de la explosión ----------
class Particula:
    def __init__(self, x, y):
        self.x, self.y = x, y
        ang = random.uniform(0, 2 * math.pi)
        rap = random.uniform(2, 9)
        self.vx, self.vy = math.cos(ang) * rap, math.sin(ang) * rap - 3
        self.vida = random.randint(15, CUADROS_EXPLOSION)

    def actualizar(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.4
        self.vida -= 1

    def dibujar(self, pantalla, cam):
        tam = max(2, self.vida // 4)
        pygame.draw.rect(pantalla, CUBO, (int(self.x - cam), int(self.y), tam, tam))


# ---------- El cubo ----------
class Cubo:
    def __init__(self):
        self.rect = pygame.Rect(0, SUELO_Y - LADO, LADO, LADO)
        self.vel_y = 0
        self.en_suelo = True
        self.angulo = 0             # gira cuando está en el aire
        self.vivo = True

    def saltar(self):
        if self.en_suelo:
            self.vel_y = SALTO
            self.en_suelo = False

    def actualizar(self, bloques):
        # 1) avanza: si choca de frente con un bloque, muere
        self.rect.x += VELOCIDAD
        for b in bloques:
            if self.rect.colliderect(b):
                self.vivo = False
                return

        # 2) cae o sube
        self.vel_y += GRAVEDAD
        self.rect.y += int(self.vel_y)
        self.en_suelo = False
        for b in bloques:
            if self.rect.colliderect(b):
                if self.vel_y > 0 and self.rect.bottom - b.top < 20:
                    self.rect.bottom = b.top        # aterriza encima
                    self.vel_y = 0
                    self.en_suelo = True
                else:
                    self.vivo = False               # se pegó por abajo o de lado
                    return
        if self.rect.bottom >= SUELO_Y:
            self.rect.bottom = SUELO_Y
            self.vel_y = 0
            self.en_suelo = True

        # 3) gira en el aire, se endereza al aterrizar
        if self.en_suelo:
            self.angulo = 0
        else:
            self.angulo = (self.angulo + 6) % 360

    def toca_pincho(self, pinchos):
        caja = self.rect.inflate(-10, -10)
        for p in pinchos:
            punta = p.inflate(-16, -14).move(0, 7)  # solo la punta hace daño
            if caja.colliderect(punta):
                return True
        return False

    def dibujar(self, pantalla, cam):
        cx, cy = self.rect.centerx - cam, self.rect.centery
        a = math.radians(self.angulo)
        r = LADO / 2
        esquinas = []
        for ex, ey in ((-r, -r), (r, -r), (r, r), (-r, r)):
            esquinas.append((cx + ex * math.cos(a) - ey * math.sin(a),
                             cy + ex * math.sin(a) + ey * math.cos(a)))
        pygame.draw.polygon(pantalla, CUBO, esquinas)
        pygame.draw.polygon(pantalla, CUBO_BORDE, esquinas, 3)
        # ojos (dos cuadraditos que giran con el cubo)
        for ox in (-7, 5):
            ex, ey = ox, -5
            px = cx + ex * math.cos(a) - ey * math.sin(a)
            py = cy + ex * math.sin(a) + ey * math.cos(a)
            pygame.draw.rect(pantalla, CUBO_OJO, (px - 2, py - 2, 5, 5))


# ---------- Dibujos de ayuda ----------
def mezclar(c1, c2, t):
    """Un color entre c1 (t=0) y c2 (t=1)."""
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def dibujar_pincho(pantalla, r):
    puntos = [(r.left, r.bottom), (r.right, r.bottom), (r.centerx, r.top)]
    pygame.draw.polygon(pantalla, PINCHO, puntos)
    pygame.draw.polygon(pantalla, PINCHO_BORDE, puntos, 2)


def texto(pantalla, fuente, msg, y, color=BLANCO, x=None):
    cx = ANCHO // 2 if x is None else x
    s = fuente.render(msg, True, NEGRO)
    pantalla.blit(s, s.get_rect(center=(cx + 2, y + 2)))
    t = fuente.render(msg, True, color)
    pantalla.blit(t, t.get_rect(center=(cx, y)))


# ---------- El juego ----------
def nuevo_intento(indice, intentos):
    n = cargar_nivel(NIVELES[indice])
    return dict(indice=indice, bloques=n["bloques"], pinchos=n["pinchos"], largo=n["largo"],
                cubo=Cubo(), particulas=[], intentos=intentos,
                estado="jugando",       # "jugando", "explotando", "completo", "ganaste"
                timer=0)


def main():
    pygame.init()
    TECLA.update(cargar_controles())
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Salto — runner de Manu")
    reloj = pygame.time.Clock()
    fuente_grande = pygame.font.SysFont(None, 64)
    fuente_chica = pygame.font.SysFont(None, 30)

    j = nuevo_intento(0, 1)
    corriendo = True
    while corriendo:
        cubo = j["cubo"]

        # 1) Eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                corriendo = False
            elif e.type == pygame.KEYDOWN:
                if e.key == TECLA["salir"]:
                    corriendo = False
                elif e.key == TECLA["reiniciar"]:
                    if j["estado"] == "ganaste":
                        j = nuevo_intento(0, 1)
                    else:
                        j = nuevo_intento(j["indice"], 1)
                    cubo = j["cubo"]

        # 2) Mover
        if j["estado"] == "jugando":
            # saltar si la tecla está apretada (así puedes dejarla apretada)
            if pygame.key.get_pressed()[TECLA["saltar"]]:
                cubo.saltar()
            cubo.actualizar(j["bloques"])
            if cubo.vivo and cubo.toca_pincho(j["pinchos"]):
                cubo.vivo = False
            if not cubo.vivo:
                j["estado"] = "explotando"
                j["timer"] = CUADROS_EXPLOSION
                j["particulas"] = [Particula(cubo.rect.centerx, cubo.rect.centery) for _ in range(30)]
            elif cubo.rect.left >= j["largo"]:
                j["estado"] = "completo"
                j["timer"] = CUADROS_FESTEJO

        elif j["estado"] == "explotando":
            for p in j["particulas"]:
                p.actualizar()
            j["timer"] -= 1
            if j["timer"] <= 0:
                # reinicio instantáneo, sumando un intento
                j = nuevo_intento(j["indice"], j["intentos"] + 1)
                cubo = j["cubo"]

        elif j["estado"] == "completo":
            cubo.rect.x += VELOCIDAD        # sigue corriendo feliz
            j["timer"] -= 1
            if j["timer"] <= 0:
                if j["indice"] + 1 < len(NIVELES):
                    j = nuevo_intento(j["indice"] + 1, 1)
                    cubo = j["cubo"]
                else:
                    j["estado"] = "ganaste"

        # 3) Cámara y progreso
        cam = cubo.rect.x - CUBO_X
        progreso = max(0.0, min(1.0, cubo.rect.x / j["largo"]))

        # 4) Dibujar
        pantalla.fill(mezclar(FONDO_INICIO, FONDO_FIN, progreso))
        # rayitas del fondo que se mueven lento (parallax)
        for i in range(-1, ANCHO // 120 + 2):
            x = i * 120 - (cam // 3) % 120
            pygame.draw.line(pantalla, mezclar(FONDO_INICIO, BLANCO, 0.08), (x, 0), (x, SUELO_Y), 2)
        pygame.draw.rect(pantalla, PISO, (0, SUELO_Y, ANCHO, ALTO - SUELO_Y))
        pygame.draw.line(pantalla, LINEA_PISO, (0, SUELO_Y), (ANCHO, SUELO_Y), 3)
        for b in j["bloques"]:
            r = b.move(-cam, 0)
            if -TILE < r.x < ANCHO:
                pygame.draw.rect(pantalla, BLOQUE, r)
                pygame.draw.rect(pantalla, BLOQUE_BORDE, r, 2)
        for p in j["pinchos"]:
            r = p.move(-cam, 0)
            if -TILE < r.x < ANCHO:
                dibujar_pincho(pantalla, r)
        # meta: una línea brillante al final
        fin_x = j["largo"] - cam
        if -10 < fin_x < ANCHO + 10:
            pygame.draw.rect(pantalla, VERDE, (fin_x, 0, 8, SUELO_Y))
        if j["estado"] == "explotando":
            for p in j["particulas"]:
                p.dibujar(pantalla, cam)
        else:
            cubo.dibujar(pantalla, cam)

        # barra de progreso y textos
        pygame.draw.rect(pantalla, BARRA_FONDO, (ANCHO // 2 - 150, 14, 300, 14), border_radius=7)
        pygame.draw.rect(pantalla, BARRA, (ANCHO // 2 - 150, 14, int(300 * progreso), 14), border_radius=7)
        texto(pantalla, fuente_chica, f"{int(progreso * 100)}%", 44)
        texto(pantalla, fuente_chica, f"Nivel {j['indice'] + 1}/{len(NIVELES)}", 22, x=90)
        texto(pantalla, fuente_chica, f"Intento {j['intentos']}", 22, x=ANCHO - 90)

        if j["estado"] == "completo":
            texto(pantalla, fuente_grande, "¡NIVEL COMPLETO!", ALTO // 2 - 40, VERDE)
        elif j["estado"] == "ganaste":
            texto(pantalla, fuente_grande, "¡GANASTE TODO!", ALTO // 2 - 40, VERDE)
            texto(pantalla, fuente_chica, f"{pygame.key.name(TECLA['reiniciar']).upper()} para jugar de nuevo", ALTO // 2 + 20)

        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
