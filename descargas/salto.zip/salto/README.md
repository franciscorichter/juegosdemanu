# Salto — runner de Manu

Un cubo que corre solo. Tú solo decides **cuándo saltar**. Pinchos y bloques
de frente te hacen explotar, y vuelves a empezar al tiro. Arriba se ve el
porcentaje del nivel que llevas y en qué intento vas.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 salto.py

En Windows: `python salto.py`. En Linux/Mac también sirve `./jugar.sh`.

- **ESPACIO** salta. Si lo dejas apretado, salta apenas toca el suelo.
- **R** reinicia el nivel · **ESC** cierra.
- Sobre los bloques te puedes parar. De frente, te matan.
- Al pasar el nivel 1 sigue el 2. Al terminar los dos: ¡ganaste todo!

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo:

```
saltar    = up
reiniciar = return
```

Nombres válidos: letras (`a`, `b`...), flechas (`up`, `down`, `left`, `right`),
`space`, `return`, `tab`, `left shift`, `left ctrl`, números. Si escribes una
tecla que no existe, el juego avisa en la terminal y usa la de siempre.

## Dibuja tu propio nivel

Los niveles son `nivel1.txt` y `nivel2.txt` (lista `NIVELES` arriba de
`salto.py`). Cada letra es un cuadrito, y **la última fila es la que va pegada
al piso**:

    #  bloque (te paras encima; de frente te mata)
    ^  pincho (te mata)
    .  nada

El nivel termina donde termina el texto. Consejos:
- Un salto pasa por encima de hasta 3 pinchos seguidos.
- Puedes subirte a un bloque de 2 de alto, pero no a uno de 3 (salvo desde otro bloque).
- Si un pincho va encima de un bloque, escríbelo en la fila de arriba.

## Para cambiar cómo se siente

Arriba de `salto.py`: `VELOCIDAD`, `GRAVEDAD`, `SALTO`, `FONDO_INICIO` y
`FONDO_FIN` (el fondo cambia de color según cuánto llevas del nivel).

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
