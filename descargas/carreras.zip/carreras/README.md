# Carreras de Manu

Carreras vistas desde arriba, hechas en Python con pygame. **Tú eres el auto rojo.**
Todo son figuras de colores: no usa imágenes ni archivos de sonido.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 carreras.py

En Windows: `python carreras.py`. En Linux/Mac también sirve `./jugar.sh`.

**En el menú:** `1` / `2` / `3` eliges la pista (Óvalo, Chicanas, Gran Premio) y `ENTER` largas.

**Corriendo:**

- **FLECHA ARRIBA** aceleras · **FLECHA ABAJO** frenas (y marcha atrás).
- **IZQUIERDA / DERECHA** doblas. Cuanto más rápido vas, más derrapa.
- **R** corres de nuevo cuando terminó · **M** vuelves al menú · **ESC** cierras.

Todas las teclas se cambian en `controles.txt`.

### Las reglas

- 3 vueltas contra 5 rivales. Hay que pasar las **rayas amarillas** (checkpoints) en orden
  y cruzar la **meta** (cuadros blancos y negros).
- El **pasto** frena. Los **muros** te hacen rebotar.
- **Flecha verde** = turbo (vas más rápido un rato). **Mancha negra** = aceite (¡derrape!).
- Abajo ves tu posición en vivo, la vuelta, el cronómetro y tu mejor vuelta.
- La mejor vuelta de cada pista se guarda en `mejores.txt`.

## Para cambiar cosas

Arriba de `carreras.py` están los ajustes: `VEL_MAX`, `ACELERACION`, `AGARRE` (bájalo y
todo derrapa), `VUELTAS`, `RIVALES`... Cambia un número, guarda, y vuelve a correrlo.

### Haz tu propia pista

Las pistas son **dibujos de texto** de 30 x 20 letras, en `PISTAS`:

```
#  muro        .  asfalto     g  pasto (frena)
1-9 checkpoints en orden      M  meta
S  largada (pon al menos 6)   T  turbo      O  aceite
```

Copia una pista, cámbiale el dibujo y el nombre, y ponle los `puntos` por donde van a
manejar los rivales (columna, fila; `.5` es el centro del cuadrito). Los checkpoints tienen
que cruzar la pista completa, si no los autos se los saltan.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
