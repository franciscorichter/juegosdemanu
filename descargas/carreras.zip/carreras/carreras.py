"""
Carreras — versión de Manu
==========================
Carreras vistas desde arriba, hechas en Python con pygame. Tú eres el auto ROJO.

Controles (todos se cambian en controles.txt):
  FLECHA ARRIBA  -> acelerar
  FLECHA ABAJO   -> frenar / marcha atrás
  IZQ / DER      -> doblar
  1 / 2 / 3      -> elegir pista (en el menú)
  ENTER          -> empezar
  R              -> correr de nuevo cuando terminó
  M              -> volver al menú
  ESC            -> salir

La carrera: 3 vueltas contra 5 rivales. Hay que pasar los checkpoints en orden
(las rayas amarillas) y cruzar la meta (rayas blancas y negras).
- El pasto frena. Los muros te hacen rebotar.
- Ítems: TURBO (flecha verde) te acelera un rato; ACEITE (mancha negra) te hace derrapar.
- Tu mejor vuelta de cada pista se guarda en mejores.txt.

Las pistas son dibujos de texto (mira PISTAS más abajo): puedes hacer la tuya.
"""

import array
import math
import os
import random

import pygame

# ---------- Ajustes del juego (cámbialos y prueba qué pasa) ----------
TILE = 30                        # tamaño de cada cuadrito de la pista
COLS, FILAS = 30, 20             # cuadritos de ancho y de alto
ANCHO, ALTO = COLS * TILE, FILAS * TILE + 50   # ventana (abajo va el HUD)
FPS = 60

VUELTAS = 3
RIVALES = 5

ACELERACION = 0.16               # cuánto sube la velocidad por cuadro con el acelerador
FRENO = 0.35                     # cuánto baja con el freno
VEL_MAX = 6.5                    # velocidad tope en asfalto (píxeles por cuadro)
VEL_MAX_PASTO = 3.0              # en el pasto
VEL_MAX_ATRAS = 2.0              # marcha atrás
ROCE = 0.985                     # por cuadro, la velocidad se multiplica por esto (suelta el acelerador y frenas solo)
ROCE_PASTO = 0.94
GIRO = 3.6                       # grados por cuadro al doblar, a velocidad tope
AGARRE = 0.82                    # cuánto del derrape se corrige por cuadro (1 = sin derrape)
AGARRE_ACEITE = 0.985            # con aceite casi no se corrige: ¡derrape!
DURACION_TURBO = 1.6             # segundos
DURACION_ACEITE = 1.5
TURBO_VEL = 1.5                  # el turbo multiplica la velocidad tope
REBOTE = -0.35                   # al chocar un muro, la velocidad se multiplica por esto

CUENTA_ATRAS = 3.0               # segundos de 3, 2, 1, ¡YA!

# ---------- Colores ----------
FONDO = (25, 28, 35)
ASFALTO = (70, 70, 78)
PASTO = (60, 140, 60)
MURO = (150, 150, 160)
MURO_BORDE = (100, 100, 110)
CHECK = (255, 210, 60)
META_A = (240, 240, 240)
META_B = (20, 20, 20)
TURBO = (80, 240, 120)
ACEITE = (15, 15, 20)
BLANCO = (240, 240, 240)
NEGRO = (0, 0, 0)
GRIS = (140, 140, 150)
ROJO = (225, 45, 45)
VERDE = (80, 230, 100)

COLORES_RIVALES = [
    (60, 120, 230),   # azul
    (250, 140, 30),   # naranja
    (240, 220, 60),   # amarillo
    (200, 80, 220),   # morado
    (60, 210, 210),   # cian
]

# ---------- Las pistas ----------
# Cada pista es un dibujo de texto de 30 x 20. Cada letra es un cuadrito:
#   #  muro          .  asfalto        g  pasto (frena)
#   1-9 checkpoints (en orden)         M  meta
#   S  lugar de largada               T  turbo        O  mancha de aceite
# "puntos" son los lugares por donde manejan los rivales (columna, fila), en orden.
PISTAS = [
    {
        "nombre": "Óvalo",
        "angulo": 0,                   # hacia dónde miran los autos al largar (0 = derecha)
        "puntos": [(26.5, 16.5), (26.5, 3), (3, 2.5), (3, 16.5)],
        "dibujo": [
            "##############################",
            "#.............2..............#",
            "#.....T.......2..........O...#",
            "#.............2..............#",
            "#.............2..............#",
            "#.....gggggggggggggggggggg...#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#33333g################g11111#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....gggggggggggggggggggg...#",
            "#.........SS..M..............#",
            "#..O......SS..M..............#",
            "#.........SS..M.......T......#",
            "#.........SS..M..............#",
            "##############################",
        ],
    },
    {
        "nombre": "Chicanas",
        "angulo": 0,
        "puntos": [(11.5, 17.5), (16.5, 15.5), (26.5, 16.5), (26.5, 3), (18.5, 3.5), (13.5, 1.5),
                   (3, 2.5), (3, 16.5)],
        "dibujo": [
            "##############################",
            "#..........2......gg.........#",
            "#..........2......##.........#",
            "#....T.....2.##.........O....#",
            "#..........2.##..............#",
            "#.....gggggggggggggggggggg...#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#33333g################g11111#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....g################g.....#",
            "#.....gggggggggggggggggggg...#",
            "#..........##........M.......#",
            "#....SS....##........M..O....#",
            "#....SS.........##...M...T...#",
            "#....SS.........##...M.......#",
            "##############################",
        ],
    },
    {
        "nombre": "Gran Premio",
        "angulo": 0,
        "puntos": [(5.5, 17.5), (16, 17.5), (26.5, 16.5), (26.5, 12), (26, 8.5), (27.5, 3.5),
                   (16, 2.5), (3, 2.5), (3, 9), (3, 13.5), (3.5, 17)],
        "dibujo": [
            "##############################",
            "#..............2.............#",
            "#..............2.........gg..#",
            "#....T.........2.........gg..#",
            "#..............2.......O.....#",
            "#.....gggggggggggggggg.......#",
            "#.....g###############g......#",
            "#.....g###############g......#",
            "#.....g###############g111111#",
            "#.....g###############g......#",
            "#.....g################gg....#",
            "#.....g#################g....#",
            "#.....g#################g....#",
            "#33333g#################g....#",
            "#.....gg################g....#",
            "#........gMgggggggggggggg....#",
            "#........O.M.....gg..........#",
            "#SSS......M...T..............#",
            "#SSS......M..................#",
            "##############################",
        ],
    },
]


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "acelerar": "up", "frenar": "down", "izquierda": "left", "derecha": "right",
    "pista1": "1", "pista2": "2", "pista3": "3", "empezar": "return",
    "reiniciar": "r", "menu": "m", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(CARPETA, "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


CARPETA = os.path.dirname(os.path.abspath(__file__))
TECLA = {}   # se llena en main(), después de pygame.init()


def nombre_tecla(accion):
    nombre = pygame.key.name(TECLA[accion])
    return {"return": "ENTER", "space": "ESPACIO", "escape": "ESC"}.get(nombre, nombre.upper())


# ---------- Mejores vueltas (se guardan en mejores.txt) ----------
def cargar_mejores():
    mejores = {}
    try:
        with open(os.path.join(CARPETA, "mejores.txt"), encoding="utf-8") as f:
            for linea in f:
                if "=" in linea:
                    nombre, valor = linea.strip().split("=", 1)
                    try:
                        mejores[nombre] = float(valor)
                    except ValueError:
                        pass
    except OSError:
        pass
    return mejores


def guardar_mejores(mejores):
    try:
        with open(os.path.join(CARPETA, "mejores.txt"), "w", encoding="utf-8") as f:
            for nombre, valor in mejores.items():
                f.write(f"{nombre}={valor:.2f}\n")
    except OSError:
        pass


def formato_tiempo(seg):
    return f"{int(seg // 60)}:{seg % 60:05.2f}"


# ---------- Sonidos fabricados con matemáticas ----------
class Sonidos:
    """Cada sonido es una lista de números (la onda) que le pasamos a pygame.
    Si el computador no tiene audio, simplemente no suena nada."""

    def __init__(self):
        self.ok = False
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1)
            self.frec, _, self.canales = pygame.mixer.get_init()
            self.ok = True
        except pygame.error:
            return
        self.cuenta = self._armar(self._beep(660, 0.15))
        self.ya = self._armar(self._beep(990, 0.4))
        self.check = self._armar(self._beep(1100, 0.06, volumen=0.3))
        self.vuelta = self._armar(self._beep(523, 0.1) + self._beep(659, 0.1) + self._beep(784, 0.2))
        self.choque = self._armar(self._ruido(0.15, volumen=0.5))
        self.turbo = self._armar(self._tono_subiendo(200, 900, 0.4))
        self.aceite = self._armar(self._tono_subiendo(500, 150, 0.3, volumen=0.4))
        self.final = self._armar(self._beep(523, 0.15) + self._beep(659, 0.15) + self._beep(784, 0.15) + self._beep(1046, 0.4))

    def _beep(self, hz, seg, volumen=0.5):
        n = int(self.frec * seg)
        return [volumen * math.sin(2 * math.pi * hz * i / self.frec) * min(1.0, (n - i) / (n * 0.3))
                for i in range(n)]

    def _tono_subiendo(self, hz_inicio, hz_fin, seg, volumen=0.5):
        n = int(self.frec * seg)
        muestras, fase = [], 0.0
        for i in range(n):
            hz = hz_inicio + (hz_fin - hz_inicio) * i / n
            fase += 2 * math.pi * hz / self.frec
            muestras.append(volumen * math.sin(fase) * (1 - i / n))
        return muestras

    def _ruido(self, seg, volumen=0.4):
        n = int(self.frec * seg)
        return [volumen * random.uniform(-1, 1) * (1 - i / n) for i in range(n)]

    def _armar(self, muestras):
        datos = array.array("h")
        for m in muestras:
            v = int(max(-1.0, min(1.0, m)) * 32767)
            for _ in range(self.canales):
                datos.append(v)
        return pygame.mixer.Sound(buffer=datos.tobytes())

    def tocar(self, nombre):
        if self.ok:
            getattr(self, nombre).play()


SONIDO = None


def sonar(nombre):
    if SONIDO is not None:
        SONIDO.tocar(nombre)


# ---------- La pista ----------
class Pista:
    def __init__(self, datos):
        self.nombre = datos["nombre"]
        self.angulo = datos["angulo"]
        self.puntos = [(c * TILE, f * TILE) for c, f in datos["puntos"]]   # (11.5, 17.5) = centro del cuadrito col 11, fila 17
        self.filas = datos["dibujo"]
        assert len(self.filas) == FILAS and all(len(f) == COLS for f in self.filas), \
            f"la pista '{self.nombre}' tiene que ser de {COLS} x {FILAS} letras"
        self.checkpoints = sorted({ch for fila in self.filas for ch in fila if ch.isdigit()})
        self.largadas = [((c + 0.5) * TILE, (f + 0.5) * TILE)
                         for f, fila in enumerate(self.filas) for c, ch in enumerate(fila) if ch == "S"]
        # Centro de cada checkpoint: para saber qué tan lejos va cada auto (posiciones en vivo).
        self.centro_check = {}
        for d in self.checkpoints:
            celdas = [(c, f) for f, fila in enumerate(self.filas) for c, ch in enumerate(fila) if ch == d]
            self.centro_check[d] = ((sum(c for c, _ in celdas) / len(celdas) + 0.5) * TILE,
                                   (sum(f for _, f in celdas) / len(celdas) + 0.5) * TILE)
        celdas = [(c, f) for f, fila in enumerate(self.filas) for c, ch in enumerate(fila) if ch == "M"]
        self.centro_meta = ((sum(c for c, _ in celdas) / len(celdas) + 0.5) * TILE,
                            (sum(f for _, f in celdas) / len(celdas) + 0.5) * TILE)
        self.superficie = None

    def letra(self, x, y):
        """Qué hay en el cuadrito donde cae este punto."""
        c, f = int(x // TILE), int(y // TILE)
        if 0 <= f < FILAS and 0 <= c < COLS:
            return self.filas[f][c]
        return "#"

    def es_muro(self, x, y):
        return self.letra(x, y) == "#"

    def dibujar_base(self):
        """Dibuja la pista una sola vez en una superficie, para no repetirlo cada cuadro."""
        s = pygame.Surface((COLS * TILE, FILAS * TILE))
        s.fill(FONDO)
        for f, fila in enumerate(self.filas):
            for c, ch in enumerate(fila):
                r = pygame.Rect(c * TILE, f * TILE, TILE, TILE)
                if ch == "#":
                    pygame.draw.rect(s, MURO, r)
                    pygame.draw.rect(s, MURO_BORDE, r, 1)
                elif ch == "g":
                    pygame.draw.rect(s, PASTO, r)
                else:
                    pygame.draw.rect(s, ASFALTO, r)
                if ch.isdigit():
                    pygame.draw.rect(s, CHECK, r.inflate(-16, 0) if self._vertical(c, f) else r.inflate(0, -16))
                elif ch == "M":
                    for i in range(3):
                        for j in range(3):
                            color = META_A if (i + j) % 2 == 0 else META_B
                            pygame.draw.rect(s, color, (c * TILE + i * 10, f * TILE + j * 10, 10, 10))
                elif ch == "T":
                    cx, cy = r.center
                    pygame.draw.polygon(s, TURBO, [(cx - 10, cy + 8), (cx + 10, cy + 8), (cx, cy - 10)])
                elif ch == "O":
                    pygame.draw.ellipse(s, ACEITE, r.inflate(-4, -10))
        self.superficie = s

    def _vertical(self, c, f):
        """¿Este checkpoint es una raya vertical (mismo número arriba o abajo)?"""
        ch = self.filas[f][c]
        arriba = f > 0 and self.filas[f - 1][c] == ch
        abajo = f < FILAS - 1 and self.filas[f + 1][c] == ch
        return arriba or abajo


# ---------- Los autos ----------
class Auto:
    def __init__(self, pista, color, pos, es_jugador=False):
        self.pista = pista
        self.color = color
        self.x, self.y = pos
        self.angulo = pista.angulo         # grados; 0 = derecha, 90 = abajo (en pantalla el eje y va hacia abajo)
        self.vx, self.vy = 0.0, 0.0        # velocidad como vector
        self.es_jugador = es_jugador
        self.vueltas = 0
        self.siguiente = 0                 # índice del próximo checkpoint que tiene que pasar
        self.termino = False
        self.turbo = 0.0
        self.aceite = 0.0
        self.tiempo_vuelta = 0.0
        self.mejor_vuelta = None
        self.tiempo_total = 0.0
        self.punto = 0                     # para los rivales: a qué punto van
        self.habilidad = random.uniform(0.86, 1.0)   # los rivales no son todos igual de buenos
        self.choque_t = 0.0
        self.parado_t = 0.0                # segundos que lleva casi detenido (para despegarse de un muro)
        self.retrocediendo = 0.0           # segundos que le quedan de marcha atrás

    # --- velocidad "hacia adelante" (positiva) o "hacia atrás" (negativa) ---
    @property
    def rapidez(self):
        rad = math.radians(self.angulo)
        return self.vx * math.cos(rad) + self.vy * math.sin(rad)

    def controlar(self, acelerar, frenar, izquierda, derecha, dt):
        """Un cuadro de física. acelerar/frenar/izquierda/derecha son True o False."""
        letra = self.pista.letra(self.x, self.y)
        en_pasto = letra == "g"

        # 1. Ítems: pisar un turbo o una mancha de aceite.
        if letra == "T" and self.turbo <= 0:
            self.turbo = DURACION_TURBO
            if self.es_jugador:
                sonar("turbo")
        if letra == "O" and self.aceite <= 0:
            self.aceite = DURACION_ACEITE
            if self.es_jugador:
                sonar("aceite")
        self.turbo = max(0.0, self.turbo - dt)
        self.aceite = max(0.0, self.aceite - dt)
        self.choque_t = max(0.0, self.choque_t - dt)

        # 2. Doblar: cuanto más rápido vas, más dobla (y con aceite, dobla igual pero no agarra).
        rapidez = self.rapidez
        tope = VEL_MAX_PASTO if en_pasto else VEL_MAX
        if self.turbo > 0:
            tope *= TURBO_VEL
        giro = GIRO * max(-1.0, min(1.0, rapidez / VEL_MAX))
        if izquierda:
            self.angulo -= giro
        if derecha:
            self.angulo += giro

        # 3. Acelerar / frenar a lo largo de hacia dónde mira el auto.
        rad = math.radians(self.angulo)
        fx, fy = math.cos(rad), math.sin(rad)
        if acelerar:
            self.vx += fx * ACELERACION * (TURBO_VEL if self.turbo > 0 else 1)
            self.vy += fy * ACELERACION * (TURBO_VEL if self.turbo > 0 else 1)
        if frenar:
            if rapidez > 0.3:
                self.vx -= fx * FRENO
                self.vy -= fy * FRENO
            else:
                self.vx -= fx * ACELERACION * 0.6
                self.vy -= fy * ACELERACION * 0.6

        # 4. Agarre: la parte de la velocidad que va "de lado" se corrige (o no, con aceite).
        adelante = self.vx * fx + self.vy * fy
        lado_x, lado_y = self.vx - adelante * fx, self.vy - adelante * fy
        agarre = AGARRE_ACEITE if self.aceite > 0 else AGARRE
        roce = ROCE_PASTO if en_pasto else ROCE
        adelante *= roce
        adelante = max(-VEL_MAX_ATRAS, min(tope, adelante))
        self.vx = adelante * fx + lado_x * agarre
        self.vy = adelante * fy + lado_y * agarre

        # 5. Moverse, chocando con los muros (eje por eje, para deslizarse).
        if self.pista.es_muro(self.x + self.vx, self.y):
            self.vx *= REBOTE
            self._chocar()
        else:
            self.x += self.vx
        if self.pista.es_muro(self.x, self.y + self.vy):
            self.vy *= REBOTE
            self._chocar()
        else:
            self.y += self.vy

        # 6. Checkpoints y meta.
        self._revisar_progreso(dt)

    def _chocar(self):
        if self.es_jugador and self.choque_t <= 0 and math.hypot(self.vx, self.vy) > 1.5:
            sonar("choque")
            self.choque_t = 0.4

    def _revisar_progreso(self, dt):
        if self.termino:
            return
        self.tiempo_vuelta += dt
        self.tiempo_total += dt
        letra = self.pista.letra(self.x, self.y)
        checks = self.pista.checkpoints
        if self.siguiente < len(checks) and letra == checks[self.siguiente]:
            self.siguiente += 1
            if self.es_jugador:
                sonar("check")
        elif letra == "M" and self.siguiente == len(checks):
            self.vueltas += 1
            self.siguiente = 0
            if self.mejor_vuelta is None or self.tiempo_vuelta < self.mejor_vuelta:
                self.mejor_vuelta = self.tiempo_vuelta
            self.tiempo_vuelta = 0.0
            if self.vueltas >= VUELTAS:
                self.termino = True
            if self.es_jugador:
                sonar("final" if self.termino else "vuelta")

    def progreso(self):
        """Un número que crece mientras más avanzado vas: sirve para las posiciones en vivo."""
        checks = self.pista.checkpoints
        if self.siguiente < len(checks):
            objetivo = self.pista.centro_check[checks[self.siguiente]]
        else:
            objetivo = self.pista.centro_meta
        d = math.hypot(self.x - objetivo[0], self.y - objetivo[1])
        return self.vueltas * 100 + self.siguiente * 10 + (1 - min(1.0, d / 2000))

    # --- la "inteligencia" de los rivales ---
    def manejar_solo(self, dt):
        """Los rivales van de punto en punto. Doblan hacia el punto y frenan en las curvas."""
        puntos = self.pista.puntos
        px, py = puntos[self.punto]
        sx, sy = puntos[(self.punto + 1) % len(puntos)]
        # Pasa al siguiente punto si ya llegó, o si se lo saltó (el siguiente ya está más cerca).
        if math.hypot(px - self.x, py - self.y) < TILE * 1.4 or \
                math.hypot(sx - self.x, sy - self.y) < math.hypot(px - self.x, py - self.y) * 0.8:
            self.punto = (self.punto + 1) % len(puntos)
            px, py = puntos[self.punto]
        deseado = math.degrees(math.atan2(py - self.y, px - self.x))
        diferencia = (deseado - self.angulo + 180) % 360 - 180   # entre -180 y 180
        izquierda = diferencia < -4
        derecha = diferencia > 4

        # Plan B: si lleva un segundo pegado a un muro, retrocede un poco doblando al revés.
        if abs(self.rapidez) < 0.6 and not self.termino:
            self.parado_t += dt
        else:
            self.parado_t = 0.0
        if self.parado_t > 1.0:
            self.parado_t = 0.0
            self.retrocediendo = 0.7
        if self.retrocediendo > 0:
            self.retrocediendo -= dt
            self.controlar(False, True, derecha, izquierda, dt)
            return
        # En una curva cerrada, o si va muy rápido para su habilidad, suelta el acelerador.
        rapido = self.rapidez > VEL_MAX * self.habilidad
        curva = abs(diferencia) > 50 and self.rapidez > VEL_MAX * 0.5
        acelerar = not rapido and not curva
        frenar = curva and self.rapidez > VEL_MAX * 0.7
        if self.termino:                      # ya terminó: da vueltas tranquilo
            acelerar = self.rapidez < VEL_MAX * 0.5
        self.controlar(acelerar, frenar, izquierda, derecha, dt)

    def dibujar(self, s):
        rad = math.radians(self.angulo)
        fx, fy = math.cos(rad), math.sin(rad)
        lx, ly = -fy, fx                      # vector "de lado"
        largo, ancho = 13, 8
        puntos = [
            (self.x + fx * largo + lx * ancho, self.y + fy * largo + ly * ancho),
            (self.x + fx * largo - lx * ancho, self.y + fy * largo - ly * ancho),
            (self.x - fx * largo - lx * ancho, self.y - fy * largo - ly * ancho),
            (self.x - fx * largo + lx * ancho, self.y - fy * largo + ly * ancho),
        ]
        pygame.draw.polygon(s, self.color, puntos)
        pygame.draw.polygon(s, NEGRO, puntos, 2)
        # el "parabrisas" marca hacia dónde mira
        pygame.draw.circle(s, BLANCO, (int(self.x + fx * 6), int(self.y + fy * 6)), 3)
        if self.turbo > 0:
            pygame.draw.circle(s, TURBO, (int(self.x - fx * 15), int(self.y - fy * 15)), 5)


# ---------- La carrera ----------
class Juego:
    def __init__(self):
        self.pista_elegida = 0
        self.estado = "inicio"      # "inicio", "cuenta", "corriendo", "final"
        self.mejores = cargar_mejores()

    def empezar(self):
        self.pista = Pista(PISTAS[self.pista_elegida])
        self.pista.dibujar_base()
        largadas = self.pista.largadas[:RIVALES + 1]
        random.shuffle(largadas)
        self.jugador = Auto(self.pista, ROJO, largadas[0], es_jugador=True)
        self.rivales = [Auto(self.pista, COLORES_RIVALES[i], largadas[i + 1]) for i in range(RIVALES)]
        self.autos = [self.jugador] + self.rivales
        self.cuenta = CUENTA_ATRAS
        self.ultimo_beep = 4
        self.estado = "cuenta"
        self.posicion_final = None
        self.nuevo_record = False

    def reiniciar(self):
        self.empezar()

    def posiciones(self):
        """Lista de autos ordenados del primero al último."""
        return sorted(self.autos, key=lambda a: (a.termino, a.progreso()), reverse=True)

    def actualizar(self, dt, teclas):
        if self.estado == "cuenta":
            self.cuenta -= dt
            if int(self.cuenta) + 1 < self.ultimo_beep and self.cuenta > 0:
                self.ultimo_beep = int(self.cuenta) + 1
                sonar("cuenta")
            if self.cuenta <= 0:
                self.estado = "corriendo"
                sonar("ya")
            return
        if self.estado != "corriendo":
            return

        self.jugador.controlar(teclas[TECLA["acelerar"]], teclas[TECLA["frenar"]],
                               teclas[TECLA["izquierda"]], teclas[TECLA["derecha"]], dt)
        for r in self.rivales:
            r.manejar_solo(dt)
        self._separar_autos()

        if self.jugador.termino:
            self.estado = "final"
            self.posicion_final = self.posiciones().index(self.jugador) + 1
            mejor = self.jugador.mejor_vuelta
            if mejor is not None and (self.pista.nombre not in self.mejores or mejor < self.mejores[self.pista.nombre]):
                self.mejores[self.pista.nombre] = mejor
                self.nuevo_record = True
                guardar_mejores(self.mejores)

    def _separar_autos(self):
        """Si dos autos se encimaron, se empujan un poquito para separarse."""
        for i, a in enumerate(self.autos):
            for b in self.autos[i + 1:]:
                dx, dy = b.x - a.x, b.y - a.y
                d = math.hypot(dx, dy)
                if 0 < d < 22:
                    empuje = (22 - d) / 2
                    ex, ey = dx / d * empuje, dy / d * empuje
                    if not a.pista.es_muro(a.x - ex, a.y - ey):
                        a.x -= ex
                        a.y -= ey
                    if not b.pista.es_muro(b.x + ex, b.y + ey):
                        b.x += ex
                        b.y += ey

    # --- dibujar ---
    def dibujar(self, pantalla, fuente, fuente_grande):
        if self.estado == "inicio":
            self._dibujar_inicio(pantalla, fuente, fuente_grande)
            return
        pantalla.fill(FONDO)
        pantalla.blit(self.pista.superficie, (0, 0))
        for a in sorted(self.autos, key=lambda a: a.es_jugador):   # el jugador se dibuja al final (encima)
            a.dibujar(pantalla)
        self._dibujar_hud(pantalla, fuente)
        if self.estado == "cuenta":
            n = int(self.cuenta) + 1
            t = fuente_grande.render(str(n), True, CHECK)
            pantalla.blit(t, t.get_rect(center=(ANCHO // 2, FILAS * TILE // 2)))
        elif self.estado == "final":
            self._dibujar_final(pantalla, fuente, fuente_grande)

    def _dibujar_hud(self, pantalla, fuente):
        j = self.jugador
        y = FILAS * TILE + 4
        pos = self.posiciones().index(j) + 1
        vuelta = min(j.vueltas + 1, VUELTAS)
        mejor = self.mejores.get(self.pista.nombre)
        textos = [
            f"Posición {pos}/{len(self.autos)}",
            f"Vuelta {vuelta}/{VUELTAS}",
            f"Tiempo {formato_tiempo(j.tiempo_total)}",
            f"Esta vuelta {formato_tiempo(j.tiempo_vuelta)}",
            f"Mejor {formato_tiempo(mejor) if mejor else '--:--'}",
        ]
        x = 12
        for t in textos:
            r = fuente.render(t, True, BLANCO)
            pantalla.blit(r, (x, y))
            x += r.get_width() + 26
        if j.turbo > 0:
            pantalla.blit(fuente.render("¡TURBO!", True, TURBO), (x, y))
        elif j.aceite > 0:
            pantalla.blit(fuente.render("¡ACEITE!", True, CHECK), (x, y))
        # La lista de posiciones, compacta, a la derecha de la barra (cada nombre con su color).
        x = ANCHO - 12
        for i, a in reversed(list(enumerate(self.posiciones()))):
            nombre = "TÚ" if a.es_jugador else f"R{COLORES_RIVALES.index(a.color) + 1}"
            r = fuente.render(f"{i + 1}.{nombre}", True, a.color)
            x -= r.get_width()
            pantalla.blit(r, (x, y + 22))
            x -= 10

    def _dibujar_inicio(self, pantalla, fuente, fuente_grande):
        pantalla.fill(FONDO)
        t = fuente_grande.render("CARRERAS", True, ROJO)
        pantalla.blit(t, t.get_rect(center=(ANCHO // 2, 100)))
        lineas = [(f"Pista: {PISTAS[self.pista_elegida]['nombre']}", BLANCO)]
        for i, p in enumerate(PISTAS):
            mejor = self.mejores.get(p["nombre"])
            tecla = nombre_tecla(f"pista{i + 1}")
            lineas.append((f"   {tecla} = {p['nombre']}   (mejor vuelta: {formato_tiempo(mejor) if mejor else '--:--'})", GRIS))
        lineas += [
            ("", BLANCO),
            (f"{nombre_tecla('empezar')} para largar", VERDE),
            ("", BLANCO),
            (f"{VUELTAS} vueltas contra {RIVALES} rivales. Pasa las rayas amarillas en orden y cruza la meta.", GRIS),
            (f"{nombre_tecla('acelerar')}: acelerar   {nombre_tecla('frenar')}: frenar   "
             f"{nombre_tecla('izquierda')}/{nombre_tecla('derecha')}: doblar", GRIS),
            ("Flecha verde = turbo. Mancha negra = aceite (¡derrape!). El pasto frena.", GRIS),
        ]
        y = 180
        for texto, color in lineas:
            if texto:
                r = fuente.render(texto, True, color)
                pantalla.blit(r, r.get_rect(center=(ANCHO // 2, y)))
            y += 30
        # una vista chiquita de la pista elegida
        pista = Pista(PISTAS[self.pista_elegida])
        pista.dibujar_base()
        mini = pygame.transform.smoothscale(pista.superficie, (COLS * 8, FILAS * 8))
        pantalla.blit(mini, mini.get_rect(center=(ANCHO // 2, ALTO - 120)))

    def _dibujar_final(self, pantalla, fuente, fuente_grande):
        capa = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        capa.fill((0, 0, 0, 170))
        pantalla.blit(capa, (0, 0))
        pos = self.posicion_final
        titulo = {1: "¡GANASTE!", 2: "¡2° LUGAR!", 3: "¡3° LUGAR!"}.get(pos, f"{pos}° LUGAR")
        color = VERDE if pos == 1 else CHECK
        t = fuente_grande.render(titulo, True, color)
        pantalla.blit(t, t.get_rect(center=(ANCHO // 2, ALTO // 2 - 60)))
        j = self.jugador
        m = fuente.render(f"Tiempo total {formato_tiempo(j.tiempo_total)}   ·   mejor vuelta {formato_tiempo(j.mejor_vuelta)}"
                          + ("   ¡NUEVO RÉCORD!" if self.nuevo_record else ""), True, BLANCO)
        pantalla.blit(m, m.get_rect(center=(ANCHO // 2, ALTO // 2)))
        r = fuente.render(f"{nombre_tecla('reiniciar')} correr de nuevo   ·   {nombre_tecla('menu')} menú   ·   "
                          f"{nombre_tecla('salir')} salir", True, GRIS)
        pantalla.blit(r, r.get_rect(center=(ANCHO // 2, ALTO // 2 + 40)))


def main():
    global SONIDO
    pygame.init()
    TECLA.update(cargar_controles())
    SONIDO = Sonidos()
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Carreras — de Manu")
    reloj = pygame.time.Clock()
    fuente = pygame.font.SysFont(None, 24)
    fuente_grande = pygame.font.SysFont(None, 90)

    juego = Juego()
    corriendo = True
    while corriendo:
        dt = reloj.tick(FPS) / 1000.0
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN:
                k = evento.key
                if k == TECLA["salir"]:
                    corriendo = False
                elif juego.estado == "inicio":
                    for i in range(len(PISTAS)):
                        if k == TECLA[f"pista{i + 1}"]:
                            juego.pista_elegida = i
                    if k == TECLA["empezar"]:
                        juego.empezar()
                elif juego.estado == "final":
                    if k == TECLA["reiniciar"]:
                        juego.reiniciar()
                    elif k == TECLA["menu"]:
                        juego.estado = "inicio"
                elif k == TECLA["menu"]:
                    juego.estado = "inicio"

        juego.actualizar(dt, pygame.key.get_pressed())
        juego.dibujar(pantalla, fuente, fuente_grande)
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
