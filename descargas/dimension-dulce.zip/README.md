# Dimensión Dulce (datapack para Minecraft 1.21.4)

Una dimensión nueva hecha de caramelo: colinas de pasto rosado con parches de
lana rosa y magenta, tierra de terracota rosa, roca de panal de abejas
(honeycomb) y lagos de bloques de miel en los valles. Cielo, niebla y agua
rosados, corazones flotando, cerezos, conejos, abejas y ovejas. Nada de
monstruos. Y mientras estás ahí te curas solo.

## Instalar

1. Copia `dimension-dulce.zip` a la carpeta `datapacks` de tu mundo:

   ```
   ~/.var/app/com.mojang.Minecraft/.minecraft/saves/<tu mundo>/datapacks/
   ```

2. **Importante:** para una dimensión nueva `/reload` NO basta. Sal del mundo
   (Guardar y salir) y vuelve a entrar. Las dimensiones solo se cargan cuando
   se abre el mundo.

3. Al entrar debería salir en el chat: `[Dulce] listo...`. Si no sale, revisa
   con `/datapack list` que aparezca `file/dimension-dulce.zip` en verde.

Si quieres la carpeta en vez del zip, copia la carpeta `dimension-dulce/`
entera (la que tiene `pack.mcmeta` adentro) a `datapacks/`.

## Usar

| Comando | Qué hace |
|---|---|
| `/function dulce:ir` | Te lleva a la Dimensión Dulce, a altura 100, con una plataforma 5x5 de miel bajo los pies. Guarda el sitio donde estabas. |
| `/function dulce:volver` | Te devuelve al mundo normal, al mismo sitio donde estabas antes de irte. |
| `/function dulce:curar` | (interno) Regeneración cada 2 segundos a quien esté en la dimensión. |

- Al entrar por primera vez ganas el logro **¡Bienvenido a la Dimensión Dulce!**,
  te regala miel y azúcar, y desbloquea las dos recetas en el libro de recetas.
- La miel es pegajosa: los lagos frenan y no te dejan saltar. Los cerezos y las
  colinas sí son normales.

## Recetas nuevas

**Caramelo dorado** (da una manzana dorada normal):

```
azúcar  miel    azúcar
miel    manzana miel
azúcar  miel    azúcar
```

**Bloque de miel barato**: 2 frascos de miel uno al lado del otro → 1 bloque de
miel (la receta normal pide 4).

## Cómo está armado (por si quieres cambiarlo)

```
pack.mcmeta                              pack_format 61 = 1.21.4
data/minecraft/tags/function/            load.json y tick.json
data/dulce/
  dimension/dulce.json                   la dimensión: usa el tipo y el generador de abajo
  dimension_type/dulce.json              cielo normal, sin techo, luz ambiente alta, camas OK
  worldgen/noise_settings/dulce.json     el generador: colinas + reglas de qué bloque va en cada capa
  worldgen/noise/colinas.json            el "ruido" que dibuja las colinas
  worldgen/biome/caramelo.json           colores, música, partículas, animales, cerezos
  function/*.mcfunction                  ir, volver, tick, curar, load, bienvenida
  recipe/*.json                          caramelo_dorado, miel_barata
  advancement/bienvenido.json            el logro
```

Ideas para tocar:

- **Colores**: en `biome/caramelo.json`, `sky_color`, `fog_color`, `water_color`,
  `grass_color` son números decimales de un color hexadecimal
  (`0xFFA6D9` = `16754393`). Pruébalo en Python: `print(0xFF0000)`.
- **Qué bloque va en la superficie**: en `noise_settings/dulce.json`, busca
  `result_state` y cambia `minecraft:pink_wool` por el bloque que quieras.
- **Altura de las colinas**: en el mismo archivo, el `mul` con `0.7`. Más grande
  = colinas más altas. Los lagos de miel están fijos en altura 57.
- **Animales**: la lista `spawners.creature`. Los animales solo aparecen sobre
  `grass_block`, por eso el suelo es pasto teñido de rosa y no solo lana.

## Cosas que saber

- Después de cambiar cualquier archivo de `worldgen/`, `dimension/` o
  `dimension_type/`, hay que salir y volver a entrar al mundo. Las funciones y
  recetas sí se recargan con `/reload`.
- Los chunks que ya se generaron no cambian aunque cambies el generador; para
  ver los cambios explora zonas nuevas o usa un mundo nuevo.
