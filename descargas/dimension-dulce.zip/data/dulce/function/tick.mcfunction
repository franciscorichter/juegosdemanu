# Se ejecuta 20 veces por segundo

# El reloj suma 1 cada tick; cuando llega a 40 (2 segundos) curamos y lo ponemos en 0
scoreboard players add #reloj dulce_reloj 1
execute if score #reloj dulce_reloj matches 40.. run function dulce:curar
