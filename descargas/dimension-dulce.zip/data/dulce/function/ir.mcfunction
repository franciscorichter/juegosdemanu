# Viajar a la Dimension Dulce. Usalo asi: /function dulce:ir
# Se ejecuta "como" el jugador que lo escribe (@s = tu)

# 1. Guardamos donde estabas, para poder volver despues con dulce:volver
execute store result score @s dulce_x run data get entity @s Pos[0]
execute store result score @s dulce_y run data get entity @s Pos[1]
execute store result score @s dulce_z run data get entity @s Pos[2]
scoreboard players set @s dulce_fue 1

# 2. Teletransporte: mismas x y z, pero en la otra dimension, a altura 100
execute in dulce:dulce run tp @s ~ 100 ~

# 3. Plataforma segura de 5x5 de bloques de miel justo debajo de los pies (altura 99)
execute at @s run fill ~-2 99 ~-2 ~2 99 ~2 minecraft:honey_block

# 4. Un poquito de caida lenta por si acaso
effect give @s minecraft:slow_falling 5 0 true
playsound minecraft:block.honey_block.slide player @s ~ ~ ~ 1 1.5
title @s title {"text":"Dimension Dulce","color":"light_purple"}
title @s subtitle {"text":"Cuidado: la miel es pegajosa","color":"gold"}
