# Se ejecuta una vez cuando carga el mundo (o con /reload)

# Aqui guardamos donde estaba cada jugador antes de irse a la Dimension Dulce
scoreboard objectives add dulce_x dummy
scoreboard objectives add dulce_y dummy
scoreboard objectives add dulce_z dummy

# 1 = ya se fue alguna vez con /function dulce:ir (asi sabemos si hay sitio guardado)
scoreboard objectives add dulce_fue dummy

# Reloj para no curar 20 veces por segundo, solo cada 2 segundos
scoreboard objectives add dulce_reloj dummy
scoreboard players set #reloj dulce_reloj 0

tellraw @a [{"text":"[Dulce] ","color":"light_purple"},{"text":"listo. Escribe ","color":"gray"},{"text":"/function dulce:ir","color":"gold"},{"text":" para viajar a la Dimension Dulce.","color":"gray"}]
