# Premio del logro "Bienvenido a la Dimension Dulce" (se ejecuta una sola vez por jugador)
tellraw @s [{"text":"[Dulce] ","color":"light_purple"},{"text":"Bienvenido. Aqui te curas solo, y con miel + azucar puedes craftear un ","color":"gray"},{"text":"caramelo dorado","color":"gold"},{"text":".","color":"gray"}]
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
give @s minecraft:honey_bottle 2
give @s minecraft:sugar 4
