# Funcion "macro": las lineas que empiezan con $ reciben valores de afuera
$execute in minecraft:overworld run tp @s $(x) $(y) $(z)
