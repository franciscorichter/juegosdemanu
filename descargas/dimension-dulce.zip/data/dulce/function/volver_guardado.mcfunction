# Copiamos los tres numeros guardados a un "storage" (un cofre de datos) y llamamos
# a la funcion macro, que rellena $(x) $(y) $(z) con esos numeros
execute store result storage dulce:tmp x int 1 run scoreboard players get @s dulce_x
execute store result storage dulce:tmp y int 1 run scoreboard players get @s dulce_y
execute store result storage dulce:tmp z int 1 run scoreboard players get @s dulce_z
function dulce:tp_overworld with storage dulce:tmp
