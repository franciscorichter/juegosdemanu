# Volver al mundo normal. Usalo asi: /function dulce:volver

# Si ya viniste con dulce:ir, te devolvemos al mismo sitio donde estabas
execute if score @s dulce_fue matches 1 run function dulce:volver_guardado

# Si no hay sitio guardado, vamos a las mismas x z del overworld y buscamos suelo firme
execute unless score @s dulce_fue matches 1 run function dulce:volver_superficie

playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Dulce] ","color":"light_purple"},{"text":"de vuelta en el mundo normal.","color":"gray"}]
