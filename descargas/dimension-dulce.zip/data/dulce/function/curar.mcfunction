# Regeneracion lenta (nivel 1, 3 segundos) a todos los que esten en la Dimension Dulce.
# El "true" del final esconde las particulas para que no molesten.
execute as @a if dimension dulce:dulce run effect give @s minecraft:regeneration 3 0 true
scoreboard players set #reloj dulce_reloj 0
