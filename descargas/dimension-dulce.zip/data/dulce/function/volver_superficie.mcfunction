# Sin sitio guardado: mismas x y z en el overworld, pero encima del suelo mas alto
execute in minecraft:overworld run tp @s ~ 200 ~
execute at @s run spreadplayers ~ ~ 0 1 false @s
