#!/bin/bash
# Abre el juego. Si hay una cajita .venv (con pygame adentro) la usa;
# si no, usa el python3 normal del computador.
cd "$(dirname "$0")"
if [ -x .venv/bin/python ]; then
    exec .venv/bin/python torres.py "$@"
else
    exec python3 torres.py "$@"
fi
