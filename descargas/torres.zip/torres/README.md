# Torres

Un tower defense hecho en Python con pygame. Los enemigos (círculos) caminan por
el camino hacia tu **base**. Tú pones **torres** en el pasto para detenerlos.
Aguanta **10 oleadas** y ganas. Si llegan 10 enemigos a tu base, pierdes.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 torres.py

En Windows: `python torres.py`. En Linux/Mac también sirve `./jugar.sh`.

- **1 / 2 / 3** (o clic en las tarjetas de abajo) eligen el tipo de torre.
- **Clic izquierdo** en el pasto pone la torre (si tienes monedas). El círculo blanco muestra hasta dónde dispara.
- **Clic derecho** sobre una torre la vende (te devuelve la mitad).
- **ESPACIO** lanza la siguiente oleada (si no, sale sola a los 15 s).
- **R** reinicia · **ESC** cierra.

Las torres:

| Torre | Precio | Cómo es |
|---|---|---|
| Rápida (celeste) | 50 | dispara muy seguido, poco daño |
| Fuerte (naranja) | 90 | mucho daño, alcance largo, lenta |
| Bomba (morada) | 120 | explota y daña a todos los que estén cerca |

Los enemigos: **rojos** normales, **amarillos** rápidos, **grises** tanques (mucha vida).
Cada oleada tienen más vida. Matarlos da monedas, y terminar una oleada da 30 extra.

## Haz tu propio mapa

El mapa está en `camino.txt`. Es un dibujo con letras:

    .  pasto (aquí puedes construir)     =  camino
    S  donde salen los enemigos           B  tu base
    #  roca (no se puede construir)

El camino `=` tiene que conectar la **S** con la **B**. Edítalo (o copia el archivo
con otro nombre) y córrelo así:

    python3 torres.py mi_mapa.txt

Mientras más largo el camino, más tiempo tienen tus torres para disparar.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo:

```
torre1 = q
torre2 = w
torre3 = e
oleada = return
```

Nombres válidos: letras (`a`, `b`...), `space`, `return`, `tab`, números (`1`, `2`...).
Si escribes una tecla que no existe, el juego te avisa en la terminal y usa la de siempre.

## Para cambiar cosas

Arriba de `torres.py` están los ajustes: `VIDAS`, `MONEDAS_INICIO`, la tabla `TORRES`
(precio, daño, alcance, área), la tabla `ENEMIGOS` (vida, velocidad, monedas) y
`armar_oleada()`, que decide cuántos enemigos salen en cada oleada.
Cambia un número, guarda, y vuelve a correrlo.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
