"""
TORRES - un tower defense de Manu
==================================
Los enemigos (circulos) caminan por el camino hacia tu base. Tu pones torres
en el pasto, con el mouse, para detenerlos. Aguanta 10 oleadas y ganas.

Controles (se cambian en controles.txt):
    1 / 2 / 3     elegir tipo de torre        clic izquierdo   poner la torre
    ESPACIO       lanzar la siguiente oleada  clic derecho     vender una torre
    R             reiniciar                   ESC              salir

El mapa esta en camino.txt:
    .  pasto (aqui puedes construir)     =  camino
    S  donde salen los enemigos           B  tu base
    #  roca (no se puede construir)
Tu propio mapa:  python torres.py mi_mapa.txt
"""

import math
import os
import sys
from collections import deque

import pygame

# ------------------------------------------------------------------ AJUSTES
TILE = 40
ALTO_BARRA = 90               # la barra de abajo con las torres
FPS = 60
VIDAS = 10
MONEDAS_INICIO = 150
OLEADAS = 10
BONO_OLEADA = 30              # monedas de regalo al terminar una oleada
ESPERA_OLEADA = 15            # segundos hasta que la siguiente oleada sale sola
VIDA_EXTRA_POR_OLEADA = 0.35  # cada oleada los enemigos tienen 35% mas vida que la primera
FRAMES_ENTRE_ENEMIGOS = 20    # cada cuanto sale un enemigo de la oleada (60 = 1 s)

# Los 3 tipos de torre. Cambia numeros y prueba.
#   dano = cuanta vida quita cada disparo    espera = frames entre disparos (60 = 1 s)
#   alcance = hasta donde llega (pixeles)    area = radio de la explosion (0 = sin area)
TORRES = {
    1: {"nombre": "Rapida", "precio": 50, "dano": 6, "espera": 10, "alcance": 100, "area": 0,
        "color": (80, 200, 240)},
    2: {"nombre": "Fuerte", "precio": 90, "dano": 40, "espera": 50, "alcance": 150, "area": 0,
        "color": (240, 150, 50)},
    3: {"nombre": "Bomba", "precio": 120, "dano": 25, "espera": 90, "alcance": 120, "area": 65,
        "color": (190, 90, 230)},
}

# Los tipos de enemigo: vida, velocidad (pixeles por frame), monedas que dan, tamano
ENEMIGOS = {
    "normal": {"vida": 40, "vel": 1.6, "monedas": 8, "radio": 12, "color": (220, 70, 70)},
    "rapido": {"vida": 25, "vel": 3.0, "monedas": 10, "radio": 9, "color": (240, 220, 60)},
    "tanque": {"vida": 160, "vel": 0.9, "monedas": 25, "radio": 17, "color": (90, 90, 110)},
}


def armar_oleada(n):
    """Que enemigos salen en la oleada n (1 a 10). Cada oleada es mas dura."""
    lista = ["normal"] * (4 + n * 2)
    if n >= 3:
        lista += ["rapido"] * (n - 1)
    if n >= 5:
        lista += ["tanque"] * (n // 3)
    if n == OLEADAS:
        lista += ["tanque"] * 4 + ["rapido"] * 6
    return lista


# Colores
PASTO = (70, 140, 70)
PASTO_2 = (64, 130, 64)
CAMINO = (190, 165, 120)
ROCA = (110, 110, 115)
BASE = (60, 120, 220)
BLANCO = (245, 245, 245)
NEGRO = (15, 15, 20)

# ------------------------------------------------------------------ CONTROLES
CONTROLES_DEFECTO = {
    "torre1": "1", "torre2": "2", "torre3": "3",
    "oleada": "space", "reiniciar": "r", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una linea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}   # se llena en main(), despues de pygame.init()


# ------------------------------------------------------------------ MAPA
def cargar_mapa(ruta):
    with open(ruta, encoding="utf-8") as f:
        filas = [linea.rstrip("\n") for linea in f if linea.strip()]
    ancho = max(len(fila) for fila in filas)
    return [fila.ljust(ancho, ".") for fila in filas]


class Mapa:
    def __init__(self, filas):
        self.filas = filas
        self.alto = len(filas)
        self.ancho = len(filas[0])
        self.inicio = self.buscar("S")
        self.base = self.buscar("B")
        self.camino = self.armar_camino()   # lista de puntos (pixeles) que siguen los enemigos

    def buscar(self, letra):
        for cy, fila in enumerate(self.filas):
            if letra in fila:
                return (fila.index(letra), cy)
        raise SystemExit(f"Al mapa le falta la letra {letra}")

    def celda(self, cx, cy):
        if 0 <= cy < self.alto and 0 <= cx < self.ancho:
            return self.filas[cy][cx]
        return "#"

    def armar_camino(self):
        """Sigue el camino desde S hasta B (busqueda BFS por las casillas '=')."""
        anterior = {self.inicio: None}
        cola = deque([self.inicio])
        while cola:
            actual = cola.popleft()
            if actual == self.base:
                break
            cx, cy = actual
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                v = (cx + dx, cy + dy)
                if v not in anterior and self.celda(*v) in "=B":
                    anterior[v] = actual
                    cola.append(v)
        if self.base not in anterior:
            raise SystemExit("El camino '=' no conecta S con B")
        ruta = []
        paso = self.base
        while paso is not None:
            ruta.append((paso[0] * TILE + TILE / 2, paso[1] * TILE + TILE / 2))
            paso = anterior[paso]
        return ruta[::-1]

    def se_puede_construir(self, cx, cy):
        return self.celda(cx, cy) == "."


# ------------------------------------------------------------------ ENEMIGO
class Enemigo:
    def __init__(self, tipo, camino, oleada=1):
        d = ENEMIGOS[tipo]
        self.tipo = tipo
        self.vida_max = self.vida = int(d["vida"] * (1 + VIDA_EXTRA_POR_OLEADA * (oleada - 1)))
        self.vel = d["vel"]
        self.monedas = d["monedas"]
        self.radio = d["radio"]
        self.color = d["color"]
        self.camino = camino
        self.x, self.y = camino[0]
        self.indice = 1               # hacia que punto del camino voy
        self.llego = False
        self.avance = 0.0             # cuanto camino lleva (para saber quien va primero)

    def actualizar(self):
        if self.indice >= len(self.camino):
            self.llego = True
            return
        ox, oy = self.camino[self.indice]
        dx, dy = ox - self.x, oy - self.y
        dist = math.hypot(dx, dy)
        if dist <= self.vel:
            self.x, self.y = ox, oy
            self.indice += 1
        else:
            self.x += dx / dist * self.vel
            self.y += dy / dist * self.vel
        self.avance += self.vel

    @property
    def vivo(self):
        return self.vida > 0

    def dibujar(self, sup):
        x, y = int(self.x), int(self.y)
        pygame.draw.circle(sup, self.color, (x, y), self.radio)
        pygame.draw.circle(sup, NEGRO, (x, y), self.radio, 2)
        # barrita de vida
        ancho = self.radio * 2
        pygame.draw.rect(sup, (60, 20, 20), (x - self.radio, y - self.radio - 8, ancho, 4))
        pygame.draw.rect(sup, (80, 230, 80), (x - self.radio, y - self.radio - 8, int(ancho * self.vida / self.vida_max), 4))


# ------------------------------------------------------------------ TORRE
class Torre:
    def __init__(self, tipo, cx, cy):
        self.tipo = tipo
        self.datos = TORRES[tipo]
        self.cx, self.cy = cx, cy
        self.x = cx * TILE + TILE / 2
        self.y = cy * TILE + TILE / 2
        self.enfriando = 0
        self.angulo = 0.0
        self.disparos = 0

    def actualizar(self, enemigos, balas):
        if self.enfriando > 0:
            self.enfriando -= 1
        # apunta al enemigo que va mas adelante dentro del alcance
        objetivo = None
        for e in enemigos:
            if math.hypot(e.x - self.x, e.y - self.y) <= self.datos["alcance"]:
                if objetivo is None or e.avance > objetivo.avance:
                    objetivo = e
        if objetivo is None:
            return
        self.angulo = math.atan2(objetivo.y - self.y, objetivo.x - self.x)
        if self.enfriando == 0:
            balas.append(Bala(self, objetivo))
            self.enfriando = self.datos["espera"]
            self.disparos += 1

    def dibujar(self, sup, seleccionada=False):
        x, y = int(self.x), int(self.y)
        color = self.datos["color"]
        # base cuadrada y canon que gira
        pygame.draw.rect(sup, (50, 50, 60), (x - 14, y - 14, 28, 28), border_radius=5)
        pygame.draw.circle(sup, color, (x, y), 11)
        fx = x + math.cos(self.angulo) * 16
        fy = y + math.sin(self.angulo) * 16
        pygame.draw.line(sup, NEGRO, (x, y), (fx, fy), 6 if self.tipo != 1 else 3)
        if seleccionada:
            pygame.draw.circle(sup, BLANCO, (x, y), self.datos["alcance"], 1)


class Bala:
    VEL = 9

    def __init__(self, torre, objetivo):
        self.x, self.y = torre.x, torre.y
        self.objetivo = objetivo
        self.dano = torre.datos["dano"]
        self.area = torre.datos["area"]
        self.color = torre.datos["color"]
        self.llego = False

    def actualizar(self, enemigos, explosiones):
        # persigue al enemigo (o al ultimo lugar donde estaba si ya murio)
        ox, oy = self.objetivo.x, self.objetivo.y
        dx, dy = ox - self.x, oy - self.y
        dist = math.hypot(dx, dy)
        if dist <= self.VEL:
            self.llego = True
            if self.area:
                explosiones.append([ox, oy, self.area, 12])
                for e in enemigos:
                    if math.hypot(e.x - ox, e.y - oy) <= self.area:
                        e.vida -= self.dano
            elif self.objetivo.vivo:
                self.objetivo.vida -= self.dano
        else:
            self.x += dx / dist * self.VEL
            self.y += dy / dist * self.VEL

    def dibujar(self, sup):
        pygame.draw.circle(sup, self.color, (int(self.x), int(self.y)), 6 if self.area else 4)


# ------------------------------------------------------------------ JUEGO
class Juego:
    def __init__(self, ruta_mapa):
        self.ruta_mapa = ruta_mapa
        self.fuente = pygame.font.SysFont(None, 26)
        self.fuente_chica = pygame.font.SysFont(None, 20)
        self.fuente_grande = pygame.font.SysFont(None, 64)
        self.reiniciar()

    def reiniciar(self):
        self.mapa = Mapa(cargar_mapa(self.ruta_mapa))
        self.ancho = self.mapa.ancho * TILE
        self.alto = self.mapa.alto * TILE + ALTO_BARRA
        self.torres = {}            # (cx, cy) -> Torre
        self.enemigos = []
        self.balas = []
        self.explosiones = []       # [x, y, radio, frames]
        self.monedas = MONEDAS_INICIO
        self.vidas = VIDAS
        self.oleada = 0             # la ultima que salio
        self.por_salir = []         # enemigos que faltan por aparecer en esta oleada
        self.espera_aparecer = 0
        self.cuenta_regresiva = ESPERA_OLEADA * FPS
        self.tipo_elegido = 1
        self.estado = "jugando"     # "jugando", "ganaste", "perdiste"
        self.mensaje = "ESPACIO para lanzar la oleada 1"
        self.mensaje_hasta = 10 ** 9
        self.tiempo = 0

    # ---- acciones del jugador
    def lanzar_oleada(self):
        if self.estado != "jugando" or self.oleada >= OLEADAS or self.por_salir:
            return
        self.oleada += 1
        self.por_salir = armar_oleada(self.oleada)
        self.espera_aparecer = 0
        self.cuenta_regresiva = ESPERA_OLEADA * FPS
        self.avisar(f"¡Oleada {self.oleada}! Vienen {len(self.por_salir)} enemigos")

    def clic(self, pos, boton):
        if self.estado != "jugando":
            return
        x, y = pos
        if y >= self.mapa.alto * TILE:
            # clic en la barra de abajo: elegir torre
            for tipo, r in self.rects_barra().items():
                if r.collidepoint(pos):
                    self.tipo_elegido = tipo
            return
        cx, cy = x // TILE, y // TILE
        if boton == 1:
            self.construir(cx, cy)
        elif boton == 3:
            self.vender(cx, cy)

    def construir(self, cx, cy):
        precio = TORRES[self.tipo_elegido]["precio"]
        if (cx, cy) in self.torres:
            self.avisar("Ahi ya hay una torre (clic derecho para venderla)")
        elif not self.mapa.se_puede_construir(cx, cy):
            self.avisar("Solo puedes construir en el pasto")
        elif self.monedas < precio:
            self.avisar(f"Te faltan {precio - self.monedas} monedas")
        else:
            self.monedas -= precio
            self.torres[(cx, cy)] = Torre(self.tipo_elegido, cx, cy)

    def vender(self, cx, cy):
        torre = self.torres.pop((cx, cy), None)
        if torre:
            devuelto = torre.datos["precio"] // 2
            self.monedas += devuelto
            self.avisar(f"Torre vendida: +{devuelto} monedas")

    def tecla(self, key):
        if key == TECLA["reiniciar"]:
            self.reiniciar()
        elif self.estado != "jugando":
            return
        elif key == TECLA["oleada"]:
            self.lanzar_oleada()
        elif key == TECLA["torre1"]:
            self.tipo_elegido = 1
        elif key == TECLA["torre2"]:
            self.tipo_elegido = 2
        elif key == TECLA["torre3"]:
            self.tipo_elegido = 3

    def avisar(self, texto, segundos=3):
        self.mensaje = texto
        self.mensaje_hasta = self.tiempo + segundos * FPS

    # ---- logica
    def actualizar(self):
        if self.estado != "jugando":
            return
        self.tiempo += 1

        # aparecen los enemigos de la oleada, de a uno
        if self.por_salir:
            self.espera_aparecer -= 1
            if self.espera_aparecer <= 0:
                self.enemigos.append(Enemigo(self.por_salir.pop(0), self.mapa.camino, self.oleada))
                self.espera_aparecer = FRAMES_ENTRE_ENEMIGOS
        elif not self.enemigos and self.oleada > 0 and self.oleada < OLEADAS:
            # oleada terminada: cuenta regresiva para la siguiente
            if self.cuenta_regresiva == ESPERA_OLEADA * FPS:
                self.monedas += BONO_OLEADA
                self.avisar(f"Oleada {self.oleada} superada: +{BONO_OLEADA} monedas. ESPACIO o espera...", 6)
            self.cuenta_regresiva -= 1
            if self.cuenta_regresiva <= 0:
                self.lanzar_oleada()

        for e in self.enemigos:
            e.actualizar()
        for t in self.torres.values():
            t.actualizar(self.enemigos, self.balas)
        for b in self.balas:
            b.actualizar(self.enemigos, self.explosiones)
        self.balas = [b for b in self.balas if not b.llego]
        for ex in self.explosiones:
            ex[3] -= 1
        self.explosiones = [ex for ex in self.explosiones if ex[3] > 0]

        # enemigos muertos dan monedas; los que llegan quitan vidas
        quedan = []
        for e in self.enemigos:
            if not e.vivo:
                self.monedas += e.monedas
            elif e.llego:
                self.vidas -= 1
            else:
                quedan.append(e)
        self.enemigos = quedan

        if self.vidas <= 0:
            self.vidas = 0
            self.estado = "perdiste"
        elif self.oleada == OLEADAS and not self.por_salir and not self.enemigos:
            self.estado = "ganaste"

    # ---- dibujo
    def rects_barra(self):
        y = self.mapa.alto * TILE + 10
        return {tipo: pygame.Rect(10 + (tipo - 1) * 150, y, 140, ALTO_BARRA - 20) for tipo in TORRES}

    def dibujar(self, pantalla):
        m = self.mapa
        for cy in range(m.alto):
            for cx in range(m.ancho):
                r = pygame.Rect(cx * TILE, cy * TILE, TILE, TILE)
                c = m.celda(cx, cy)
                if c in "=S":
                    pygame.draw.rect(pantalla, CAMINO, r)
                elif c == "B":
                    pygame.draw.rect(pantalla, CAMINO, r)
                    pygame.draw.rect(pantalla, BASE, r.inflate(-8, -8), border_radius=6)
                    pygame.draw.polygon(pantalla, BLANCO, [(r.centerx, r.top + 8), (r.right - 8, r.centery), (r.left + 8, r.centery)])
                elif c == "#":
                    pygame.draw.rect(pantalla, PASTO, r)
                    pygame.draw.circle(pantalla, ROCA, r.center, 14)
                    pygame.draw.circle(pantalla, (80, 80, 85), r.center, 14, 2)
                else:
                    pygame.draw.rect(pantalla, PASTO if (cx + cy) % 2 else PASTO_2, r)
        # entrada
        sx, sy = m.inicio
        pygame.draw.rect(pantalla, (120, 60, 40), (sx * TILE + 4, sy * TILE + 4, TILE - 8, TILE - 8), border_radius=6)

        # donde esta el mouse: sombra de la torre que vas a poner
        mx, my = pygame.mouse.get_pos()
        cx, cy = mx // TILE, my // TILE
        if self.estado == "jugando" and my < m.alto * TILE:
            datos = TORRES[self.tipo_elegido]
            ok = m.se_puede_construir(cx, cy) and (cx, cy) not in self.torres and self.monedas >= datos["precio"]
            color = (255, 255, 255) if ok else (255, 80, 80)
            centro = (cx * TILE + TILE // 2, cy * TILE + TILE // 2)
            pygame.draw.circle(pantalla, color, centro, datos["alcance"], 1)
            pygame.draw.rect(pantalla, color, (cx * TILE, cy * TILE, TILE, TILE), 2)

        for t in self.torres.values():
            t.dibujar(pantalla, seleccionada=(t.cx, t.cy) == (cx, cy))
        for e in self.enemigos:
            e.dibujar(pantalla)
        for b in self.balas:
            b.dibujar(pantalla)
        for x, y, radio, frames in self.explosiones:
            pygame.draw.circle(pantalla, (255, 200, 80), (int(x), int(y)), int(radio * (1 - frames / 24)), 3)

        self.dibujar_barra(pantalla)

        if self.estado == "ganaste":
            self.pantalla_final(pantalla, "¡GANASTE!", (80, 255, 120))
        elif self.estado == "perdiste":
            self.pantalla_final(pantalla, "PERDISTE", (255, 70, 70))

    def dibujar_barra(self, pantalla):
        y0 = self.mapa.alto * TILE
        pygame.draw.rect(pantalla, (30, 30, 40), (0, y0, self.ancho, ALTO_BARRA))
        for tipo, r in self.rects_barra().items():
            d = TORRES[tipo]
            elegido = tipo == self.tipo_elegido
            pygame.draw.rect(pantalla, (60, 60, 75) if elegido else (42, 42, 55), r, border_radius=8)
            pygame.draw.rect(pantalla, d["color"] if elegido else (90, 90, 100), r, 2, border_radius=8)
            pygame.draw.circle(pantalla, d["color"], (r.left + 22, r.centery), 11)
            nombre = pygame.key.name(TECLA[f"torre{tipo}"]).upper()
            self.texto(pantalla, f"[{nombre}] {d['nombre']}", self.fuente, BLANCO, (r.left + 42, r.top + 8))
            self.texto(pantalla, f"${d['precio']}  dano {d['dano']}", self.fuente_chica, (200, 200, 210), (r.left + 42, r.top + 32))
            extra = f"area {d['area']}" if d["area"] else f"cada {d['espera'] / FPS:.1f} s"
            self.texto(pantalla, extra, self.fuente_chica, (200, 200, 210), (r.left + 42, r.top + 50))
        # marcador a la derecha
        x = self.ancho - 10
        self.texto(pantalla, f"Monedas: {self.monedas}", self.fuente, (255, 220, 90), (x, y0 + 8), derecha=True)
        self.texto(pantalla, f"Vidas: {self.vidas}", self.fuente, (255, 120, 120), (x, y0 + 32), derecha=True)
        self.texto(pantalla, f"Oleada: {self.oleada}/{OLEADAS}", self.fuente, BLANCO, (x, y0 + 56), derecha=True)
        # mensaje
        if self.tiempo < self.mensaje_hasta and self.mensaje:
            self.texto(pantalla, self.mensaje, self.fuente, (255, 245, 200), (self.ancho // 2, 14), centrado=True, fondo=True)
        elif self.estado == "jugando" and not self.enemigos and not self.por_salir and 0 < self.oleada < OLEADAS:
            seg = self.cuenta_regresiva // FPS + 1
            self.texto(pantalla, f"Siguiente oleada en {seg} s (ESPACIO para ya)", self.fuente, (255, 245, 200), (self.ancho // 2, 14), centrado=True, fondo=True)

    def pantalla_final(self, pantalla, titulo, color):
        velo = pygame.Surface((self.ancho, self.alto), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 160))
        pantalla.blit(velo, (0, 0))
        cx, cy = self.ancho // 2, self.mapa.alto * TILE // 2
        self.texto(pantalla, titulo, self.fuente_grande, color, (cx, cy - 30), centrado=True)
        detalle = f"Llegaste a la oleada {self.oleada} con {len(self.torres)} torres"
        self.texto(pantalla, detalle, self.fuente, BLANCO, (cx, cy + 20), centrado=True)
        self.texto(pantalla, "R para jugar de nuevo  -  ESC para salir", self.fuente, (220, 220, 220), (cx, cy + 50), centrado=True)

    def texto(self, pantalla, cadena, fuente, color, pos, centrado=False, derecha=False, fondo=False):
        img = fuente.render(cadena, True, color)
        r = img.get_rect()
        if centrado:
            r.center = pos
        elif derecha:
            r.topright = pos
        else:
            r.topleft = pos
        if fondo:
            pygame.draw.rect(pantalla, (0, 0, 0, 150), r.inflate(16, 8), border_radius=6)
        pantalla.blit(img, r)


# ------------------------------------------------------------------ ARRANQUE
def main():
    global TECLA
    carpeta = os.path.dirname(os.path.abspath(__file__))
    ruta = sys.argv[1] if len(sys.argv) > 1 else os.path.join(carpeta, "camino.txt")
    pygame.init()
    TECLA = cargar_controles()
    juego = Juego(ruta)
    pantalla = pygame.display.set_mode((juego.ancho, juego.alto))
    pygame.display.set_caption("Torres")
    reloj = pygame.time.Clock()

    corriendo = True
    while corriendo:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == TECLA["salir"]:
                    corriendo = False
                else:
                    juego.tecla(evento.key)
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                juego.clic(evento.pos, evento.button)

        juego.actualizar()
        juego.dibujar(pantalla)
        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
