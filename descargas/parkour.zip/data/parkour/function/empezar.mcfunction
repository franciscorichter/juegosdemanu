# Arranca el reloj del jugador que ejecuta esto (@s)
scoreboard players set @s pk_estado 1
scoreboard players set @s pk_ticks 0
scoreboard players set @s pk_seg 0

# Guardar donde esta la placa de salida
execute store result score @s pk_x run data get entity @s Pos[0]
execute store result score @s pk_z run data get entity @s Pos[2]

title @s times 0 20 10
title @s title {"text":"¡YA!","color":"green","bold":true}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
