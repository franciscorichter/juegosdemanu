# Piso una placa de oro mientras corria. ¿Es la de salida o la meta?
execute store result score @s pk_cx run data get entity @s Pos[0]
execute store result score @s pk_cz run data get entity @s Pos[2]

# Si es otra placa distinta a la de salida -> es la meta
execute unless score @s pk_cx = @s pk_x run function parkour:terminar
execute if score @s pk_estado matches 2 unless score @s pk_cz = @s pk_z run function parkour:terminar
