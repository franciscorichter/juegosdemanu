# Se ejecuta una vez cuando carga el mundo (o con /reload)

# Estado de cada jugador: 0 = esperando, 1 = corriendo (todavia en la placa de salida),
# 2 = corriendo, 3 = ya termino (todavia parado en la placa de meta)
scoreboard objectives add pk_estado dummy

# Cuantos ticks lleva corriendo (20 ticks = 1 segundo)
scoreboard objectives add pk_ticks dummy

# Segundos y decimas, para mostrar bonito
scoreboard objectives add pk_seg dummy [{"text":"Parkour ","color":"gold"},{"text":"(segundos)","color":"gray"}]
scoreboard objectives add pk_dec dummy

# Mejor tiempo de cada jugador, en ticks (0 = todavia no tiene)
scoreboard objectives add pk_mejor dummy

# Donde esta la placa de salida, para no confundirla con la meta
scoreboard objectives add pk_x dummy
scoreboard objectives add pk_z dummy
scoreboard objectives add pk_cx dummy
scoreboard objectives add pk_cz dummy

# Un "jugador falso" que siempre vale 20, para dividir ticks entre 20
scoreboard players set #veinte pk_ticks 20
scoreboard players set #dos pk_ticks 2

# Mostrar los segundos a la derecha de la pantalla
scoreboard objectives setdisplay sidebar pk_seg

tellraw @a [{"text":"[Parkour] ","color":"gold"},{"text":"listo. Pisa una placa de presion de oro para empezar.","color":"gray"}]
