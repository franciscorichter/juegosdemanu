# Cancela tu carrera actual. Uso: /function parkour:reiniciar
scoreboard players set @s pk_estado 0
scoreboard players set @s pk_ticks 0
scoreboard players set @s pk_seg 0
tellraw @s [{"text":"[Parkour] ","color":"gold"},{"text":"carrera cancelada. Pisa la placa de salida para volver a empezar.","color":"gray"}]
