# Se ejecuta 20 veces por segundo

# Si alguien nuevo no tiene estado, ponerle 0
scoreboard players add @a pk_estado 0

# Estado 0 y pisa una placa de oro -> empezar
execute as @a[scores={pk_estado=0}] at @s if block ~ ~ ~ minecraft:light_weighted_pressure_plate run function parkour:empezar

# Estado 1 o 2 -> el reloj avanza un tick
execute as @a[scores={pk_estado=1..2}] run function parkour:contar

# Estado 1 y ya salio de la placa de salida -> estado 2
execute as @a[scores={pk_estado=1}] at @s unless block ~ ~ ~ minecraft:light_weighted_pressure_plate run scoreboard players set @s pk_estado 2

# Estado 2 y pisa una placa de oro -> ver si es la meta
execute as @a[scores={pk_estado=2}] at @s if block ~ ~ ~ minecraft:light_weighted_pressure_plate run function parkour:pisar_placa

# Estado 3 y ya se bajo de la placa de meta -> volver a 0 (puede correr otra vez)
execute as @a[scores={pk_estado=3}] at @s unless block ~ ~ ~ minecraft:light_weighted_pressure_plate run scoreboard players set @s pk_estado 0
