scoreboard players operation @s pk_mejor = @s pk_ticks
title @s subtitle {"text":"¡Nuevo record!","color":"aqua","bold":true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1

# Mostrar el record en el marcador como un "jugador" llamado Mejor
scoreboard players operation Mejor pk_seg = @s pk_mejor
scoreboard players operation Mejor pk_seg /= #veinte pk_ticks
