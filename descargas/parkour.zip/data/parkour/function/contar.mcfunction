# Un tick mas, y convertir a segundos para el marcador
scoreboard players add @s pk_ticks 1
scoreboard players operation @s pk_seg = @s pk_ticks
scoreboard players operation @s pk_seg /= #veinte pk_ticks
