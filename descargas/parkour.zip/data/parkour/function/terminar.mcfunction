# Parar el reloj
scoreboard players set @s pk_estado 3

# Decimas: (ticks % 20) / 2  -> un numero del 0 al 9
scoreboard players operation @s pk_dec = @s pk_ticks
scoreboard players operation @s pk_dec %= #veinte pk_ticks
scoreboard players operation @s pk_dec /= #dos pk_ticks

title @s times 0 60 20
title @s title [{"score":{"name":"@s","objective":"pk_seg"},"color":"gold"},{"text":".","color":"gold"},{"score":{"name":"@s","objective":"pk_dec"},"color":"gold"},{"text":" s","color":"gold"}]
tellraw @a [{"text":"[Parkour] ","color":"gold"},{"selector":"@s"},{"text":" termino en "},{"score":{"name":"@s","objective":"pk_seg"},"color":"yellow"},{"text":".","color":"yellow"},{"score":{"name":"@s","objective":"pk_dec"},"color":"yellow"},{"text":" segundos","color":"yellow"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1

# ¿Record? (si pk_mejor es 0 es que nunca ha terminado)
execute if score @s pk_mejor matches 0 run function parkour:record
execute if score @s pk_ticks < @s pk_mejor run function parkour:record
