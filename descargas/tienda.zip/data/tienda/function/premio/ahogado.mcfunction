# Premio por matar un drowned: 5 monedas
scoreboard players add @s monedas 5
title @s actionbar [{"text":"+5 monedas (drowned)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_ahogado
