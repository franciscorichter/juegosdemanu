# Regalo de bienvenida (una sola vez por jugador)
scoreboard players add @s monedas 50
tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"¡Bienvenido! Te regalo 50 monedas. Escribe ","color":"green"},{"text":"/trigger tienda","color":"yellow"},{"text":" para ver que puedes comprar.","color":"green"}]
