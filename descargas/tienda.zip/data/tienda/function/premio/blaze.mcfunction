# Premio por matar un blaze: 10 monedas
scoreboard players add @s monedas 10
title @s actionbar [{"text":"+10 monedas (blaze)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_blaze
