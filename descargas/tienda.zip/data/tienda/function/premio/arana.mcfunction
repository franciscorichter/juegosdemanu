# Premio por matar un spider: 4 monedas
scoreboard players add @s monedas 4
title @s actionbar [{"text":"+4 monedas (spider)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_arana
