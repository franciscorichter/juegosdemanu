# Premio por matar un enderman: 15 monedas
scoreboard players add @s monedas 15
title @s actionbar [{"text":"+15 monedas (enderman)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_enderman
