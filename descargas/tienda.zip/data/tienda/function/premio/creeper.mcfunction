# Premio por matar un creeper: 8 monedas
scoreboard players add @s monedas 8
title @s actionbar [{"text":"+8 monedas (creeper)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_creeper
