# Premio por matar un wither_skeleton: 12 monedas
scoreboard players add @s monedas 12
title @s actionbar [{"text":"+12 monedas (wither_skeleton)","color":"gold"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.5
# Quitar el logro para que se pueda ganar otra vez
advancement revoke @s only tienda:matar_wither_esqueleto
