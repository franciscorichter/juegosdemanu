scoreboard players remove @s monedas 300
give @s minecraft:diamond_sword[minecraft:enchantments={levels:{"minecraft:sharpness":2}}]
give @s minecraft:diamond_pickaxe[minecraft:enchantments={levels:{"minecraft:efficiency":3}}]
tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"compraste el Kit diamante. Te quedan ","color":"green"},{"score":{"name":"@s","objective":"monedas"},"color":"gold"},{"text":" monedas.","color":"green"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
