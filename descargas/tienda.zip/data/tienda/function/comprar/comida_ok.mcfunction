scoreboard players remove @s monedas 20
give @s minecraft:cooked_beef 16
give @s minecraft:golden_carrot 8
tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"compraste el Kit comida. Te quedan ","color":"green"},{"score":{"name":"@s","objective":"monedas"},"color":"gold"},{"text":" monedas.","color":"green"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
