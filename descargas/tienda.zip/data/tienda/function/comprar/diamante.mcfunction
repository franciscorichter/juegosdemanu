# Kit diamante: 300 monedas. Lo ejecuta el jugador que compro (@s)
# Si le alcanza: dar cosas y cobrar
execute if score @s monedas matches 300.. run function tienda:comprar/diamante_ok
# Si no le alcanza: decirle cuanto le falta
execute unless score @s monedas matches 300.. run scoreboard players set @s tienda_tmp 300
execute unless score @s monedas matches 300.. run scoreboard players operation @s tienda_tmp -= @s monedas
execute unless score @s monedas matches 300.. run tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"te faltan ","color":"red"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"red","bold":true},{"text":" monedas para el Kit diamante.","color":"red"}]
execute unless score @s monedas matches 300.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
