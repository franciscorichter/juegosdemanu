scoreboard players remove @s monedas 120
give @s minecraft:iron_helmet[minecraft:enchantments={levels:{"minecraft:protection":1}}]
give @s minecraft:iron_chestplate[minecraft:enchantments={levels:{"minecraft:protection":1}}]
give @s minecraft:iron_leggings[minecraft:enchantments={levels:{"minecraft:protection":1}}]
give @s minecraft:iron_boots[minecraft:enchantments={levels:{"minecraft:protection":1}}]
tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"compraste el Kit armadura. Te quedan ","color":"green"},{"score":{"name":"@s","objective":"monedas"},"color":"gold"},{"text":" monedas.","color":"green"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
