# Kit comida: 20 monedas. Lo ejecuta el jugador que compro (@s)
# Si le alcanza: dar cosas y cobrar
execute if score @s monedas matches 20.. run function tienda:comprar/comida_ok
# Si no le alcanza: decirle cuanto le falta
execute unless score @s monedas matches 20.. run scoreboard players set @s tienda_tmp 20
execute unless score @s monedas matches 20.. run scoreboard players operation @s tienda_tmp -= @s monedas
execute unless score @s monedas matches 20.. run tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"te faltan ","color":"red"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"red","bold":true},{"text":" monedas para el Kit comida.","color":"red"}]
execute unless score @s monedas matches 20.. run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.5
