scoreboard players remove @s monedas 60
give @s minecraft:iron_pickaxe
give @s minecraft:iron_axe
give @s minecraft:iron_shovel
give @s minecraft:iron_sword
tellraw @s [{"text":"[Tienda] ","color":"gold"},{"text":"compraste el Kit herramientas. Te quedan ","color":"green"},{"score":{"name":"@s","objective":"monedas"},"color":"gold"},{"text":" monedas.","color":"green"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
