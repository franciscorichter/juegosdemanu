# Se ejecuta al cargar el mundo (o con /reload)
scoreboard objectives add monedas dummy [{"text":"Monedas","color":"gold"}]
scoreboard objectives add tienda_tmp dummy
# Objetivos 'trigger': cualquier jugador puede usarlos con /trigger (sin ser operador)
scoreboard objectives add tienda trigger
scoreboard objectives add comprar trigger
# Contadores automaticos de bloques minados (Minecraft los sube solo)
scoreboard objectives add min_carbon minecraft.mined:minecraft.coal_ore
scoreboard objectives add min_carbon_ds minecraft.mined:minecraft.deepslate_coal_ore
scoreboard objectives add min_cobre minecraft.mined:minecraft.copper_ore
scoreboard objectives add min_cobre_ds minecraft.mined:minecraft.deepslate_copper_ore
scoreboard objectives add min_hierro minecraft.mined:minecraft.iron_ore
scoreboard objectives add min_hierro_ds minecraft.mined:minecraft.deepslate_iron_ore
scoreboard objectives add min_redstone minecraft.mined:minecraft.redstone_ore
scoreboard objectives add min_redstone_ds minecraft.mined:minecraft.deepslate_redstone_ore
scoreboard objectives add min_lapis minecraft.mined:minecraft.lapis_ore
scoreboard objectives add min_lapis_ds minecraft.mined:minecraft.deepslate_lapis_ore
scoreboard objectives add min_oro minecraft.mined:minecraft.gold_ore
scoreboard objectives add min_oro_ds minecraft.mined:minecraft.deepslate_gold_ore
scoreboard objectives add min_esmeralda minecraft.mined:minecraft.emerald_ore
scoreboard objectives add min_esmeralda_ds minecraft.mined:minecraft.deepslate_emerald_ore
scoreboard objectives add min_diamante minecraft.mined:minecraft.diamond_ore
scoreboard objectives add min_diamante_ds minecraft.mined:minecraft.deepslate_diamond_ore
scoreboard objectives add min_debris minecraft.mined:minecraft.ancient_debris
# Las monedas se ven en la lista de jugadores (tecla TAB)
scoreboard objectives setdisplay list monedas
tellraw @a [{"text":"[Tienda] ","color":"gold"},{"text":"lista. Escribe ","color":"gray"},{"text":"/trigger tienda","color":"yellow"},{"text":" para abrirla.","color":"gray"}]
