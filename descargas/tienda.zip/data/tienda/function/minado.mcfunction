# Cada mineral minado se convierte en monedas y el contador vuelve a 0
# coal_ore: 1 moneda(s) cada uno
execute as @a[scores={min_carbon=1..}] run scoreboard players operation @s tienda_tmp = @s min_carbon
execute as @a[scores={min_carbon=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_carbon=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_carbon
# deepslate_coal_ore: 1 moneda(s) cada uno
execute as @a[scores={min_carbon_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_carbon_ds
execute as @a[scores={min_carbon_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_carbon_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_carbon_ds
# copper_ore: 1 moneda(s) cada uno
execute as @a[scores={min_cobre=1..}] run scoreboard players operation @s tienda_tmp = @s min_cobre
execute as @a[scores={min_cobre=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_cobre=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_cobre
# deepslate_copper_ore: 1 moneda(s) cada uno
execute as @a[scores={min_cobre_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_cobre_ds
execute as @a[scores={min_cobre_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_cobre_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_cobre_ds
# iron_ore: 2 moneda(s) cada uno
execute as @a[scores={min_hierro=1..}] run scoreboard players operation @s tienda_tmp = @s min_hierro
execute as @a[scores={min_hierro=1..}] run scoreboard players set #valor tienda_tmp 2
execute as @a[scores={min_hierro=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_hierro=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_hierro=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_hierro
# deepslate_iron_ore: 2 moneda(s) cada uno
execute as @a[scores={min_hierro_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_hierro_ds
execute as @a[scores={min_hierro_ds=1..}] run scoreboard players set #valor tienda_tmp 2
execute as @a[scores={min_hierro_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_hierro_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_hierro_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_hierro_ds
# redstone_ore: 2 moneda(s) cada uno
execute as @a[scores={min_redstone=1..}] run scoreboard players operation @s tienda_tmp = @s min_redstone
execute as @a[scores={min_redstone=1..}] run scoreboard players set #valor tienda_tmp 2
execute as @a[scores={min_redstone=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_redstone=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_redstone=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_redstone
# deepslate_redstone_ore: 2 moneda(s) cada uno
execute as @a[scores={min_redstone_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_redstone_ds
execute as @a[scores={min_redstone_ds=1..}] run scoreboard players set #valor tienda_tmp 2
execute as @a[scores={min_redstone_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_redstone_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_redstone_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_redstone_ds
# lapis_ore: 3 moneda(s) cada uno
execute as @a[scores={min_lapis=1..}] run scoreboard players operation @s tienda_tmp = @s min_lapis
execute as @a[scores={min_lapis=1..}] run scoreboard players set #valor tienda_tmp 3
execute as @a[scores={min_lapis=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_lapis=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_lapis=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_lapis
# deepslate_lapis_ore: 3 moneda(s) cada uno
execute as @a[scores={min_lapis_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_lapis_ds
execute as @a[scores={min_lapis_ds=1..}] run scoreboard players set #valor tienda_tmp 3
execute as @a[scores={min_lapis_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_lapis_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_lapis_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_lapis_ds
# gold_ore: 3 moneda(s) cada uno
execute as @a[scores={min_oro=1..}] run scoreboard players operation @s tienda_tmp = @s min_oro
execute as @a[scores={min_oro=1..}] run scoreboard players set #valor tienda_tmp 3
execute as @a[scores={min_oro=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_oro=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_oro=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_oro
# deepslate_gold_ore: 3 moneda(s) cada uno
execute as @a[scores={min_oro_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_oro_ds
execute as @a[scores={min_oro_ds=1..}] run scoreboard players set #valor tienda_tmp 3
execute as @a[scores={min_oro_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_oro_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_oro_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_oro_ds
# emerald_ore: 8 moneda(s) cada uno
execute as @a[scores={min_esmeralda=1..}] run scoreboard players operation @s tienda_tmp = @s min_esmeralda
execute as @a[scores={min_esmeralda=1..}] run scoreboard players set #valor tienda_tmp 8
execute as @a[scores={min_esmeralda=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_esmeralda=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_esmeralda=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_esmeralda
# deepslate_emerald_ore: 8 moneda(s) cada uno
execute as @a[scores={min_esmeralda_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_esmeralda_ds
execute as @a[scores={min_esmeralda_ds=1..}] run scoreboard players set #valor tienda_tmp 8
execute as @a[scores={min_esmeralda_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_esmeralda_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_esmeralda_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_esmeralda_ds
# diamond_ore: 10 moneda(s) cada uno
execute as @a[scores={min_diamante=1..}] run scoreboard players operation @s tienda_tmp = @s min_diamante
execute as @a[scores={min_diamante=1..}] run scoreboard players set #valor tienda_tmp 10
execute as @a[scores={min_diamante=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_diamante=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_diamante=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_diamante
# deepslate_diamond_ore: 10 moneda(s) cada uno
execute as @a[scores={min_diamante_ds=1..}] run scoreboard players operation @s tienda_tmp = @s min_diamante_ds
execute as @a[scores={min_diamante_ds=1..}] run scoreboard players set #valor tienda_tmp 10
execute as @a[scores={min_diamante_ds=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_diamante_ds=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_diamante_ds=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_diamante_ds
# ancient_debris: 20 moneda(s) cada uno
execute as @a[scores={min_debris=1..}] run scoreboard players operation @s tienda_tmp = @s min_debris
execute as @a[scores={min_debris=1..}] run scoreboard players set #valor tienda_tmp 20
execute as @a[scores={min_debris=1..}] run scoreboard players operation @s tienda_tmp *= #valor tienda_tmp
execute as @a[scores={min_debris=1..}] run scoreboard players operation @s monedas += @s tienda_tmp
execute as @a[scores={min_debris=1..}] run title @s actionbar [{"text":"+","color":"gold"},{"score":{"name":"@s","objective":"tienda_tmp"},"color":"gold"},{"text":" monedas (mineral)","color":"gold"}]
scoreboard players reset @a min_debris
