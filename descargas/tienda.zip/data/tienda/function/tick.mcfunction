# Cada tick
# Dejar los triggers listos para que los jugadores puedan usarlos
scoreboard players enable @a tienda
scoreboard players enable @a comprar
# ¿Alguien abrio la tienda? (/trigger tienda)
execute as @a[scores={tienda=1..}] run function tienda:abrir
scoreboard players reset @a tienda
# ¿Alguien compro algo? (/trigger comprar set N)
execute as @a[scores={comprar=1}] run function tienda:comprar/comida
execute as @a[scores={comprar=2}] run function tienda:comprar/herramientas
execute as @a[scores={comprar=3}] run function tienda:comprar/armadura
execute as @a[scores={comprar=4}] run function tienda:comprar/diamante
scoreboard players reset @a comprar
# Convertir bloques minados en monedas
function tienda:minado
