"""
Tanques — batalla de tanques vista desde arriba, hecha con pygame.

Modos: 2 jugadores en el mismo teclado, o 1 jugador contra la computadora (IA).
Las arenas están en arena1.txt ... arena4.txt (puedes editarlas o hacer más).
Controles en controles.txt. Pausa con P.

Cómo está armado (de arriba a abajo):
  Ajustes → Controles → Sonidos → Arena → Partículas → Bala → Mina → PowerUp
  → Tanque → IA → Juego (una partida) → Menú → main()
"""
import os
import sys
import math
import array
import random
import collections

import pygame

# ---------- Ajustes (cámbialos y prueba) ----------
TAM = 40                 # tamaño de una casilla en píxeles
COLS, FILAS = 20, 14     # casillas de ancho y alto de cada arena
HUD = 70                 # franja de arriba con vidas y marcador
ANCHO, ALTO = COLS * TAM, FILAS * TAM + HUD
FPS = 60

VEL_TANQUE = 170         # píxeles por segundo, a fondo
ACELERACION = 420        # qué tan rápido agarra velocidad (la inercia)
FRENO = 300              # qué tan rápido frena solo cuando sueltas
VEL_GIRO = 170           # grados por segundo
VEL_BALA = 430
RECARGA = 0.45           # segundos entre disparos
VIDAS = 3
RONDAS_PARA_GANAR = 3    # al mejor de 5 = el primero que llega a 3
CADA_CUANTO_POWERUP = 7  # segundos
MAX_POWERUPS = 3

COLOR_J = {1: (70, 170, 255), 2: (255, 110, 70)}
NOMBRE_J = {1: "J1", 2: "J2"}
NOMBRES_DIFICULTAD = ["Patrulla", "Persigue", "Esquiva"]
NOMBRES_ARENA = ["Patio", "Rio", "Laberinto", "Isla"]


def carpeta():
    return os.path.dirname(os.path.abspath(__file__))


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "j1_adelante": "w", "j1_atras": "s", "j1_izquierda": "a", "j1_derecha": "d",
    "j1_disparar": "space", "j1_mina": "q",
    "j2_adelante": "up", "j2_atras": "down", "j2_izquierda": "left", "j2_derecha": "right",
    "j2_disparar": "return", "j2_mina": "right shift",
    "pausa": "p", "empezar": "return", "menu": "m", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(carpeta(), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}   # se llena en main(), después de pygame.init()


def nombre_tecla(accion):
    nombre = pygame.key.name(TECLA[accion])
    return {"return": "ENTER", "space": "ESPACIO", "escape": "ESC",
            "right shift": "SHIFT DER", "left shift": "SHIFT IZQ"}.get(nombre, nombre.upper())


# ---------- Sonidos fabricados con matemáticas ----------
class Sonidos:
    """Cada sonido es una lista de números (la onda) que le pasamos a pygame.
    Si el computador no tiene audio, simplemente no suena nada (self.ok = False)."""

    def __init__(self):
        self.ok = False
        self.lista = {}
        try:
            pygame.mixer.quit()
            pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
            self.frec = pygame.mixer.get_init()[0]
            self.lista = {
                "disparo": self._armar(self._tono_bajando(700, 200, 0.12, 0.35, ruido=0.3)),
                "rebote": self._armar(self._beep(1500, 0.05, 0.25)),
                "ladrillo": self._armar(self._ruido(0.15, 0.4)),
                "golpe": self._armar(self._tono_bajando(300, 60, 0.3, 0.6, ruido=0.5)),
                "explosion": self._armar(self._tono_bajando(200, 30, 0.7, 0.8, ruido=0.8)),
                "powerup": self._armar(self._beep(660, 0.08) + self._beep(880, 0.08) + self._beep(1320, 0.12)),
                "mina": self._armar(self._beep(440, 0.06, 0.3) + self._silencio(0.04) + self._beep(440, 0.06, 0.3)),
                "ronda": self._armar(self._beep(523, 0.15) + self._beep(659, 0.15) + self._beep(784, 0.3)),
            }
            self.ok = True
        except pygame.error as e:
            print("Sin sonido:", e)

    def tocar(self, nombre):
        if self.ok and nombre in self.lista:
            try:
                self.lista[nombre].play()
            except pygame.error:
                pass

    # --- generadores: devuelven listas de números entre -1 y 1 ---
    def _beep(self, hz, seg, volumen=0.5):
        n = int(self.frec * seg)
        return [volumen * math.sin(2 * math.pi * hz * i / self.frec) * min(1.0, (n - i) / (n * 0.3))
                for i in range(n)]

    def _tono_bajando(self, hz_inicio, hz_fin, seg, volumen=0.5, ruido=0.0):
        n = int(self.frec * seg)
        muestras, fase = [], 0.0
        for i in range(n):
            hz = hz_inicio + (hz_fin - hz_inicio) * i / n
            fase += 2 * math.pi * hz / self.frec
            onda = math.sin(fase)
            if ruido:
                onda = onda * (1 - ruido) + random.uniform(-1, 1) * ruido
            muestras.append(volumen * onda * (1 - i / n))
        return muestras

    def _ruido(self, seg, volumen=0.4):
        n = int(self.frec * seg)
        return [volumen * random.uniform(-1, 1) * (1 - i / n) for i in range(n)]

    def _silencio(self, seg):
        return [0.0] * int(self.frec * seg)

    def _armar(self, muestras):
        """Convierte los números en un Sound de pygame (enteros de 16 bits)."""
        datos = array.array("h")
        for m in muestras:
            datos.append(int(max(-1.0, min(1.0, m)) * 32767))
        return pygame.mixer.Sound(buffer=datos.tobytes())


class SinSonido:
    ok = False

    def tocar(self, nombre):
        pass


# ---------- Arena (el mapa, leído de un .txt) ----------
class Arena:
    """Cada casilla es una letra: # muro, L ladrillo, A agua, B arbusto, . piso.
    1 y 2 son donde empiezan los tanques."""

    def __init__(self, ruta):
        self.nombre = os.path.basename(ruta)
        filas = []
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.rstrip("\n")
                if not linea or linea.startswith("# "):   # comentario
                    continue
                filas.append(linea)
        self.celdas = []
        self.inicio = {}
        for fila in range(FILAS):
            texto = filas[fila] if fila < len(filas) else ""
            texto = (texto + "#" * COLS)[:COLS]
            columna = []
            for col, c in enumerate(texto):
                if c in "12":
                    self.inicio[int(c)] = (col * TAM + TAM / 2, fila * TAM + TAM / 2)
                    c = "."
                if c not in "#LAB.":
                    c = "."
                columna.append(c)
            self.celdas.append(columna)
        self.inicio.setdefault(1, (TAM * 1.5, TAM * 1.5))
        self.inicio.setdefault(2, ((COLS - 1.5) * TAM, (FILAS - 1.5) * TAM))
        self.escombros = []   # ladrillos rotos recién (para partículas)

    def celda(self, col, fila):
        if 0 <= col < COLS and 0 <= fila < FILAS:
            return self.celdas[fila][col]
        return "#"

    def celda_en(self, x, y):
        return self.celda(int(x // TAM), int(y // TAM))

    def romper(self, col, fila):
        if self.celda(col, fila) == "L":
            self.celdas[fila][col] = "."
            self.escombros.append((col * TAM + TAM / 2, fila * TAM + TAM / 2))
            return True
        return False

    @staticmethod
    def frena_tanque(c):
        return c in "#LA"

    @staticmethod
    def frena_bala(c):
        return c in "#L"

    def tanque_cabe(self, x, y, radio):
        """¿Un círculo en (x, y) está libre de muros, ladrillos y agua?"""
        col0, fila0 = int(x // TAM), int(y // TAM)
        for fila in range(fila0 - 1, fila0 + 2):
            for col in range(col0 - 1, col0 + 2):
                if self.frena_tanque(self.celda(col, fila)):
                    # punto del rectángulo más cercano al centro del círculo
                    cx = max(col * TAM, min(x, col * TAM + TAM))
                    cy = max(fila * TAM, min(y, fila * TAM + TAM))
                    if (cx - x) ** 2 + (cy - y) ** 2 < radio * radio:
                        return False
        return True

    def casillas_libres(self):
        return [(c, f) for f in range(FILAS) for c in range(COLS) if self.celdas[f][c] == "."]

    def camino(self, desde, hasta):
        """Busca el camino más corto entre dos casillas (col, fila) andando solo
        por piso y arbustos. Es una búsqueda 'en anchura': mira los vecinos,
        luego los vecinos de los vecinos... hasta llegar. Devuelve la lista de
        casillas, o [] si no hay forma."""
        if desde == hasta:
            return [hasta]
        cola = collections.deque([desde])
        de_donde = {desde: None}
        while cola:
            actual = cola.popleft()
            for dc, df in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                vecino = (actual[0] + dc, actual[1] + df)
                if vecino in de_donde or self.frena_tanque(self.celda(*vecino)):
                    continue
                # no cortar esquinas en diagonal: los dos lados deben ser libres
                de_donde[vecino] = actual
                if vecino == hasta:
                    ruta = [hasta]
                    while de_donde[ruta[-1]] is not None:
                        ruta.append(de_donde[ruta[-1]])
                    return ruta[::-1]
                cola.append(vecino)
        return []

    def linea_libre(self, x1, y1, x2, y2):
        """¿Una bala podría ir derecho de un punto al otro sin chocar?"""
        d = math.hypot(x2 - x1, y2 - y1)
        pasos = max(1, int(d / 8))
        for i in range(pasos + 1):
            t = i / pasos
            if self.frena_bala(self.celda_en(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)):
                return False
        return True

    # --- dibujo ---
    def dibujar_suelo(self, pantalla, tiempo):
        for fila in range(FILAS):
            for col in range(COLS):
                c = self.celdas[fila][col]
                r = pygame.Rect(col * TAM, fila * TAM + HUD, TAM, TAM)
                if c == "#":
                    pygame.draw.rect(pantalla, (95, 95, 105), r)
                    pygame.draw.rect(pantalla, (130, 130, 140), r.inflate(-10, -10), 2)
                elif c == "L":
                    pygame.draw.rect(pantalla, (170, 80, 50), r)
                    for y in (r.top + 10, r.top + 20, r.top + 30):
                        pygame.draw.line(pantalla, (110, 50, 30), (r.left, y), (r.right, y), 2)
                    pygame.draw.line(pantalla, (110, 50, 30), (r.centerx, r.top), (r.centerx, r.top + 10), 2)
                    pygame.draw.line(pantalla, (110, 50, 30), (r.left + 10, r.top + 10), (r.left + 10, r.top + 20), 2)
                    pygame.draw.line(pantalla, (110, 50, 30), (r.right - 10, r.top + 10), (r.right - 10, r.top + 20), 2)
                    pygame.draw.line(pantalla, (110, 50, 30), (r.centerx, r.top + 20), (r.centerx, r.top + 30), 2)
                elif c == "A":
                    onda = int(12 * math.sin(tiempo * 2 + col + fila))
                    pygame.draw.rect(pantalla, (40, 90 + onda, 200 + onda // 2), r)
                    y = r.top + 20 + int(6 * math.sin(tiempo * 3 + col))
                    pygame.draw.line(pantalla, (120, 170, 255), (r.left + 6, y), (r.left + 20, y), 2)
                else:
                    tono = 150 if (col + fila) % 2 else 140
                    pygame.draw.rect(pantalla, (tono, tono + 20, 100), r)

    def dibujar_arbustos(self, pantalla):
        """Se dibujan DESPUÉS de los tanques para que los tapen."""
        for fila in range(FILAS):
            for col in range(COLS):
                if self.celdas[fila][col] == "B":
                    cx, cy = col * TAM + TAM // 2, fila * TAM + HUD + TAM // 2
                    for dx, dy, rad in ((-9, -8, 13), (10, -6, 12), (0, 9, 13), (-11, 8, 10), (11, 9, 10), (0, -2, 11)):
                        pygame.draw.circle(pantalla, (30, 110, 40), (cx + dx, cy + dy), rad)
                        pygame.draw.circle(pantalla, (50, 150, 60), (cx + dx - 3, cy + dy - 3), rad // 2)


# ---------- Partículas (explosiones, chispas, humo) ----------
class Particula:
    def __init__(self, x, y, color, velocidad, vida, tamano=3, gravedad=0):
        ang = random.uniform(0, 2 * math.pi)
        v = random.uniform(velocidad * 0.3, velocidad)
        self.x, self.y = x, y
        self.vx, self.vy = math.cos(ang) * v, math.sin(ang) * v
        self.color = color
        self.vida = self.vida_total = random.uniform(vida * 0.5, vida)
        self.tamano = tamano
        self.gravedad = gravedad

    def actualizar(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravedad * dt
        self.vx *= 0.97
        self.vy *= 0.97
        self.vida -= dt
        return self.vida > 0

    def dibujar(self, pantalla):
        t = self.tamano * self.vida / self.vida_total
        if t >= 1:
            pygame.draw.circle(pantalla, self.color, (int(self.x), int(self.y + HUD)), int(t))


def explosion(lista, x, y, color, cantidad=30, fuerza=220, vida=0.8, tamano=5):
    for _ in range(cantidad):
        lista.append(Particula(x, y, color, fuerza, vida, tamano))
    for _ in range(cantidad // 3):
        lista.append(Particula(x, y, (255, 230, 120), fuerza * 0.6, vida * 0.6, tamano))
    for _ in range(cantidad // 3):
        lista.append(Particula(x, y, (70, 70, 70), fuerza * 0.3, vida * 1.6, tamano + 2))


# ---------- Bala ----------
class Bala:
    RADIO = 4

    def __init__(self, x, y, angulo, duenio):
        rad = math.radians(angulo)
        self.x, self.y = x, y
        self.vx, self.vy = math.cos(rad) * VEL_BALA, math.sin(rad) * VEL_BALA
        self.duenio = duenio      # el tanque que la disparó
        self.rebotes = 1          # cuántas veces más puede rebotar en un muro
        self.edad = 0.0
        self.viva = True

    def actualizar(self, dt, arena, sonidos, particulas):
        self.edad += dt
        if self.edad > 3.0:
            self.viva = False
            return
        # primero muevo en x y miro qué hay; después en y. Así sé de qué lado choqué.
        nx = self.x + self.vx * dt
        if self._choca(nx, self.y, arena, sonidos, particulas):
            self.vx = -self.vx
        else:
            self.x = nx
        if not self.viva:
            return
        ny = self.y + self.vy * dt
        if self._choca(self.x, ny, arena, sonidos, particulas):
            self.vy = -self.vy
        else:
            self.y = ny

    def _choca(self, x, y, arena, sonidos, particulas):
        """Devuelve True si en (x, y) hay algo sólido. Se encarga del rebote y de romper ladrillos."""
        c = arena.celda_en(x, y)
        if c == "L":
            arena.romper(int(x // TAM), int(y // TAM))
            cx, cy = int(x // TAM) * TAM + TAM / 2, int(y // TAM) * TAM + TAM / 2
            for _ in range(14):
                particulas.append(Particula(cx, cy, (170, 80, 50), 160, 0.7, 4, gravedad=300))
            sonidos.tocar("ladrillo")
            self.viva = False
            return True
        if c == "#":
            if self.rebotes > 0:
                self.rebotes -= 1
                sonidos.tocar("rebote")
                for _ in range(5):
                    particulas.append(Particula(self.x, self.y, (255, 240, 150), 120, 0.3, 2))
            else:
                self.viva = False
                for _ in range(6):
                    particulas.append(Particula(self.x, self.y, (200, 200, 200), 100, 0.3, 2))
            return True
        return False

    def dibujar(self, pantalla):
        pygame.draw.circle(pantalla, (255, 240, 180), (int(self.x), int(self.y + HUD)), self.RADIO)
        pygame.draw.circle(pantalla, (255, 160, 40), (int(self.x), int(self.y + HUD)), self.RADIO - 2)


# ---------- Mina ----------
class Mina:
    RADIO_ACTIVA = 22    # a esta distancia un tanque la hace explotar
    RADIO_DANIO = 55     # hasta aquí llega el daño

    def __init__(self, x, y, duenio):
        self.x, self.y = x, y
        self.duenio = duenio
        self.armada_en = 1.2     # segundos hasta que se activa (para que el dueño se aleje)
        self.viva = True

    def actualizar(self, dt):
        self.armada_en -= dt

    def dibujar(self, pantalla, tiempo):
        pos = (int(self.x), int(self.y + HUD))
        pygame.draw.circle(pantalla, (60, 60, 60), pos, 9)
        if self.armada_en <= 0 and int(tiempo * 4) % 2 == 0:
            pygame.draw.circle(pantalla, (255, 40, 40), pos, 3)
        else:
            pygame.draw.circle(pantalla, (120, 120, 120), pos, 3)


# ---------- Power-ups ----------
TIPOS_POWERUP = ["escudo", "triple", "velocidad", "mina"]
COLOR_POWERUP = {"escudo": (80, 200, 255), "triple": (255, 200, 60), "velocidad": (120, 255, 120), "mina": (230, 90, 230)}
LETRA_POWERUP = {"escudo": "E", "triple": "3", "velocidad": "V", "mina": "M"}


class PowerUp:
    RADIO = 14

    def __init__(self, x, y, tipo):
        self.x, self.y, self.tipo = x, y, tipo
        self.vida = 15.0

    def actualizar(self, dt):
        self.vida -= dt
        return self.vida > 0

    def dibujar(self, pantalla, fuente, tiempo):
        if self.vida < 3 and int(tiempo * 6) % 2 == 0:
            return    # parpadea antes de irse
        pos = (int(self.x), int(self.y + HUD + 3 * math.sin(tiempo * 4)))
        pygame.draw.circle(pantalla, (255, 255, 255), pos, self.RADIO + 2)
        pygame.draw.circle(pantalla, COLOR_POWERUP[self.tipo], pos, self.RADIO)
        letra = fuente.render(LETRA_POWERUP[self.tipo], True, (20, 20, 20))
        pantalla.blit(letra, letra.get_rect(center=pos))


# ---------- Tanque ----------
class Tanque:
    RADIO = 15

    def __init__(self, num, arena):
        self.num = num
        self.color = COLOR_J[num]
        self.arena = arena
        self.reiniciar_posicion()
        self.vidas = VIDAS
        self.recarga = 0.0
        self.escudo = 0.0       # segundos de escudo que quedan (0 = sin escudo)
        self.triple = 0.0
        self.rapido = 0.0
        self.minas = 0
        self.invulnerable = 0.0
        self.disparos = 0       # cuenta de balas disparadas (lo usan las pruebas)
        self.vivo = True

    def reiniciar_posicion(self):
        self.x, self.y = self.arena.inicio[self.num]
        self.angulo = 0 if self.num == 1 else 180
        self.vel = 0.0

    @property
    def casilla(self):
        return (int(self.x // TAM), int(self.y // TAM))

    def actualizar(self, dt, acel, giro, otros):
        """acel: 1 adelante, -1 atrás, 0 nada. giro: 1 derecha (horario), -1 izquierda."""
        for nombre in ("recarga", "escudo", "triple", "rapido", "invulnerable"):
            setattr(self, nombre, max(0.0, getattr(self, nombre) - dt))
        vel_max = VEL_TANQUE * (1.6 if self.rapido > 0 else 1.0)
        if acel > 0:
            self.vel = min(vel_max, self.vel + ACELERACION * dt)
        elif acel < 0:
            self.vel = max(-vel_max * 0.6, self.vel - ACELERACION * dt)
        else:
            # inercia: sigue un poco y va frenando solo
            if self.vel > 0:
                self.vel = max(0.0, self.vel - FRENO * dt)
            else:
                self.vel = min(0.0, self.vel + FRENO * dt)
        self.angulo = (self.angulo + giro * VEL_GIRO * dt) % 360
        rad = math.radians(self.angulo)
        nx = self.x + math.cos(rad) * self.vel * dt
        ny = self.y + math.sin(rad) * self.vel * dt
        chocado = False
        if self.cabe(nx, self.y, otros):
            self.x = nx
        else:
            chocado = True
        if self.cabe(self.x, ny, otros):
            self.y = ny
        else:
            chocado = True
        if chocado:
            self.vel *= -0.2    # rebota un poquito
        return chocado

    def cabe(self, x, y, otros):
        if not (self.RADIO <= x <= ANCHO - self.RADIO and self.RADIO <= y <= FILAS * TAM - self.RADIO):
            return False
        if not self.arena.tanque_cabe(x, y, self.RADIO):
            return False
        for o in otros:
            if o is not self and o.vivo and math.hypot(o.x - x, o.y - y) < self.RADIO * 2:
                return False
        return True

    def punta(self):
        rad = math.radians(self.angulo)
        return self.x + math.cos(rad) * (self.RADIO + 6), self.y + math.sin(rad) * (self.RADIO + 6)

    def disparar(self, balas, sonidos, particulas):
        if self.recarga > 0 or not self.vivo:
            return False
        self.recarga = RECARGA
        px, py = self.punta()
        angulos = [self.angulo]
        if self.triple > 0:
            angulos = [self.angulo - 15, self.angulo, self.angulo + 15]
        for a in angulos:
            balas.append(Bala(px, py, a, self))
        for _ in range(6):
            particulas.append(Particula(px, py, (255, 200, 80), 150, 0.25, 3))
        self.disparos += 1
        sonidos.tocar("disparo")
        return True

    def poner_mina(self, minas, sonidos):
        if self.minas <= 0 or not self.vivo:
            return False
        self.minas -= 1
        rad = math.radians(self.angulo)
        minas.append(Mina(self.x - math.cos(rad) * 22, self.y - math.sin(rad) * 22, self))
        sonidos.tocar("mina")
        return True

    def recibir_golpe(self, particulas, sonidos):
        """Devuelve True si de verdad perdió una vida."""
        if not self.vivo or self.invulnerable > 0:
            return False
        if self.escudo > 0:
            self.escudo = 0
            for _ in range(20):
                particulas.append(Particula(self.x, self.y, (80, 200, 255), 200, 0.5, 4))
            sonidos.tocar("rebote")
            return False
        self.vidas -= 1
        if self.vidas <= 0:
            self.vivo = False
            explosion(particulas, self.x, self.y, self.color, 70, 320, 1.4, 7)
            sonidos.tocar("explosion")
        else:
            explosion(particulas, self.x, self.y, self.color, 25, 200, 0.7, 5)
            sonidos.tocar("golpe")
            self.invulnerable = 2.0
            self.triple = self.rapido = 0.0
        return True

    def agarrar(self, powerup, sonidos):
        if powerup.tipo == "escudo":
            self.escudo = 10.0
        elif powerup.tipo == "triple":
            self.triple = 10.0
        elif powerup.tipo == "velocidad":
            self.rapido = 8.0
        elif powerup.tipo == "mina":
            self.minas = min(3, self.minas + 1)
        sonidos.tocar("powerup")

    def dibujar(self, pantalla, tiempo, escondido=False):
        if not self.vivo:
            return
        if self.invulnerable > 0 and int(tiempo * 10) % 2 == 0:
            return    # parpadea mientras no se le puede pegar
        s = pygame.Surface((44, 44), pygame.SRCALPHA)
        c = self.color
        oscuro = (c[0] // 2, c[1] // 2, c[2] // 2)
        # orugas (las bandas de los lados)
        pygame.draw.rect(s, (40, 40, 40), (8, 6, 28, 8), border_radius=2)
        pygame.draw.rect(s, (40, 40, 40), (8, 30, 28, 8), border_radius=2)
        paso = int(tiempo * abs(self.vel) / 6) % 6
        for i in range(5):
            x = 10 + i * 6 + paso
            if x < 34:
                pygame.draw.line(s, (90, 90, 90), (x, 7), (x, 13), 1)
                pygame.draw.line(s, (90, 90, 90), (x, 31), (x, 37), 1)
        # cuerpo
        pygame.draw.rect(s, c, (9, 12, 26, 20), border_radius=4)
        pygame.draw.rect(s, oscuro, (9, 12, 26, 20), 2, border_radius=4)
        # torreta y cañón (apuntan a la derecha; luego se gira todo)
        pygame.draw.rect(s, oscuro, (22, 19, 20, 6))
        pygame.draw.circle(s, c, (22, 22), 8)
        pygame.draw.circle(s, oscuro, (22, 22), 8, 2)
        if self.rapido > 0:
            pygame.draw.circle(s, (120, 255, 120), (14, 22), 3)
        if self.triple > 0:
            pygame.draw.rect(s, (255, 200, 60), (22, 15, 20, 3))
            pygame.draw.rect(s, (255, 200, 60), (22, 26, 20, 3))
        girado = pygame.transform.rotate(s, -self.angulo)
        if escondido:
            girado.set_alpha(110)
        pantalla.blit(girado, girado.get_rect(center=(int(self.x), int(self.y + HUD))))
        if self.escudo > 0:
            r = self.RADIO + 6 + int(2 * math.sin(tiempo * 8))
            pygame.draw.circle(pantalla, (80, 200, 255), (int(self.x), int(self.y + HUD)), r, 2)


# ---------- IA (el tanque de la computadora) ----------
def diferencia_angulo(a, b):
    """Cuánto hay que girar desde a hasta b, entre -180 y 180."""
    return (b - a + 180) % 360 - 180


class IA:
    """Nivel 1 Patrulla: da vueltas al azar y dispara si te tiene enfrente.
    Nivel 2 Persigue: busca el camino hasta ti y dispara cuando te ve.
    Nivel 3 Esquiva: como 2, pero se quita de las balas, agarra power-ups y apunta mejor."""

    def __init__(self, nivel, yo, enemigo):
        self.nivel = max(1, min(3, nivel))
        self.yo, self.enemigo = yo, enemigo
        self.angulo_objetivo = random.uniform(0, 360)
        self.reloj_cambio = 0.0
        self.reloj_camino = 0.0
        self.camino = []
        self.recarga = random.uniform(0.5, 1.5)
        self.atascado = 0.0
        self.reversa = 0.0

    def decidir(self, juego, dt):
        """Devuelve (acel, giro, disparar, poner_mina), lo mismo que haría un jugador con el teclado."""
        yo, en = self.yo, self.enemigo
        acel, disparar, mina = 1, False, False
        self.recarga -= dt
        self.reloj_cambio -= dt
        self.reloj_camino -= dt
        self.reversa = max(0.0, self.reversa - dt)
        ve_enemigo = en.vivo and juego.visible(yo, en)
        dist_en = math.hypot(en.x - yo.x, en.y - yo.y)
        ang_en = math.degrees(math.atan2(en.y - yo.y, en.x - yo.x))

        objetivo = None
        # --- 1. esquivar balas (solo nivel 3) ---
        if self.nivel >= 3:
            objetivo = self._esquivar(juego.balas)
        # --- 2. si está atascado, retrocede un momento ---
        if objetivo is None and self.reversa > 0:
            acel = -1
            objetivo = self.angulo_objetivo
        # --- 3. moverse ---
        if objetivo is None:
            if self.nivel == 1:
                if self.reloj_cambio <= 0:
                    self.angulo_objetivo = random.uniform(0, 360)
                    self.reloj_cambio = random.uniform(1.5, 3.0)
                objetivo = self.angulo_objetivo
                # si te tiene más o menos enfrente y cerca, gira hacia ti (aunque haya muros)
                if en.vivo and dist_en < 380 and abs(diferencia_angulo(yo.angulo, ang_en)) < 50:
                    objetivo, acel = ang_en, 0
            else:
                objetivo, acel = self._perseguir(juego, ve_enemigo, dist_en, ang_en)

        # girar hacia el objetivo
        diff = diferencia_angulo(yo.angulo, objetivo)
        giro = 1 if diff > 5 else (-1 if diff < -5 else 0)
        if acel > 0 and abs(diff) > 70:
            acel = 0    # primero gira, después avanza

        # --- 4. disparar ---
        umbral = {1: 14, 2: 9, 3: 6}[self.nivel]
        if en.vivo and self.recarga <= 0:
            apuntado = abs(diferencia_angulo(yo.angulo, ang_en)) < umbral
            if self.nivel == 1:
                puede = apuntado and dist_en < 380       # dispara aunque haya muros
            elif self.nivel == 2:
                puede = apuntado and (ve_enemigo or not self.camino)   # sin camino: rompe ladrillos a tiros
            else:
                puede = apuntado and (ve_enemigo or (not self.camino and dist_en < 300))
            if puede:
                disparar = True
                self.recarga = {1: 1.3, 2: 0.9, 3: 0.55}[self.nivel] + random.uniform(0, 0.3)

        # --- 5. minas: las deja caer cuando el enemigo lo viene siguiendo ---
        if yo.minas > 0 and self.nivel >= 2 and 90 < dist_en < 260 and random.random() < 0.4 * dt:
            mina = True

        # --- 6. detectar que no avanza ---
        if acel != 0 and abs(yo.vel) < 8:
            self.atascado += dt
        else:
            self.atascado = 0.0
        if self.atascado > 0.5:
            self.atascado = 0.0
            self.angulo_objetivo = (yo.angulo + random.choice((-90, 90, 180)) + random.uniform(-30, 30)) % 360
            self.reversa = 0.5
            self.reloj_cambio = 1.5
            self.reloj_camino = 0.0
        return acel, giro, disparar, mina

    def _esquivar(self, balas):
        yo = self.yo
        for b in balas:
            if b.duenio is yo and b.edad < 0.4:
                continue
            rx, ry = yo.x - b.x, yo.y - b.y
            d = math.hypot(rx, ry)
            if d > 230 or d == 0:
                continue
            vlen = math.hypot(b.vx, b.vy)
            ux, uy = b.vx / vlen, b.vy / vlen
            acercando = rx * ux + ry * uy          # positivo = viene hacia mí
            lateral = rx * uy - ry * ux            # de qué lado paso
            if acercando > 0 and abs(lateral) < 45:
                ang_bala = math.degrees(math.atan2(uy, ux))
                # me muevo perpendicular a la bala, hacia el lado donde ya estoy un poco
                return (ang_bala + (90 if lateral >= 0 else -90)) % 360
        return None

    def _perseguir(self, juego, ve_enemigo, dist_en, ang_en):
        yo, en = self.yo, self.enemigo
        # si ya lo veo y está cerca, me quedo quieto apuntando
        if ve_enemigo and dist_en < 200:
            return ang_en, 0
        destino = en.casilla
        if self.nivel >= 3:
            cerca = [p for p in juego.powerups if math.hypot(p.x - yo.x, p.y - yo.y) < 280]
            if cerca:
                p = min(cerca, key=lambda p: math.hypot(p.x - yo.x, p.y - yo.y))
                destino = (int(p.x // TAM), int(p.y // TAM))
        if self.reloj_camino <= 0:
            self.reloj_camino = 0.4
            self.camino = juego.arena.camino(yo.casilla, destino)
        # saco las casillas que ya pasé
        while len(self.camino) > 1 and math.hypot(self.camino[0][0] * TAM + TAM / 2 - yo.x,
                                                 self.camino[0][1] * TAM + TAM / 2 - yo.y) < 14:
            self.camino.pop(0)
        if not self.camino:
            # no hay camino (agua o ladrillos en medio): apunto al enemigo y avanzo
            return ang_en, (1 if not ve_enemigo else 0)
        cx, cy = self.camino[0][0] * TAM + TAM / 2, self.camino[0][1] * TAM + TAM / 2
        return math.degrees(math.atan2(cy - yo.y, cx - yo.x)), 1


# ---------- Juego (una partida completa: varias rondas) ----------
class Juego:
    def __init__(self, ruta_arena, modo, dificultad, sonidos=None):
        self.ruta_arena = ruta_arena
        self.modo = modo               # 1 = contra la IA, 2 = dos jugadores
        self.dificultad = dificultad
        self.sonidos = sonidos or SinSonido()
        self.rondas = {1: 0, 2: 0}
        self.numero_ronda = 0
        self.ganador = None
        self.tiempo = 0.0
        self.nueva_ronda()

    def nueva_ronda(self):
        self.arena = Arena(self.ruta_arena)
        self.tanques = [Tanque(1, self.arena), Tanque(2, self.arena)]
        self.ia = IA(self.dificultad, self.tanques[1], self.tanques[0]) if self.modo == 1 else None
        self.balas, self.minas, self.powerups, self.particulas = [], [], [], []
        self.reloj_powerup = CADA_CUANTO_POWERUP * 0.6
        self.numero_ronda += 1
        self.estado = "jugando"        # o "fin_ronda" o "fin_partida"
        self.temporizador = 0.0
        self.mensaje = ""

    def tanque(self, num):
        return self.tanques[num - 1]

    def visible(self, quien, a_quien):
        """¿'quien' puede ver a 'a_quien'? No si hay muro en medio, ni si está
        en un arbusto (salvo muy cerca)."""
        if self.arena.celda_en(a_quien.x, a_quien.y) == "B" and math.hypot(a_quien.x - quien.x, a_quien.y - quien.y) > 70:
            return False
        return self.arena.linea_libre(quien.x, quien.y, a_quien.x, a_quien.y)

    def ordenes_teclado(self, teclas):
        """Convierte las teclas apretadas en órdenes (acel, giro, disparar) por tanque."""
        ordenes = {}
        for num in (1, 2):
            if num == 2 and self.modo == 1:
                continue
            p = f"j{num}_"
            acel = (1 if teclas[TECLA[p + "adelante"]] else 0) - (1 if teclas[TECLA[p + "atras"]] else 0)
            giro = (1 if teclas[TECLA[p + "derecha"]] else 0) - (1 if teclas[TECLA[p + "izquierda"]] else 0)
            ordenes[num] = (acel, giro, bool(teclas[TECLA[p + "disparar"]]), False)
        return ordenes

    def paso(self, dt, ordenes):
        """Avanza el juego dt segundos. ordenes = {1: (acel, giro, disparar, mina), 2: ...}"""
        self.tiempo += dt
        self.particulas = [p for p in self.particulas if p.actualizar(dt)]
        if self.estado != "jugando":
            self.temporizador -= dt
            if self.temporizador <= 0 and self.estado == "fin_ronda":
                self.nueva_ronda()
            return
        if self.ia is not None:
            ordenes = dict(ordenes)
            ordenes[2] = self.ia.decidir(self, dt)
        # tanques
        for t in self.tanques:
            acel, giro, disparar, mina = ordenes.get(t.num, (0, 0, False, False))
            if not t.vivo:
                continue
            t.actualizar(dt, acel, giro, self.tanques)
            if disparar:
                t.disparar(self.balas, self.sonidos, self.particulas)
            if mina:
                t.poner_mina(self.minas, self.sonidos)
        # balas
        for b in self.balas:
            b.actualizar(dt, self.arena, self.sonidos, self.particulas)
            if not b.viva:
                continue
            for t in self.tanques:
                if not t.vivo or (b.duenio is t and b.edad < 0.2):
                    continue
                if math.hypot(t.x - b.x, t.y - b.y) < t.RADIO + b.RADIO:
                    b.viva = False
                    t.recibir_golpe(self.particulas, self.sonidos)
                    break
        # balas que chocan entre ellas se anulan
        for i, a in enumerate(self.balas):
            for b in self.balas[i + 1:]:
                if a.viva and b.viva and math.hypot(a.x - b.x, a.y - b.y) < a.RADIO * 2:
                    a.viva = b.viva = False
                    for _ in range(8):
                        self.particulas.append(Particula(a.x, a.y, (255, 255, 200), 150, 0.3, 3))
        self.balas = [b for b in self.balas if b.viva]
        # minas
        for m in self.minas:
            m.actualizar(dt)
            if m.armada_en > 0:
                continue
            for t in self.tanques:
                if t.vivo and math.hypot(t.x - m.x, t.y - m.y) < m.RADIO_ACTIVA + t.RADIO:
                    m.viva = False
                    explosion(self.particulas, m.x, m.y, (230, 90, 230), 40, 260, 0.9, 6)
                    self.sonidos.tocar("explosion")
                    for t2 in self.tanques:
                        if t2.vivo and math.hypot(t2.x - m.x, t2.y - m.y) < m.RADIO_DANIO:
                            t2.recibir_golpe(self.particulas, self.sonidos)
                    break
        self.minas = [m for m in self.minas if m.viva]
        # power-ups
        self.reloj_powerup -= dt
        if self.reloj_powerup <= 0:
            self.reloj_powerup = CADA_CUANTO_POWERUP
            if len(self.powerups) < MAX_POWERUPS:
                self.crear_powerup()
        self.powerups = [p for p in self.powerups if p.actualizar(dt)]
        for p in self.powerups:
            for t in self.tanques:
                if t.vivo and math.hypot(t.x - p.x, t.y - p.y) < t.RADIO + p.RADIO:
                    p.vida = 0
                    t.agarrar(p, self.sonidos)
                    break
        self.powerups = [p for p in self.powerups if p.vida > 0]
        # ¿alguien murió?
        muertos = [t for t in self.tanques if not t.vivo]
        if muertos:
            vivos = [t for t in self.tanques if t.vivo]
            self.estado = "fin_ronda"
            self.temporizador = 2.5
            if len(vivos) == 1:
                g = vivos[0].num
                self.rondas[g] += 1
                self.mensaje = f"Ronda {self.numero_ronda} para {NOMBRE_J[g]}"
                if self.rondas[g] >= RONDAS_PARA_GANAR:
                    self.estado = "fin_partida"
                    self.ganador = g
                    self.mensaje = f"¡Gana {NOMBRE_J[g]}!  {self.rondas[1]} - {self.rondas[2]}"
            else:
                self.mensaje = "¡Empate! Se repite la ronda"
            self.sonidos.tocar("ronda")

    def crear_powerup(self):
        libres = [(c, f) for c, f in self.arena.casillas_libres()
                  if all(math.hypot(c * TAM + TAM / 2 - t.x, f * TAM + TAM / 2 - t.y) > 100 for t in self.tanques)]
        if not libres:
            return
        c, f = random.choice(libres)
        self.powerups.append(PowerUp(c * TAM + TAM / 2, f * TAM + TAM / 2, random.choice(TIPOS_POWERUP)))

    # --- dibujo ---
    def dibujar(self, pantalla, fuentes):
        pantalla.fill((20, 20, 30))
        self.arena.dibujar_suelo(pantalla, self.tiempo)
        for m in self.minas:
            m.dibujar(pantalla, self.tiempo)
        for p in self.powerups:
            p.dibujar(pantalla, fuentes["chica"], self.tiempo)
        for t in self.tanques:
            t.dibujar(pantalla, self.tiempo, escondido=self.arena.celda_en(t.x, t.y) == "B")
        for b in self.balas:
            b.dibujar(pantalla)
        self.arena.dibujar_arbustos(pantalla)
        for p in self.particulas:
            p.dibujar(pantalla)
        self.dibujar_hud(pantalla, fuentes)
        if self.estado != "jugando":
            sombra = pygame.Surface((ANCHO, ALTO - HUD), pygame.SRCALPHA)
            sombra.fill((0, 0, 0, 120))
            pantalla.blit(sombra, (0, HUD))
            texto = fuentes["grande"].render(self.mensaje, True, (255, 255, 255))
            pantalla.blit(texto, texto.get_rect(center=(ANCHO // 2, ALTO // 2)))
            if self.estado == "fin_partida":
                t2 = fuentes["media"].render(f"{nombre_tecla('empezar')} para volver al menú", True, (220, 220, 220))
                pantalla.blit(t2, t2.get_rect(center=(ANCHO // 2, ALTO // 2 + 50)))

    def dibujar_hud(self, pantalla, fuentes):
        pygame.draw.rect(pantalla, (30, 30, 45), (0, 0, ANCHO, HUD))
        pygame.draw.line(pantalla, (80, 80, 110), (0, HUD - 1), (ANCHO, HUD - 1), 2)
        for t in self.tanques:
            x0 = 15 if t.num == 1 else ANCHO - 15
            lado = 1 if t.num == 1 else -1
            nombre = fuentes["media"].render(NOMBRE_J[t.num] + (" (IA)" if t.num == 2 and self.ia else ""), True, t.color)
            r = nombre.get_rect(topleft=(x0, 8)) if t.num == 1 else nombre.get_rect(topright=(x0, 8))
            pantalla.blit(nombre, r)
            for i in range(VIDAS):
                cx = x0 + lado * (10 + i * 22)
                color = t.color if i < t.vidas else (60, 60, 70)
                pygame.draw.circle(pantalla, color, (cx, 48), 8)
            # iconos de power-ups activos
            iconos = []
            if t.escudo > 0:
                iconos.append(("E", COLOR_POWERUP["escudo"]))
            if t.triple > 0:
                iconos.append(("3", COLOR_POWERUP["triple"]))
            if t.rapido > 0:
                iconos.append(("V", COLOR_POWERUP["velocidad"]))
            for _ in range(t.minas):
                iconos.append(("M", COLOR_POWERUP["mina"]))
            for i, (letra, color) in enumerate(iconos):
                cx = x0 + lado * (90 + i * 26)
                pygame.draw.circle(pantalla, color, (cx, 48), 11)
                l = fuentes["chica"].render(letra, True, (20, 20, 20))
                pantalla.blit(l, l.get_rect(center=(cx, 48)))
        marcador = fuentes["grande"].render(f"{self.rondas[1]}  -  {self.rondas[2]}", True, (255, 255, 255))
        pantalla.blit(marcador, marcador.get_rect(center=(ANCHO // 2, 26)))
        ronda = fuentes["chica"].render(f"Ronda {self.numero_ronda}  ·  primero a {RONDAS_PARA_GANAR}", True, (170, 170, 190))
        pantalla.blit(ronda, ronda.get_rect(center=(ANCHO // 2, 54)))


# ---------- Menú ----------
class Menu:
    def __init__(self):
        self.modo = 1          # 1 = vs IA, 2 = dos jugadores
        self.arena = 0         # índice 0..3
        self.dificultad = 2    # 1..3
        self.fila = 0          # qué opción está marcada
        self.arenas = self.buscar_arenas()

    @staticmethod
    def buscar_arenas():
        rutas = []
        for i in range(1, 100):
            r = os.path.join(carpeta(), f"arena{i}.txt")
            if os.path.exists(r):
                rutas.append(r)
        return rutas

    def nombre_arena(self, i):
        return NOMBRES_ARENA[i] if i < len(NOMBRES_ARENA) else os.path.basename(self.arenas[i])

    def tecla(self, k):
        """Devuelve True si hay que empezar a jugar."""
        arriba = k in (TECLA["j1_adelante"], TECLA["j2_adelante"])
        abajo = k in (TECLA["j1_atras"], TECLA["j2_atras"])
        izq = k in (TECLA["j1_izquierda"], TECLA["j2_izquierda"])
        der = k in (TECLA["j1_derecha"], TECLA["j2_derecha"])
        if arriba:
            self.fila = (self.fila - 1) % 3
        elif abajo:
            self.fila = (self.fila + 1) % 3
        elif izq or der:
            paso = 1 if der else -1
            if self.fila == 0:
                self.modo = 3 - self.modo
            elif self.fila == 1:
                self.arena = (self.arena + paso) % len(self.arenas)
            elif self.fila == 2:
                self.dificultad = (self.dificultad - 1 + paso) % 3 + 1
        elif k == TECLA["empezar"]:
            return True
        return False

    def dibujar(self, pantalla, fuentes, tiempo):
        pantalla.fill((20, 20, 30))
        titulo = fuentes["titulo"].render("TANQUES", True, (255, 220, 80))
        pantalla.blit(titulo, titulo.get_rect(center=(ANCHO // 2, 70)))
        sub = fuentes["chica"].render("batalla vista desde arriba · al mejor de 5 rondas", True, (170, 170, 190))
        pantalla.blit(sub, sub.get_rect(center=(ANCHO // 2, 115)))
        opciones = [
            ("Modo", "1 jugador contra la IA" if self.modo == 1 else "2 jugadores"),
            ("Arena", f"{self.arena + 1}. {self.nombre_arena(self.arena)}"),
            ("Dificultad", f"{self.dificultad}. {NOMBRES_DIFICULTAD[self.dificultad - 1]}" + ("" if self.modo == 1 else "  (solo vs IA)")),
        ]
        for i, (nombre, valor) in enumerate(opciones):
            y = 175 + i * 50
            marcada = i == self.fila
            color = (255, 255, 255) if marcada else (150, 150, 170)
            if marcada:
                pygame.draw.rect(pantalla, (45, 45, 70), (60, y - 20, 420, 42), border_radius=8)
                flecha = fuentes["media"].render("<", True, (255, 220, 80))
                pantalla.blit(flecha, flecha.get_rect(center=(200, y)))
                flecha = fuentes["media"].render(">", True, (255, 220, 80))
                pantalla.blit(flecha, flecha.get_rect(center=(460, y)))
            t = fuentes["media"].render(nombre, True, color)
            pantalla.blit(t, t.get_rect(midleft=(75, y)))
            t = fuentes["media"].render(valor, True, color)
            pantalla.blit(t, t.get_rect(midleft=(215, y)))
        # vista chiquita de la arena
        try:
            arena = Arena(self.arenas[self.arena])
            mini = 12
            ox, oy = ANCHO - 60 - COLS * mini, 160
            colores = {"#": (95, 95, 105), "L": (170, 80, 50), "A": (40, 90, 200), "B": (30, 110, 40), ".": (145, 165, 100)}
            for f in range(FILAS):
                for c in range(COLS):
                    pygame.draw.rect(pantalla, colores[arena.celdas[f][c]], (ox + c * mini, oy + f * mini, mini, mini))
            for num, (x, y) in arena.inicio.items():
                pygame.draw.circle(pantalla, COLOR_J[num], (int(ox + x / TAM * mini), int(oy + y / TAM * mini)), 5)
        except (OSError, IndexError):
            pass
        y = 350
        lineas = [
            f"{nombre_tecla('empezar')} para empezar   ·   P pausa   ·   {nombre_tecla('salir')} salir",
            "",
            f"J1:  {nombre_tecla('j1_adelante')} {nombre_tecla('j1_izquierda')} {nombre_tecla('j1_atras')} {nombre_tecla('j1_derecha')} mueve  ·  "
            f"{nombre_tecla('j1_disparar')} dispara  ·  {nombre_tecla('j1_mina')} mina",
            f"J2:  {nombre_tecla('j2_adelante')} {nombre_tecla('j2_izquierda')} {nombre_tecla('j2_atras')} {nombre_tecla('j2_derecha')} mueve  ·  "
            f"{nombre_tecla('j2_disparar')} dispara  ·  {nombre_tecla('j2_mina')} mina",
            "",
            "Power-ups:  E escudo   3 triple disparo   V velocidad   M mina",
            "Las balas rebotan una vez en los muros. Los ladrillos se rompen.",
            "Los arbustos te esconden. El agua no se cruza. 3 vidas por ronda.",
        ]
        for linea in lineas:
            if linea:
                t = fuentes["chica"].render(linea, True, (200, 200, 220))
                pantalla.blit(t, t.get_rect(center=(ANCHO // 2, y)))
            y += 24
        if int(tiempo * 2) % 2 == 0:
            t = fuentes["media"].render("¡Listos!", True, (255, 220, 80))
            pantalla.blit(t, t.get_rect(center=(ANCHO // 2, ALTO - 40)))


def cargar_fuentes():
    return {
        "titulo": pygame.font.Font(None, 80),
        "grande": pygame.font.Font(None, 48),
        "media": pygame.font.Font(None, 32),
        "chica": pygame.font.Font(None, 22),
    }


# ---------- El programa principal ----------
def main():
    pygame.init()
    TECLA.update(cargar_controles())
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Tanques")
    reloj = pygame.time.Clock()
    fuentes = cargar_fuentes()
    sonidos = Sonidos()
    menu = Menu()
    if not menu.arenas:
        print("No encontré ninguna arena (arena1.txt...). Ponlas al lado de tanques.py")
        return
    juego = None
    pausa = False
    tiempo = 0.0

    while True:
        dt = min(reloj.tick(FPS) / 1000, 0.05)   # segundos desde el cuadro anterior
        tiempo += dt
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                return
            if evento.type == pygame.KEYDOWN:
                k = evento.key
                if k == TECLA["salir"]:
                    if juego is None:
                        pygame.quit()
                        return
                    juego, pausa = None, False
                elif juego is None:
                    if menu.tecla(k):
                        juego = Juego(menu.arenas[menu.arena], menu.modo, menu.dificultad, sonidos)
                        pausa = False
                elif k == TECLA["pausa"]:
                    pausa = not pausa
                elif k == TECLA["menu"]:
                    juego, pausa = None, False
                elif juego.estado == "fin_partida" and k == TECLA["empezar"]:
                    juego = None
                elif not pausa:
                    if k == TECLA["j1_mina"]:
                        juego.tanque(1).poner_mina(juego.minas, sonidos)
                    if k == TECLA["j2_mina"] and juego.modo == 2:
                        juego.tanque(2).poner_mina(juego.minas, sonidos)

        if juego is None:
            menu.dibujar(pantalla, fuentes, tiempo)
        else:
            if not pausa:
                juego.paso(dt, juego.ordenes_teclado(pygame.key.get_pressed()))
            juego.dibujar(pantalla, fuentes)
            if pausa:
                sombra = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
                sombra.fill((0, 0, 0, 140))
                pantalla.blit(sombra, (0, 0))
                t = fuentes["grande"].render("PAUSA", True, (255, 255, 255))
                pantalla.blit(t, t.get_rect(center=(ANCHO // 2, ALTO // 2 - 20)))
                t = fuentes["media"].render(f"{nombre_tecla('pausa')} sigue  ·  {nombre_tecla('menu')} menú", True, (200, 200, 220))
                pantalla.blit(t, t.get_rect(center=(ANCHO // 2, ALTO // 2 + 30)))
        pygame.display.flip()


if __name__ == "__main__":
    main()
