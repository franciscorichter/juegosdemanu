"""Pruebas de Tanques sin ventana ni audio. Correr: python3 probar.py"""
import os
import sys
import math
import random

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame
import tanques as T

pygame.init()
T.TECLA.update(T.cargar_controles())
pantalla = pygame.display.set_mode((T.ANCHO, T.ALTO))
fuentes = T.cargar_fuentes()
sonidos = T.Sonidos()          # con el driver dummy debería armar los sonidos igual
DT = 1 / 60
fallos = 0


def prueba(nombre):
    def envoltura(f):
        global fallos
        try:
            f()
            print(f"  OK   {nombre}")
        except Exception as e:
            fallos += 1
            print(f"  FALLO {nombre}: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
        return f
    return envoltura


def arenas():
    return T.Menu.buscar_arenas()


def ordenes_al_azar():
    return {n: (random.choice((1, 1, 0, -1)), random.choice((-1, 0, 1)), random.random() < 0.3, random.random() < 0.02)
            for n in (1, 2)}


@prueba("hay 4 arenas de 20x14 con salidas 1 y 2 conectadas")
def _():
    lista = arenas()
    assert len(lista) >= 4, lista
    for ruta in lista:
        a = T.Arena(ruta)
        assert len(a.celdas) == T.FILAS and all(len(f) == T.COLS for f in a.celdas)
        c1 = (int(a.inicio[1][0] // T.TAM), int(a.inicio[1][1] // T.TAM))
        c2 = (int(a.inicio[2][0] // T.TAM), int(a.inicio[2][1] // T.TAM))
        assert a.camino(c1, c2), f"{ruta}: no hay camino entre 1 y 2 (con los ladrillos puestos)"
        assert any("L" in f for f in a.celdas) and any("#" in f for f in a.celdas), ruta


for ruta in arenas():
    for modo, dif in ((2, 1), (1, 1), (1, 2), (1, 3)):
        etiqueta = f"5 s en {os.path.basename(ruta)} modo={'2 jugadores' if modo == 2 else 'vs IA nivel ' + str(dif)}"

        @prueba(etiqueta)
        def _(ruta=ruta, modo=modo, dif=dif):
            random.seed(hash((ruta, modo, dif)) & 0xffff)
            j = T.Juego(ruta, modo, dif, sonidos)
            for _ in range(int(5 / DT)):
                j.paso(DT, ordenes_al_azar())
                j.dibujar(pantalla, fuentes)
            assert j.tiempo >= 5 - 1e-6


@prueba("la bala rebota una vez en un muro y a la segunda desaparece")
def _():
    a = T.Arena(arenas()[0])
    parts = []
    # bala en el centro de la casilla (1,1) yendo a la izquierda: pared en la columna 0
    b = T.Bala(1.5 * T.TAM, 1.5 * T.TAM, 180, None)
    for _ in range(60):
        b.actualizar(DT, a, T.SinSonido(), parts)
        if b.vx > 0:
            break
    assert b.viva and b.vx > 0 and b.rebotes == 0, (b.viva, b.vx, b.rebotes)
    b.vx = -abs(b.vx)    # la mando de nuevo contra el muro
    for _ in range(60):
        b.actualizar(DT, a, T.SinSonido(), parts)
        if not b.viva:
            break
    assert not b.viva, "la bala no debería rebotar dos veces"


@prueba("la bala rompe un ladrillo (L pasa a .)")
def _():
    a = T.Arena(arenas()[0])
    col, fila = next((c, f) for f in range(T.FILAS) for c in range(T.COLS) if a.celdas[f][c] == "L")
    # la pongo justo a la izquierda del ladrillo si ahí hay piso, si no, arriba
    if a.celda(col - 1, fila) == ".":
        b = T.Bala((col - 0.5) * T.TAM, (fila + 0.5) * T.TAM, 0, None)
    else:
        b = T.Bala((col + 0.5) * T.TAM, (fila - 0.5) * T.TAM, 90, None)
    parts = []
    for _ in range(60):
        b.actualizar(DT, a, T.SinSonido(), parts)
        if not b.viva:
            break
    assert a.celdas[fila][col] == ".", a.celdas[fila][col]
    assert not b.viva and parts, "la bala debe morir y soltar escombros"


@prueba("la IA dispara cuando tiene al jugador enfrente (los 3 niveles)")
def _():
    for nivel in (1, 2, 3):
        j = T.Juego(arenas()[0], 1, nivel, T.SinSonido())
        j1, ia = j.tanque(1), j.tanque(2)
        # los pongo en la misma fila con piso libre en medio (fila 1 de la arena 1)
        j1.x, j1.y = 3.5 * T.TAM, 1.5 * T.TAM
        ia.x, ia.y = 7.5 * T.TAM, 1.5 * T.TAM
        ia.angulo = 180
        assert j.visible(ia, j1)
        for _ in range(int(3 / DT)):
            j.paso(DT, {1: (0, 0, False, False)})
            if ia.disparos > 0:
                break
        assert ia.disparos > 0, f"la IA nivel {nivel} nunca disparó"
        assert any(b.duenio is ia for b in j.balas) or ia.disparos > 0


@prueba("la IA nivel 3 se mueve cuando le viene una bala")
def _():
    j = T.Juego(arenas()[0], 1, 3, T.SinSonido())
    ia = j.tanque(2)
    ia.x, ia.y, ia.angulo = 9.5 * T.TAM, 4.5 * T.TAM, 0
    j.tanque(1).x, j.tanque(1).y = 1.5 * T.TAM, 12.5 * T.TAM
    b = T.Bala(ia.x - 150, ia.y, 0, j.tanque(1))
    j.balas.append(b)
    acel, giro, _, _ = j.ia.decidir(j, DT)
    assert giro != 0 or acel != 0, "debería intentar quitarse"
    assert j.ia._esquivar(j.balas) is not None


@prueba("un tanque pierde vidas, el escudo aguanta un golpe y la ronda termina")
def _():
    j = T.Juego(arenas()[0], 2, 1, T.SinSonido())
    t = j.tanque(1)
    t.escudo = 5
    assert not t.recibir_golpe(j.particulas, j.sonidos) and t.vidas == T.VIDAS and t.escudo == 0
    t.invulnerable = 0
    for _ in range(T.VIDAS):
        t.invulnerable = 0
        t.recibir_golpe(j.particulas, j.sonidos)
    assert not t.vivo
    j.paso(DT, {})
    assert j.estado == "fin_ronda" and j.rondas[2] == 1, (j.estado, j.rondas)


@prueba("power-ups y minas")
def _():
    j = T.Juego(arenas()[0], 2, 1, T.SinSonido())
    t = j.tanque(1)
    for tipo in T.TIPOS_POWERUP:
        t.agarrar(T.PowerUp(0, 0, tipo), j.sonidos)
    assert t.escudo > 0 and t.triple > 0 and t.rapido > 0 and t.minas == 1
    t.disparar(j.balas, j.sonidos, j.particulas)
    assert len(j.balas) == 3, "triple disparo = 3 balas"
    assert t.poner_mina(j.minas, j.sonidos) and len(j.minas) == 1 and t.minas == 0
    j.crear_powerup()
    assert len(j.powerups) == 1


@prueba("los tanques tienen inercia (siguen un poco al soltar) y chocan con muros")
def _():
    j = T.Juego(arenas()[0], 2, 1, T.SinSonido())
    t = j.tanque(1)
    for _ in range(30):
        t.actualizar(DT, 1, 0, j.tanques)
    v = t.vel
    assert v > 50
    t.actualizar(DT, 0, 0, j.tanques)
    assert 0 < t.vel < v, "al soltar debe seguir moviéndose pero frenando"
    t.angulo = 180
    for _ in range(120):
        t.actualizar(DT, 1, 0, j.tanques)
    assert t.x >= t.RADIO and j.arena.tanque_cabe(t.x, t.y, t.RADIO), "no debe meterse en el muro"


@prueba("el menú se dibuja y cambia opciones")
def _():
    m = T.Menu()
    m.dibujar(pantalla, fuentes, 0.0)
    m.tecla(T.TECLA["j2_derecha"]); assert m.modo == 2
    m.tecla(T.TECLA["j2_atras"]); m.tecla(T.TECLA["j2_derecha"]); assert m.arena == 1
    assert m.tecla(T.TECLA["empezar"])


print()
print("Sonido armado:", sonidos.ok)
if fallos:
    print(f"{fallos} prueba(s) fallaron")
    sys.exit(1)
print("Todas las pruebas pasaron")
