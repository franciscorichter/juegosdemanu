# Tanques

Batalla de tanques vista desde arriba, hecha en Python con pygame.
Dos jugadores en el mismo teclado, o uno contra la computadora (IA).
Gana el primero que se lleve 3 rondas (al mejor de 5).

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 tanques.py

En Windows: `python tanques.py`. En Linux/Mac también sirve `./jugar.sh`.

En el menú eliges con las flechas (o WASD): **modo** (1 jugador vs IA o 2 jugadores),
**arena** (4 para elegir) y **dificultad** de la IA. ENTER empieza. **P** pausa. **ESC** sale.

| Acción     | Jugador 1 | Jugador 2 |
|------------|-----------|-----------|
| Avanzar    | W         | Flecha arriba |
| Retroceder | S         | Flecha abajo |
| Girar      | A / D     | Flecha izq / der |
| Disparar   | ESPACIO   | ENTER |
| Poner mina | Q         | SHIFT derecho |

- Cada tanque tiene **3 vidas** por ronda. Sin vidas, explota y la ronda es del otro.
- Los tanques tienen **inercia**: tardan un poquito en arrancar y en frenar.
- Las balas **rebotan una vez** en los muros grises. ¡Cuidado, pueden volver a ti!
- Los **ladrillos** (naranjas) se rompen de un tiro. El **agua** no se cruza.
- En los **arbustos** te escondes: la IA no te ve (salvo que esté pegada a ti).
- Cada rato aparece un **power-up**: **E** escudo (aguanta un golpe), **3** triple
  disparo, **V** velocidad, **M** una mina que dejas con la tecla de mina.

## La IA (cuando juegas solo)

1. **Patrulla**: da vueltas al azar y dispara si te tiene enfrente.
2. **Persigue**: busca el camino más corto hasta ti y dispara cuando te ve.
3. **Esquiva**: como la 2, pero se quita de las balas, agarra power-ups y apunta mejor.

Está en la clase `IA` de `tanques.py`. Su método `decidir` devuelve lo mismo que
harías tú con el teclado: (acelerar, girar, disparar, poner mina).

## Hacer tu propia arena

Copia `arena1.txt` a `arena5.txt` y edítalo. Son 14 filas de 20 letras:

    #  muro (no se rompe, las balas rebotan)
    L  ladrillo (se rompe de un tiro)
    A  agua (los tanques no pasan, las balas sí)
    B  arbusto (esconde al tanque)
    .  piso
    1  donde empieza el jugador 1
    2  donde empieza el jugador 2

Las líneas que empiezan con `# ` (con espacio) son comentarios. El menú la
encuentra sola.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Si escribes una tecla
que no existe, el juego avisa en la terminal y usa la de siempre.

## Para cambiar cosas

Arriba de `tanques.py` están los ajustes: `VEL_TANQUE`, `ACELERACION`, `FRENO`
(la inercia), `VEL_BALA`, `RECARGA`, `VIDAS`, `RONDAS_PARA_GANAR`,
`CADA_CUANTO_POWERUP`... Cambia un número, guarda y vuelve a correrlo.
Los sonidos se fabrican con matemáticas al abrir el juego (clase `Sonidos`);
si el computador no tiene audio, el juego corre igual sin sonido.

## Pruebas

    python3 probar.py

Corre el juego "a ciegas" (sin ventana ni audio) 5 segundos en cada arena y
modo, y comprueba que las balas rebotan, que los ladrillos se rompen y que
la IA dispara.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola. (El pip que la armó está
desempacado en `~/.local/opt/pip`, sin sudo.)
