# Impostor de Manu

Un mini Among Us para un jugador, hecho en Python con pygame. **Tú eres el impostor.**
Todo son círculos y rectángulos, y los sonidos están hechos con matemáticas:
no usa nada del juego real.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 impostor.py

En Windows: `python impostor.py`. En Linux/Mac también sirve `./jugar.sh`.

**En el menú:** `1` / `2` eliges el mapa (nave chica o nave grande), `D` cambias la
dificultad (Fácil / Normal / Difícil) y `ENTER` empiezas.

**Jugando:**

- **FLECHAS** te mueves.
- **ESPACIO** matas al tripulante que tengas al lado (después esperas 10 s).
- **S** sabotaje: apagas las luces 5 s. Los bots ven mucho menos.
- **V** parado sobre una ventilación (la rejilla gris), saltas a la siguiente.
- **R** juegas de nuevo cuando terminó · **M** vuelves al menú · **ESC** cierras.

Todas las teclas se cambian en `controles.txt`.

### Cómo se gana y cómo se pierde

Los tripulantes (bots de colores) caminan entre tareas y las van haciendo: la
**barra verde de arriba** se llena. Si la llenan, perdiste. Cada bot que matas deja
de hacer tareas.

Si un bot **ve un cuerpo** o **te ve matar**, le sale un `!` y corre al botón rojo
del centro: hay reunión. Si alguno te vio matar, te vio al lado del cuerpo, te vio
hace poquito o te vio meterte a una ventilación, te expulsan. Si nadie sabe nada,
votan al azar (puede caer un inocente, nadie... o tú).

Ganas si eliminas a todos.

### Dificultades

| | Fácil | Normal | Difícil |
|---|---|---|---|
| Bots | 5 | 6 | 8 |
| Hasta dónde ven | 150 | 190 | 230 |
| Cuánto se acuerdan de ti | 2 s | 4 s | 6 s |
| Tareas para que ganen | 40 | 32 | 50 |

## Para cambiar cosas

Arriba de `impostor.py` están los ajustes: `VEL_BOT`, `COOLDOWN_KILL`, `DURACION_LUCES`,
`TIEMPO_TAREA`, la tabla `DIFICULTADES`... Cambia un número, guarda, y vuelve a correrlo.
Los mapas están en `mapa_chico()` y `mapa_grande()`: salas, pasillos, puertas, tareas y
ventilaciones. El "mapa de metro" de los bots se arma solo a partir de las puertas.
Los sonidos están en la clase `Sonidos`: cada uno es una onda hecha con `math.sin`.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola. (El pip que la armó está
desempacado en `~/.local/opt/pip`, sin sudo.)
