#!/bin/bash
# Abre el Impostor. Si hay una cajita .venv (con pygame adentro) la usa;
# si no, usa el python3 normal del computador.
cd "$(dirname "$0")"
if [ -x .venv/bin/python ]; then
    exec .venv/bin/python impostor.py
else
    exec python3 impostor.py
fi
