"""
Impostor — versión de Manu
==========================
Un mini Among Us para un jugador. TÚ eres el impostor (el círculo rojo).

Controles (todos se cambian en controles.txt, al lado de este archivo):
  FLECHAS        -> moverte
  ESPACIO        -> matar al tripulante que tengas al lado (espera 10 s entre uno y otro)
  S              -> sabotaje: apagar las luces 5 s (los bots ven mucho menos)
  V              -> parado sobre una ventilación, saltas a la siguiente
  1 / 2          -> elegir mapa (en la pantalla de inicio)
  D              -> cambiar dificultad (en la pantalla de inicio)
  ENTER          -> empezar
  R              -> jugar de nuevo cuando terminó
  M              -> volver al menú cuando terminó
  ESC            -> salir

Cómo se gana: eliminas a todos los tripulantes.
Cómo se pierde:
  - Un bot que ve un cuerpo (o te ve matar) corre al botón del centro (le sale
    un "!") y arma una reunión. Si algún bot te vio matar, te vio al lado del
    cuerpo, te vio hace menos de 4 s o te vio meterte a una ventilación, te
    expulsan. Si nadie sabe nada, votan al azar: puede salir un inocente,
    nadie... o tú.
  - La tripulación termina TODAS sus tareas (la barra de arriba se llena).
    Cada bot que matas deja de hacer tareas, así que apúrate pero con cuidado.

Todo se dibuja con círculos y rectángulos, y los sonidos se fabrican con
matemáticas. No hay imágenes ni archivos de audio.
"""

import array
import math
import os
import random
from collections import deque

import pygame

# ---------- Ajustes del juego (cámbialos y prueba qué pasa) ----------
ANCHO, ALTO = 900, 650           # tamaño de la ventana (la cámara te sigue si el mapa es más grande)
FPS = 60

VEL_JUGADOR = 3.6                # píxeles por cuadro
VEL_BOT = 2.0                    # cuando caminan tranquilos
VEL_BOT_ALARMA = 3.3             # cuando corren al botón (¡casi como tú!)

RADIO = 14                       # tamaño de los personajes (círculos)
ALCANCE_KILL = 42                # qué tan cerca hay que estar para matar
COOLDOWN_KILL = 10.0             # segundos entre un kill y el otro
ALCANCE_VENT = 24                # qué tan encima de la ventilación hay que estar
MARGEN_RUTA = 8                  # los bots caminan dejando este espacio con las paredes

VISION_BOT_OSCURO = 60           # hasta dónde ve un bot sin luz
RADIO_SOSPECHA = 90              # si un bot te ve a menos de esto de un cuerpo, sospecha de ti
DURACION_AVISO = 3.0             # segundos que se muestra el resultado de la reunión
DURACION_LUCES = 5.0             # segundos que duran apagadas
COOLDOWN_LUCES = 20.0            # segundos hasta poder sabotear de nuevo

TIEMPO_TAREA = (3.0, 6.0)        # segundos que un bot se queda "haciendo" una tarea

# Estos cuatro los pone la dificultad (mira DIFICULTADES más abajo).
VISION_BOT = 190                 # hasta dónde ve un bot con luz
MEMORIA_BOT = 4.0                # si te vio hace menos de esto y encuentra un cuerpo, sospecha de ti
CANTIDAD_BOTS = 6
TAREAS_TOTALES = 32              # tareas que necesita la tripulación para ganar

DIFICULTADES = {
    #            visión  memoria  bots  tareas
    "Fácil":    (150,    2.0,     5,    40),
    "Normal":   (190,    4.0,     6,    32),
    "Difícil":  (230,    6.0,     8,    50),
}
ORDEN_DIFICULTAD = ["Fácil", "Normal", "Difícil"]


def aplicar_dificultad(nombre):
    """Copia los números de la dificultad elegida a los ajustes del juego."""
    global VISION_BOT, MEMORIA_BOT, CANTIDAD_BOTS, TAREAS_TOTALES
    VISION_BOT, MEMORIA_BOT, CANTIDAD_BOTS, TAREAS_TOTALES = DIFICULTADES[nombre]


# ---------- Colores ----------
FONDO = (18, 18, 28)
PISO = (70, 78, 95)
PISO_PASILLO = (58, 64, 80)
PARED = (150, 160, 185)
BOTON = (220, 40, 40)
BOTON_BORDE = (120, 20, 20)
TAREA = (255, 210, 60)
VENT = (35, 38, 48)
VENT_LINEA = (110, 115, 130)
BLANCO = (240, 240, 240)
NEGRO = (0, 0, 0)
ROJO = (220, 40, 40)
VERDE = (80, 230, 100)
GRIS = (120, 120, 120)
HUESO = (230, 230, 230)

COLORES_BOTS = [
    (60, 120, 230),   # azul
    (50, 190, 80),    # verde
    (250, 140, 30),   # naranja
    (240, 220, 60),   # amarillo
    (200, 80, 220),   # morado
    (60, 210, 210),   # cian
    (245, 120, 180),  # rosado
    (150, 100, 60),   # café
]


def distancia(p, q):
    return math.hypot(p[0] - q[0], p[1] - q[1])


# ---------- Los mapas ----------
class Mapa:
    """Una nave: salas, pasillos, puertas, tareas, ventilaciones y el botón.
    El "mapa de metro" para los bots (nodos) se arma solo a partir de las puertas."""

    def __init__(self, nombre, ancho, alto, salas, pasillos, puertas, tareas, vents, boton):
        self.nombre = nombre
        self.ancho, self.alto = ancho, alto
        self.salas = salas              # {nombre: Rect}
        self.pasillos = pasillos        # [Rect]
        self.puertas = puertas          # [Rect]
        self.tareas = tareas            # [(x, y)]
        self.vents = vents              # [(x, y)]  con V saltas a la siguiente de la lista
        self.boton = boton              # (x, y) botón de emergencia; ahí empiezas tú
        self.caminable = list(salas.values()) + pasillos + puertas
        self.nodos = []
        self.vecinos = {}
        self._armar_nodos()

    def _armar_nodos(self):
        """Estaciones del metro: centro de cada puerta, su "sombra" en el medio del
        pasillo, los cruces de pasillos y el centro de cada sala. Dos estaciones se
        conectan si se ven en línea recta."""
        puntos = []
        for p in self.pasillos:
            for q in self.pasillos:
                if p is not q:
                    cruce = p.clip(q)
                    if cruce.width > 0 and cruce.height > 0:
                        puntos.append(cruce.center)
        for d in self.puertas:
            puntos.append(d.center)
            for p in self.pasillos:
                if d.inflate(2, 2).colliderect(p):
                    if p.height > p.width:          # pasillo vertical
                        puntos.append((p.centerx, d.centery))
                    else:                           # pasillo horizontal
                        puntos.append((d.centerx, p.centery))
        for s in self.salas.values():
            puntos.append(s.center)
        # sin repetidos, y solo los que pisan piso
        self.nodos = []
        for p in puntos:
            if p not in self.nodos and self.es_caminable(p):
                self.nodos.append(p)
        self.vecinos = {i: [] for i in range(len(self.nodos))}
        for i, a in enumerate(self.nodos):
            for j, b in enumerate(self.nodos):
                if i < j and self.linea_libre(a, b, margen=MARGEN_RUTA):
                    self.vecinos[i].append(j)
                    self.vecinos[j].append(i)

    def es_caminable(self, punto):
        """¿Este punto está sobre el piso (sala, pasillo o puerta)?"""
        for r in self.caminable:
            if r.collidepoint(punto):
                return True
        return False

    def linea_libre(self, p, q, paso=4, margen=0):
        """¿Se puede ir en línea recta de p a q sin atravesar paredes?
        Revisamos un puntito cada 4 píxeles. Con 'margen' revisamos también
        un poco a cada lado de la línea: así los bots no rozan las esquinas."""
        d = distancia(p, q)
        if d == 0:
            return self.es_caminable(p)
        n = max(1, int(d / paso))
        lados = [(0, 0)]
        if margen:
            # un vector perpendicular a la línea, de largo 'margen'
            px, py = -(q[1] - p[1]) / d * margen, (q[0] - p[0]) / d * margen
            lados += [(px, py), (-px, -py)]
        for i in range(n + 1):
            t = i / n
            x = p[0] + (q[0] - p[0]) * t
            y = p[1] + (q[1] - p[1]) * t
            for ox, oy in lados:
                if not self.es_caminable((x + ox, y + oy)):
                    return False
        return True

    def nodo_mas_cercano_visible(self, p):
        mejor, mejor_d = None, float("inf")
        for i, pos in enumerate(self.nodos):
            d = distancia(p, pos)
            if d < mejor_d and self.linea_libre(p, pos, margen=MARGEN_RUTA):
                mejor, mejor_d = i, d
        return mejor

    def camino(self, desde, hasta):
        """Lista de puntos para llegar de 'desde' a 'hasta' sin chocar."""
        if self.linea_libre(desde, hasta, margen=MARGEN_RUTA):
            return [hasta]
        n1 = self.nodo_mas_cercano_visible(desde)
        n2 = self.nodo_mas_cercano_visible(hasta)
        if n1 is None or n2 is None:
            return [hasta]
        # Búsqueda por anchura: encuentra la ruta más corta de estación en estación.
        anterior = {n1: None}
        cola = deque([n1])
        while cola:
            actual = cola.popleft()
            if actual == n2:
                break
            for v in self.vecinos[actual]:
                if v not in anterior:
                    anterior[v] = actual
                    cola.append(v)
        if n2 not in anterior:
            return [hasta]
        ruta = []
        n = n2
        while n is not None:
            ruta.append(self.nodos[n])
            n = anterior[n]
        ruta.reverse()
        return ruta + [hasta]


def mapa_chico():
    """Mapa 1: cuatro salas en las esquinas y dos pasillos en cruz."""
    R = pygame.Rect
    salas = {
        "Cafetería":    R(40, 40, 330, 210),
        "Armas":        R(530, 40, 330, 210),
        "Electricidad": R(40, 400, 330, 210),
        "Reactor":      R(530, 400, 330, 210),
    }
    pasillos = [R(40, 290, 820, 70), R(415, 40, 70, 570)]
    puertas = [
        R(370, 130, 45, 60), R(180, 250, 60, 40),   # Cafetería
        R(485, 130, 45, 60), R(660, 250, 60, 40),   # Armas
        R(370, 470, 45, 60), R(180, 360, 60, 40),   # Electricidad
        R(485, 470, 45, 60), R(660, 360, 60, 40),   # Reactor
    ]
    tareas = [
        (90, 90), (300, 200), (200, 120),          # Cafetería
        (580, 90), (800, 200), (700, 120),         # Armas
        (90, 560), (300, 450), (200, 530),         # Electricidad
        (580, 560), (800, 450), (700, 530),        # Reactor
    ]
    vents = [(75, 220), (825, 220), (825, 430), (75, 430)]
    return Mapa("Nave chica", 900, 650, salas, pasillos, puertas, tareas, vents, (450, 325))


def mapa_grande():
    """Mapa 2: seis salas (3 x 2), un pasillo largo al medio y dos verticales.
    Es más grande que la ventana: la cámara te sigue."""
    R = pygame.Rect
    columnas = [40, 530, 1030]           # x donde empieza cada sala
    filas = [40, 490]                    # y donde empieza cada sala
    nombres = ["Cafetería", "Armas", "Navegación", "Electricidad", "Reactor", "Motores"]
    salas = {}
    for f, y in enumerate(filas):
        for c, x in enumerate(columnas):
            salas[nombres[f * 3 + c]] = R(x, y, 330, 300)
    pasillos = [R(40, 380, 1320, 70), R(415, 40, 70, 750), R(915, 40, 70, 750)]
    puertas, tareas = [], []
    for f, y in enumerate(filas):
        # puerta hacia el pasillo horizontal (abajo de la fila 1, arriba de la fila 2)
        py = 340 if f == 0 else 450
        for c, x in enumerate(columnas):
            puertas.append(R(x + 135, py, 60, 40))
            tareas += [(x + 50, y + 50), (x + 280, y + 250), (x + 165, y + 150)]
        # puertas laterales hacia los pasillos verticales
        puertas += [R(370, y + 120, 45, 60), R(485, y + 120, 45, 60),
                    R(860, y + 120, 55, 60), R(985, y + 120, 45, 60)]
    vents = [(75, 310), (565, 310), (1325, 310), (1325, 520), (565, 520), (75, 520)]
    return Mapa("Nave grande", 1400, 830, salas, pasillos, puertas, tareas, vents, (700, 415))


MAPAS = [mapa_chico, mapa_grande]
NOMBRES_MAPAS = ["Nave chica", "Nave grande"]


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "izquierda": "left", "derecha": "right", "arriba": "up", "abajo": "down",
    "matar": "space", "sabotaje": "s", "vent": "v",
    "mapa1": "1", "mapa2": "2", "dificultad": "d", "empezar": "return",
    "reiniciar": "r", "menu": "m", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}   # se llena en main(), después de pygame.init()


def nombre_tecla(accion):
    nombre = pygame.key.name(TECLA[accion])
    return {"return": "ENTER", "space": "ESPACIO", "escape": "ESC"}.get(nombre, nombre.upper())


# ---------- Sonidos fabricados con matemáticas ----------
class Sonidos:
    """Cada sonido es una lista de números (la onda) que le pasamos a pygame.
    Si el computador no tiene audio, simplemente no suena nada."""

    def __init__(self):
        self.ok = False
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1)
            self.frec, _, self.canales = pygame.mixer.get_init()
            self.ok = True
        except pygame.error:
            return
        self.kill = self._armar(self._tono_bajando(220, 50, 0.35, volumen=0.7))
        self.alarma = self._armar(self._beep(880, 0.12) + self._silencio(0.06) +
                                  self._beep(660, 0.12) + self._silencio(0.06) + self._beep(880, 0.12))
        self.reunion = self._armar(self._beep(523, 0.15) + self._beep(659, 0.15) + self._beep(784, 0.3))
        self.vent = self._armar(self._ruido(0.25))
        self.luces = self._armar(self._tono_bajando(400, 80, 0.2, volumen=0.4))
        self.tarea = self._armar(self._beep(1200, 0.05, volumen=0.25))

    # --- generadores: devuelven listas de números entre -1 y 1 ---
    def _beep(self, hz, seg, volumen=0.5):
        n = int(self.frec * seg)
        return [volumen * math.sin(2 * math.pi * hz * i / self.frec) * min(1.0, (n - i) / (n * 0.3))
                for i in range(n)]

    def _tono_bajando(self, hz_inicio, hz_fin, seg, volumen=0.5):
        n = int(self.frec * seg)
        muestras, fase = [], 0.0
        for i in range(n):
            hz = hz_inicio + (hz_fin - hz_inicio) * i / n
            fase += 2 * math.pi * hz / self.frec
            muestras.append(volumen * math.sin(fase) * (1 - i / n))
        return muestras

    def _ruido(self, seg, volumen=0.4):
        n = int(self.frec * seg)
        return [volumen * random.uniform(-1, 1) * (1 - i / n) for i in range(n)]

    def _silencio(self, seg):
        return [0.0] * int(self.frec * seg)

    def _armar(self, muestras):
        """Convierte los números en un Sound de pygame (enteros de 16 bits)."""
        datos = array.array("h")
        for m in muestras:
            v = int(max(-1.0, min(1.0, m)) * 32767)
            for _ in range(self.canales):
                datos.append(v)
        return pygame.mixer.Sound(buffer=datos.tobytes())

    def tocar(self, nombre):
        if self.ok:
            getattr(self, nombre).play()


SONIDO = None   # se crea en main()


def sonar(nombre):
    if SONIDO is not None:
        SONIDO.tocar(nombre)


# ---------- Personajes ----------
class Jugador:
    def __init__(self, mapa):
        self.mapa = mapa
        self.pos = [float(mapa.boton[0]), float(mapa.boton[1])]
        self.cooldown = 0.0

    def mover(self, teclas):
        dx = dy = 0
        if teclas[TECLA["izquierda"]]:
            dx -= 1
        if teclas[TECLA["derecha"]]:
            dx += 1
        if teclas[TECLA["arriba"]]:
            dy -= 1
        if teclas[TECLA["abajo"]]:
            dy += 1
        if dx and dy:                       # en diagonal no vamos más rápido
            dx *= 0.707
            dy *= 0.707
        # Probamos cada eje por separado: así te deslizas por las paredes.
        nueva_x = self.pos[0] + dx * VEL_JUGADOR
        if self._cabe((nueva_x, self.pos[1])):
            self.pos[0] = nueva_x
        nueva_y = self.pos[1] + dy * VEL_JUGADOR
        if self._cabe((self.pos[0], nueva_y)):
            self.pos[1] = nueva_y

    def _cabe(self, p):
        r = RADIO - 4
        return all(self.mapa.es_caminable((p[0] + ox, p[1] + oy))
                   for ox, oy in ((0, 0), (r, 0), (-r, 0), (0, r), (0, -r)))

    def vent_cercana(self):
        """Devuelve el número de la ventilación sobre la que estás parado, o None."""
        for i, v in enumerate(self.mapa.vents):
            if distancia(self.pos, v) <= ALCANCE_VENT:
                return i
        return None


class Bot:
    def __init__(self, mapa, color, pos):
        self.mapa = mapa
        self.color = color
        self.pos = [float(pos[0]), float(pos[1])]
        self.vivo = True
        self.alarma = False             # ¿vio algo y corre al botón?
        self.sospecha = False           # ¿te vio matar, al lado de un cuerpo o entrando a una vent?
        self.desde_que_te_vio = 999.0   # segundos desde la última vez que te vio
        self.ruta = []
        self.esperando = 0.0            # segundos que le faltan en la tarea actual
        self.nueva_tarea()

    def nueva_tarea(self):
        objetivo = random.choice(self.mapa.tareas)
        self.ruta = self.mapa.camino(self.pos, objetivo)

    def alarmar(self):
        if not self.alarma:
            self.alarma = True
            self.esperando = 0.0
            self.ruta = self.mapa.camino(self.pos, self.mapa.boton)
            sonar("alarma")

    def actualizar(self, dt):
        """Mueve al bot. Devuelve True en el instante en que termina una tarea."""
        if not self.vivo:
            return False
        if self.esperando > 0:
            self.esperando -= dt
            if self.esperando <= 0:
                self.nueva_tarea()
                return True                     # ¡tarea lista!
            return False
        if not self.ruta:
            if self.alarma:
                return False                    # llegó al botón: se queda ahí
            self.esperando = random.uniform(*TIEMPO_TAREA)
            return False
        vel = VEL_BOT_ALARMA if self.alarma else VEL_BOT
        destino = self.ruta[0]
        d = distancia(self.pos, destino)
        if d <= vel:
            self.pos = [float(destino[0]), float(destino[1])]
            self.ruta.pop(0)
        else:
            self.pos[0] += (destino[0] - self.pos[0]) / d * vel
            self.pos[1] += (destino[1] - self.pos[1]) / d * vel
        return False

    def ve(self, punto, alcance):
        """¿Este bot puede ver ese punto? Tiene que estar cerca y sin pared en medio."""
        return distancia(self.pos, punto) <= alcance and self.mapa.linea_libre(self.pos, punto)

    def llego_al_boton(self):
        return self.alarma and distancia(self.pos, self.mapa.boton) < 18


# ---------- El juego ----------
class Juego:
    def __init__(self):
        self.mapa_elegido = 0
        self.dificultad = "Normal"
        self.estado = "inicio"          # "inicio", "jugando", "ganaste" o "perdiste"
        self.mapa = MAPAS[0]()
        self.mundo = pygame.Surface((self.mapa.ancho, self.mapa.alto))
        self.camara = [0, 0]

    def empezar(self):
        """Arma una partida nueva con el mapa y la dificultad elegidos."""
        aplicar_dificultad(self.dificultad)
        self.mapa = MAPAS[self.mapa_elegido]()
        self.mundo = pygame.Surface((self.mapa.ancho, self.mapa.alto))
        self.jugador = Jugador(self.mapa)
        posiciones = random.sample(self.mapa.tareas, CANTIDAD_BOTS)
        self.bots = [Bot(self.mapa, COLORES_BOTS[i], posiciones[i]) for i in range(CANTIDAD_BOTS)]
        self.cuerpos = []               # lista de (x, y, color)
        self.luces = 0.0                # segundos que quedan sin luz
        self.cooldown_luces = 0.0
        self.flash_kill = 0.0           # instante de kill: los bots que lo ven, te vieron
        self.pos_kill = None
        self.flash_vent = 0.0           # instante en que te metiste a una vent
        self.pos_vent = None
        self.tareas_hechas = 0
        self.estado = "jugando"
        self.mensaje = ""
        self.aviso = ""                 # texto de la última reunión
        self.aviso_t = 0.0

    def reiniciar(self):
        self.empezar()

    # --- acciones del impostor ---
    def intentar_kill(self):
        if self.jugador.cooldown > 0:
            return
        cerca = [b for b in self.bots if b.vivo and distancia(b.pos, self.jugador.pos) <= ALCANCE_KILL]
        if not cerca:
            return
        victima = min(cerca, key=lambda b: distancia(b.pos, self.jugador.pos))
        victima.vivo = False
        self.cuerpos.append((victima.pos[0], victima.pos[1], victima.color))
        self.jugador.cooldown = COOLDOWN_KILL
        self.flash_kill = 0.5
        self.pos_kill = tuple(victima.pos)
        sonar("kill")

    def usar_vent(self):
        """Si estás sobre una ventilación, saltas a la siguiente de la lista del mapa."""
        i = self.jugador.vent_cercana()
        if i is None:
            return False
        self.flash_vent = 0.5
        self.pos_vent = tuple(self.jugador.pos)
        destino = self.mapa.vents[(i + 1) % len(self.mapa.vents)]
        self.jugador.pos = [float(destino[0]), float(destino[1])]
        sonar("vent")
        return True

    def reunion(self):
        """Un bot llegó al botón. Los vivos votan: si alguno sospecha de ti, te expulsan.
        Si nadie sabe nada, expulsan a un bot al azar (o a nadie) y el juego sigue."""
        sonar("reunion")
        vivos = [b for b in self.bots if b.vivo]
        if any(b.sospecha for b in vivos):
            self.estado = "perdiste"
            self.mensaje = "¡Reunión! Un tripulante te vio. Te expulsaron."
            return
        # Sin pruebas, votan al azar entre todos los vivos... y tú también cuentas.
        candidatos = vivos + ["tu"]
        voto = random.choice(candidatos + [None])   # None = empate, nadie sale
        if voto == "tu":
            self.estado = "perdiste"
            self.mensaje = "¡Reunión! Nadie tenía pruebas... pero votaron por ti."
            return
        if voto is None:
            self.aviso = "Reunión: nadie sabe nada. Empate, nadie fue expulsado."
        else:
            voto.vivo = False
            self.aviso = "Reunión: nadie sabe nada... ¡expulsaron a un inocente!"
        self.aviso_t = DURACION_AVISO
        # Después de la reunión todo se limpia: cuerpos, alarmas y cooldown.
        self.cuerpos = []
        for b in self.bots:
            b.alarma = False
            b.sospecha = False
            b.desde_que_te_vio = 999.0
            if b.vivo:
                b.nueva_tarea()
        self.jugador.cooldown = COOLDOWN_KILL
        self.flash_kill = 0.0
        self.flash_vent = 0.0

    def sabotear_luces(self):
        if self.cooldown_luces > 0 or self.luces > 0:
            return
        self.luces = DURACION_LUCES
        self.cooldown_luces = COOLDOWN_LUCES
        sonar("luces")

    # --- un cuadro del juego ---
    def actualizar(self, dt, teclas):
        if self.estado != "jugando":
            return
        self.jugador.mover(teclas)
        self.jugador.cooldown = max(0.0, self.jugador.cooldown - dt)
        self.cooldown_luces = max(0.0, self.cooldown_luces - dt)
        self.luces = max(0.0, self.luces - dt)
        self.flash_kill = max(0.0, self.flash_kill - dt)
        self.flash_vent = max(0.0, self.flash_vent - dt)

        alcance = VISION_BOT_OSCURO if self.luces > 0 else VISION_BOT

        for bot in self.bots:
            if bot.actualizar(dt):
                self.tareas_hechas += 1
                sonar("tarea")
            if not bot.vivo or bot.alarma:
                continue
            # ¿Te está viendo ahora? Lo recuerda un rato.
            if bot.ve(self.jugador.pos, alcance):
                bot.desde_que_te_vio = 0.0
            else:
                bot.desde_que_te_vio += dt
            # ¿Te vio matar? Eso sí es prueba: sospecha de ti y corre al botón.
            if self.flash_kill > 0 and bot.ve(self.pos_kill, alcance):
                bot.sospecha = True
                bot.alarmar()
                continue
            # ¿Te vio meterte a una ventilación? Solo los impostores hacen eso...
            if self.flash_vent > 0 and bot.ve(self.pos_vent, alcance):
                bot.sospecha = True
            for (cx, cy, _) in self.cuerpos:
                if bot.ve((cx, cy), alcance):
                    # ¿Estabas al lado del cuerpo, o te vio hace poquito? Sospechoso.
                    cerca = distancia(self.jugador.pos, (cx, cy)) <= RADIO_SOSPECHA and bot.ve(self.jugador.pos, alcance)
                    if cerca or bot.desde_que_te_vio < MEMORIA_BOT:
                        bot.sospecha = True
                    bot.alarmar()
                    break

        self.aviso_t = max(0.0, self.aviso_t - dt)
        for bot in self.bots:
            if bot.vivo and bot.llego_al_boton():
                self.reunion()
                return

        if self.tareas_hechas >= TAREAS_TOTALES:
            self.estado = "perdiste"
            self.mensaje = "La tripulación terminó todas sus tareas. Se te acabó el tiempo."
            return

        if all(not b.vivo for b in self.bots):
            self.estado = "ganaste"
            self.mensaje = "Eliminaste a toda la tripulación. La nave es tuya."

    # --- dibujar ---
    def dibujar(self, pantalla, fuente, fuente_grande):
        if self.estado == "inicio":
            self._dibujar_inicio(pantalla, fuente, fuente_grande)
            return

        self._dibujar_mundo(fuente)

        # La cámara: un recorte del mundo centrado en ti, sin salirse del mapa.
        self.camara[0] = int(max(0, min(self.jugador.pos[0] - ANCHO / 2, self.mapa.ancho - ANCHO)))
        self.camara[1] = int(max(0, min(self.jugador.pos[1] - ALTO / 2, self.mapa.alto - ALTO)))
        pantalla.fill(FONDO)
        pantalla.blit(self.mundo, (0, 0), pygame.Rect(self.camara[0], self.camara[1], ANCHO, ALTO))

        if self.luces > 0:
            self._dibujar_oscuridad(pantalla)

        self._dibujar_hud(pantalla, fuente)

        if self.estado != "jugando":
            self._dibujar_final(pantalla, fuente, fuente_grande)

    def _dibujar_mundo(self, fuente):
        m = self.mapa
        s = self.mundo
        s.fill(FONDO)

        for r in m.pasillos + m.puertas:
            pygame.draw.rect(s, PISO_PASILLO, r)
        for nombre, r in m.salas.items():
            pygame.draw.rect(s, PISO, r)
            pygame.draw.rect(s, PARED, r, 4)
            texto = fuente.render(nombre, True, PARED)
            s.blit(texto, (r.x + 8, r.y + 6))
        for r in m.pasillos:
            pygame.draw.rect(s, PARED, r, 3)
        for r in m.puertas:                        # las puertas tapan la pared
            pygame.draw.rect(s, PISO_PASILLO, r)

        for (vx, vy) in m.vents:
            # Una ventilación: rejilla gris oscura con tres rayitas.
            pygame.draw.rect(s, VENT, (vx - 18, vy - 12, 36, 24), border_radius=5)
            for k in (-6, 0, 6):
                pygame.draw.line(s, VENT_LINEA, (vx - 12, vy + k), (vx + 12, vy + k), 2)

        for t in m.tareas:
            pygame.draw.rect(s, TAREA, (t[0] - 7, t[1] - 7, 14, 14), 2)

        pygame.draw.circle(s, BOTON_BORDE, m.boton, 18)
        pygame.draw.circle(s, BOTON, m.boton, 13)

        for (cx, cy, color) in self.cuerpos:
            # Un cuerpo: medio círculo del color del bot + un huesito.
            pygame.draw.circle(s, color, (int(cx), int(cy)), RADIO,
                               draw_top_right=True, draw_top_left=True)
            pygame.draw.line(s, HUESO, (cx - 8, cy + 4), (cx + 8, cy + 4), 4)

        for bot in self.bots:
            if not bot.vivo:
                continue
            p = (int(bot.pos[0]), int(bot.pos[1]))
            pygame.draw.circle(s, bot.color, p, RADIO)
            pygame.draw.circle(s, NEGRO, p, RADIO, 2)
            if bot.esperando > 0 and not bot.alarma:   # está haciendo una tarea
                pygame.draw.rect(s, TAREA, (p[0] - 10, p[1] - RADIO - 8, 20, 4), 1)
            if bot.alarma:
                signo = fuente.render("!", True, ROJO)
                s.blit(signo, (p[0] - 4, p[1] - RADIO - 22))

        p = (int(self.jugador.pos[0]), int(self.jugador.pos[1]))
        pygame.draw.circle(s, ROJO, p, RADIO)
        pygame.draw.circle(s, NEGRO, p, RADIO, 2)
        if self.jugador.cooldown == 0:           # anillo: listo para matar
            pygame.draw.circle(s, BLANCO, p, ALCANCE_KILL, 1)

    def _en_pantalla(self, p):
        """Convierte un punto del mundo a un punto de la ventana (resta la cámara)."""
        return (int(p[0] - self.camara[0]), int(p[1] - self.camara[1]))

    def _dibujar_oscuridad(self, pantalla):
        # Una capa negra casi opaca con un "agujero" de luz alrededor tuyo.
        sombra = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 215))
        pygame.draw.circle(sombra, (0, 0, 0, 0), self._en_pantalla(self.jugador.pos), 110)
        pantalla.blit(sombra, (0, 0))

    def _dibujar_hud(self, pantalla, fuente):
        vivos = sum(1 for b in self.bots if b.vivo)
        if self.jugador.cooldown > 0:
            kill = f"KILL en {self.jugador.cooldown:0.1f} s"
        else:
            kill = f"KILL listo ({nombre_tecla('matar')})"
        if self.luces > 0:
            luz = f"LUCES apagadas {self.luces:0.1f} s"
        elif self.cooldown_luces > 0:
            luz = f"Sabotaje en {self.cooldown_luces:0.1f} s"
        else:
            luz = f"Sabotaje listo ({nombre_tecla('sabotaje')})"
        if self.jugador.vent_cercana() is not None:
            luz += f"    VENT ({nombre_tecla('vent')})"
        linea = f"Tripulantes: {vivos}    {kill}    {luz}"
        pantalla.blit(fuente.render(linea, True, BLANCO), (12, ALTO - 26))

        # Barra de tareas de la tripulación: si se llena, perdiste.
        barra = pygame.Rect(ANCHO // 2 - 150, 10, 300, 14)
        pygame.draw.rect(pantalla, NEGRO, barra)
        avance = min(1.0, self.tareas_hechas / TAREAS_TOTALES)
        pygame.draw.rect(pantalla, VERDE, (barra.x, barra.y, int(barra.width * avance), barra.height))
        pygame.draw.rect(pantalla, BLANCO, barra, 1)
        txt = fuente.render(f"Tareas {self.tareas_hechas}/{TAREAS_TOTALES}", True, BLANCO)
        pantalla.blit(txt, (barra.right + 10, 6))

        if self.aviso_t > 0:
            txt = fuente.render(self.aviso, True, TAREA)
            pantalla.blit(txt, txt.get_rect(center=(ANCHO // 2, 44)))

    def _dibujar_inicio(self, pantalla, fuente, fuente_grande):
        pantalla.fill(FONDO)
        t = fuente_grande.render("IMPOSTOR", True, ROJO)
        pantalla.blit(t, t.get_rect(center=(ANCHO // 2, 110)))
        lineas = [
            (f"Mapa: {NOMBRES_MAPAS[self.mapa_elegido]}", BLANCO),
            (f"   ({nombre_tecla('mapa1')} = nave chica, {nombre_tecla('mapa2')} = nave grande)", GRIS),
            ("", BLANCO),
            (f"Dificultad: {self.dificultad}", BLANCO),
            (f"   ({nombre_tecla('dificultad')} para cambiar)", GRIS),
            ("", BLANCO),
            (f"{nombre_tecla('empezar')} para empezar", VERDE),
            ("", BLANCO),
            (f"Flechas: moverte   {nombre_tecla('matar')}: matar   {nombre_tecla('sabotaje')}: apagar luces   "
             f"{nombre_tecla('vent')}: ventilación", GRIS),
            ("Los bots hacen tareas: si llenan la barra, perdiste. Si te ven, te expulsan.", GRIS),
        ]
        y = 200
        for texto, color in lineas:
            if texto:
                r = fuente.render(texto, True, color)
                pantalla.blit(r, r.get_rect(center=(ANCHO // 2, y)))
            y += 32

    def _dibujar_final(self, pantalla, fuente, fuente_grande):
        capa = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        capa.fill((0, 0, 0, 170))
        pantalla.blit(capa, (0, 0))
        titulo = "GANASTE" if self.estado == "ganaste" else "PERDISTE"
        color = VERDE if self.estado == "ganaste" else ROJO
        t = fuente_grande.render(titulo, True, color)
        pantalla.blit(t, t.get_rect(center=(ANCHO // 2, ALTO // 2 - 40)))
        m = fuente.render(self.mensaje, True, BLANCO)
        pantalla.blit(m, m.get_rect(center=(ANCHO // 2, ALTO // 2 + 15)))
        r = fuente.render(f"{nombre_tecla('reiniciar')} jugar de nuevo   ·   {nombre_tecla('menu')} menú   ·   "
                          f"{nombre_tecla('salir')} salir", True, GRIS)
        pantalla.blit(r, r.get_rect(center=(ANCHO // 2, ALTO // 2 + 50)))


def main():
    global SONIDO
    pygame.init()
    TECLA.update(cargar_controles())
    SONIDO = Sonidos()
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Impostor — de Manu")
    reloj = pygame.time.Clock()
    fuente = pygame.font.SysFont(None, 26)
    fuente_grande = pygame.font.SysFont(None, 80)

    juego = Juego()
    corriendo = True
    while corriendo:
        dt = reloj.tick(FPS) / 1000.0        # segundos desde el cuadro anterior
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN:
                k = evento.key
                if k == TECLA["salir"]:
                    corriendo = False
                elif juego.estado == "inicio":
                    if k == TECLA["mapa1"]:
                        juego.mapa_elegido = 0
                    elif k == TECLA["mapa2"]:
                        juego.mapa_elegido = 1
                    elif k == TECLA["dificultad"]:
                        i = ORDEN_DIFICULTAD.index(juego.dificultad)
                        juego.dificultad = ORDEN_DIFICULTAD[(i + 1) % len(ORDEN_DIFICULTAD)]
                    elif k == TECLA["empezar"]:
                        juego.empezar()
                elif juego.estado == "jugando":
                    if k == TECLA["matar"]:
                        juego.intentar_kill()
                    elif k == TECLA["sabotaje"]:
                        juego.sabotear_luces()
                    elif k == TECLA["vent"]:
                        juego.usar_vent()
                else:                                  # ganaste / perdiste
                    if k == TECLA["reiniciar"]:
                        juego.reiniciar()
                    elif k == TECLA["menu"]:
                        juego.estado = "inicio"

        juego.actualizar(dt, pygame.key.get_pressed())
        juego.dibujar(pantalla, fuente, fuente_grande)
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()
