# Por si quieres cancelar la pelea: /function jefe:quitar (no da tesoro)
kill @e[tag=rey_zombie]
kill @e[tag=esbirro]
kill @e[type=marker,tag=jefe_marca]
scoreboard players set #activo jefe 0
bossbar set jefe:rey visible false
bossbar set jefe:rey players
tellraw @a [{"text":"[Rey Zombie] ","color":"dark_red"},{"text":"el rey se fue (sin tesoro).","color":"gray"}]
