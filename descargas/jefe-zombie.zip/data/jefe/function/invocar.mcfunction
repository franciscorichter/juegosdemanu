# Escribe /function jefe:invocar. Si ya hay un rey vivo, no crea otro.
execute if score #activo jefe matches 1 run tellraw @s [{"text":"[Rey Zombie] ","color":"dark_red"},{"text":"ya hay un Rey Zombie vivo. Derrotalo primero (o usa /function jefe:quitar).","color":"gray"}]
execute unless score #activo jefe matches 1 run function jefe:crear
