scoreboard players set #activo jefe 0
bossbar set jefe:rey visible false
bossbar set jefe:rey players

# El cofre del tesoro aparece donde cayo el rey
execute at @e[type=marker,tag=jefe_marca,limit=1] run setblock ~ ~ ~ minecraft:chest{CustomName:'{"text":"Tesoro del Rey Zombie","color":"gold"}',Items:[{Slot:10b,id:"minecraft:diamond",count:8},{Slot:11b,id:"minecraft:netherite_ingot",count:2},{Slot:12b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:13b,id:"minecraft:golden_helmet",count:1,components:{"minecraft:custom_name":'{"text":"Corona del Rey Zombie","color":"gold","italic":false}',"minecraft:enchantments":{"levels":{"minecraft:protection":4,"minecraft:unbreaking":3}}}},{Slot:14b,id:"minecraft:netherite_sword",count:1,components:{"minecraft:enchantments":{"levels":{"minecraft:sharpness":5,"minecraft:unbreaking":3}}}},{Slot:15b,id:"minecraft:totem_of_undying",count:1},{Slot:16b,id:"minecraft:experience_bottle",count:16}]}
execute at @e[type=marker,tag=jefe_marca,limit=1] run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",colors:[I;11743532,16766720],has_trail:true}],flight_duration:1}}}}
kill @e[type=marker,tag=jefe_marca]

# Los esbirros se desvanecen
execute at @e[tag=esbirro] run particle minecraft:poof ~ ~1 ~ 0.3 0.5 0.3 0.05 20
kill @e[tag=esbirro]

title @a title {"text":"¡Rey Zombie derrotado!","color":"gold","bold":true}
title @a subtitle {"text":"Busca el cofre del tesoro donde cayo","color":"yellow"}
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1
tellraw @a [{"text":"[Rey Zombie] ","color":"dark_red"},{"text":"¡Derrotado! Dejo un cofre con su tesoro.","color":"gold"}]
