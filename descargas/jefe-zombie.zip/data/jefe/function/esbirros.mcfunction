scoreboard players set #timer jefe 0
execute at @e[tag=rey_zombie,limit=1] run summon minecraft:zombie ~2 ~ ~ {CustomName:'{"text":"Esbirro","color":"gray"}',Tags:["esbirro"],PersistenceRequired:1b,IsBaby:0b,ArmorItems:[{},{},{},{id:"minecraft:leather_helmet",count:1}],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]}
execute at @e[tag=rey_zombie,limit=1] run summon minecraft:zombie ~-2 ~ ~ {CustomName:'{"text":"Esbirro","color":"gray"}',Tags:["esbirro"],PersistenceRequired:1b,IsBaby:0b,ArmorItems:[{},{},{},{id:"minecraft:leather_helmet",count:1}],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]}
execute at @e[tag=rey_zombie,limit=1] run summon minecraft:zombie ~ ~ ~2 {CustomName:'{"text":"Esbirro","color":"gray"}',Tags:["esbirro"],PersistenceRequired:1b,IsBaby:0b,ArmorItems:[{},{},{},{id:"minecraft:leather_helmet",count:1}],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]}
execute at @e[tag=rey_zombie,limit=1] run particle minecraft:soul ~ ~1 ~ 1.5 1 1.5 0.05 60
execute at @e[tag=rey_zombie,limit=1] run playsound minecraft:entity.zombie.ambient master @a ~ ~ ~ 1 0.5
tellraw @a [{"text":"[Rey Zombie] ","color":"dark_red"},{"text":"¡El rey llama a sus esbirros!","color":"gray"}]
