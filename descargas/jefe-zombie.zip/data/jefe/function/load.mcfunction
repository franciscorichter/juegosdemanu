# Se ejecuta al cargar el mundo (o con /reload)
scoreboard objectives add jefe dummy

# Crear la barra de jefe solo si no existe todavia
execute store success score #hay_barra jefe run bossbar get jefe:rey max
execute unless score #hay_barra jefe matches 1 run bossbar add jefe:rey {"text":"Rey Zombie","color":"dark_red","bold":true}
bossbar set jefe:rey color red
bossbar set jefe:rey style notched_10
bossbar set jefe:rey max 200
execute unless score #activo jefe matches 1 run bossbar set jefe:rey visible false

tellraw @a [{"text":"[Rey Zombie] ","color":"dark_red"},{"text":"datapack cargado. Escribe ","color":"gray"},{"text":"/function jefe:invocar","color":"yellow"},{"text":" para invocarlo.","color":"gray"}]
