# Cada tick, pero solo trabaja si hay un rey vivo
execute if score #activo jefe matches 1 run function jefe:vivo
