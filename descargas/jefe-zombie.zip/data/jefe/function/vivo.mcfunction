# La barra de jefe copia la vida del rey
execute store result bossbar jefe:rey value run data get entity @e[tag=rey_zombie,limit=1] Health

# El marcador lo sigue
execute as @e[tag=rey_zombie,limit=1] at @s run tp @e[type=marker,tag=jefe_marca] ~ ~ ~

# Cada 400 ticks (20 segundos) llama esbirros
scoreboard players add #timer jefe 1
execute if score #timer jefe matches 400.. run function jefe:esbirros

# ¿Murio? (ya no existe ninguna entidad con su etiqueta)
execute unless entity @e[tag=rey_zombie] run function jefe:morir
