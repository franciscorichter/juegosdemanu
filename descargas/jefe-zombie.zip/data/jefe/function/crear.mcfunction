# Aparece 3 bloques delante de quien lo invoca
summon minecraft:zombie ^ ^ ^3 {CustomName:'{"text":"Rey Zombie","color":"dark_red","bold":true}',CustomNameVisible:1b,Tags:["rey_zombie"],PersistenceRequired:1b,IsBaby:0b,CanPickUpLoot:0b,ArmorItems:[{id:"minecraft:netherite_boots",count:1},{id:"minecraft:netherite_leggings",count:1},{id:"minecraft:netherite_chestplate",count:1},{id:"minecraft:netherite_helmet",count:1}],HandItems:[{id:"minecraft:netherite_axe",count:1},{}],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f],HandDropChances:[0.0f,0.0f]}

# Mas vida, mas grande, mas rapido y dificil de empujar
attribute @e[tag=rey_zombie,limit=1] minecraft:max_health base set 200
attribute @e[tag=rey_zombie,limit=1] minecraft:scale base set 1.5
attribute @e[tag=rey_zombie,limit=1] minecraft:movement_speed base set 0.3
attribute @e[tag=rey_zombie,limit=1] minecraft:knockback_resistance base set 0.8
data merge entity @e[tag=rey_zombie,limit=1] {Health:200f}

# Efectos para siempre (el true del final esconde las particulas)
effect give @e[tag=rey_zombie] minecraft:fire_resistance infinite 0 true
effect give @e[tag=rey_zombie] minecraft:strength infinite 1 true
effect give @e[tag=rey_zombie] minecraft:resistance infinite 0 true

# Un marcador invisible que lo sigue, para saber donde murio
summon minecraft:marker ^ ^ ^3 {Tags:["jefe_marca"]}

scoreboard players set #activo jefe 1
scoreboard players set #timer jefe 0
bossbar set jefe:rey value 200
bossbar set jefe:rey players @a
bossbar set jefe:rey visible true

tellraw @a [{"text":"[Rey Zombie] ","color":"dark_red"},{"selector":"@s"},{"text":" invoco al Rey Zombie. ¡Cada 20 segundos llama a sus esbirros!","color":"gray"}]
playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 0.6
