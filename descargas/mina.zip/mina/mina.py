"""
Mina — mundo de bloques de Manu
===============================
Un mundo 2D de bloques hecho al azar: cielo, pasto, tierra, piedra, cuevas y
minerales. Picas bloques, los pones en otro lado, crafteas herramientas,
sobrevives a la noche y guardas tu mundo.

Controles:
  A / D o FLECHAS  -> caminar
  ESPACIO          -> saltar
  CLIC IZQUIERDO   -> picar el bloque bajo el mouse (mantén apretado) / pegarle a un zombie
  CLIC DERECHO     -> poner el bloque que tienes elegido
  1 al 9 / RUEDA   -> elegir casilla del inventario
  C                -> abrir/cerrar el crafteo (y 1-9 para craftear una receta)
  E                -> comer una manzana (si tienes)
  F5 / F9          -> guardar / cargar el mundo (mundo.json)
  R                -> revivir cuando moriste
  ESC              -> salir
  Las teclas se cambian en controles.txt (al lado de este archivo).

Todo se dibuja con rectángulos y detalles pintados. No hay imágenes.
"""

import json
import math
import os
import random

import pygame

# ---------- Ajustes (cámbialos y prueba qué pasa) ----------
TILE = 24                       # tamaño de cada bloque en píxeles
ANCHO, ALTO = 960, 600          # tamaño de la ventana
FPS = 60
MUNDO_ANCHO, MUNDO_ALTO = 240, 90   # tamaño del mundo en bloques
SEMILLA = None                  # pon un número para que el mundo salga siempre igual

VELOCIDAD = 3.2
GRAVEDAD = 0.45
SALTO = -8.2
ALCANCE = 5 * TILE              # hasta dónde llegas a picar/poner
VIDA_MAX = 10
COMIDA_MAX = 10
SEGUNDOS_POR_COMIDA = 25        # cada tantos segundos baja 1 de comida
CAIDA_DANO = 11                 # si caes más rápido que esto, te duele

DIA_DURACION = 180              # segundos que dura un día completo (día + noche)
ZOMBIES_MAX = 5
ZOMBIE_VIDA = 3
ZOMBIE_VEL = 1.4

# ---------- Bloques ----------
AIRE, PASTO, TIERRA, PIEDRA, CARBON, HIERRO, ORO, DIAMANTE = range(8)
MADERA, HOJAS, TABLAS, MESA, ANTORCHA, HOJAS_MANZANA = range(8, 14)
CHARS = "0123456789ABCD"        # para guardar el mundo como texto

COLOR_BLOQUE = {
    PASTO: (95, 170, 60), TIERRA: (130, 90, 55), PIEDRA: (120, 120, 125),
    CARBON: (120, 120, 125), HIERRO: (120, 120, 125), ORO: (120, 120, 125), DIAMANTE: (120, 120, 125),
    MADERA: (105, 75, 40), HOJAS: (50, 130, 45), TABLAS: (185, 140, 80),
    MESA: (160, 115, 60), ANTORCHA: None, HOJAS_MANZANA: (50, 130, 45),
}
COLOR_MINERAL = {CARBON: (35, 35, 35), HIERRO: (200, 160, 130), ORO: (255, 210, 50), DIAMANTE: (90, 230, 230)}
NOMBRE_BLOQUE = {
    PASTO: "pasto", TIERRA: "tierra", PIEDRA: "piedra", CARBON: "carbón", HIERRO: "hierro",
    ORO: "oro", DIAMANTE: "diamante", MADERA: "madera", HOJAS: "hojas", TABLAS: "tablas",
    MESA: "mesa", ANTORCHA: "antorcha", HOJAS_MANZANA: "hojas",
}
# cuántos "golpes de mano" aguanta cada bloque
DUREZA = {
    PASTO: 15, TIERRA: 15, MADERA: 25, HOJAS: 5, HOJAS_MANZANA: 5, TABLAS: 15, MESA: 15,
    ANTORCHA: 1, PIEDRA: 50, CARBON: 60, HIERRO: 80, ORO: 90, DIAMANTE: 120,
}
# nivel mínimo de pico para poder sacar el bloque (0 = mano)
PICO_MINIMO = {HIERRO: 1, ORO: 1, DIAMANTE: 2}
# qué te da cada bloque al picarlo
DROP = {
    PASTO: "tierra", TIERRA: "tierra", PIEDRA: "piedra", CARBON: "carbon", HIERRO: "hierro",
    ORO: "oro", DIAMANTE: "diamante", MADERA: "madera", HOJAS: None, HOJAS_MANZANA: "manzana",
    TABLAS: "tablas", MESA: "mesa", ANTORCHA: "antorcha",
}
NO_SOLIDOS = {AIRE, ANTORCHA}

# ---------- Ítems ----------
BLOQUE_DE_ITEM = {
    "tierra": TIERRA, "piedra": PIEDRA, "madera": MADERA, "hojas": HOJAS,
    "tablas": TABLAS, "mesa": MESA, "antorcha": ANTORCHA,
}
COLOR_ITEM = {
    "tierra": (130, 90, 55), "piedra": (120, 120, 125), "madera": (105, 75, 40), "hojas": (50, 130, 45),
    "tablas": (185, 140, 80), "palo": (150, 110, 60), "mesa": (160, 115, 60), "antorcha": (255, 200, 60),
    "carbon": (35, 35, 35), "hierro": (200, 160, 130), "oro": (255, 210, 50), "diamante": (90, 230, 230),
    "manzana": (220, 40, 40), "pico_piedra": (120, 120, 125), "pico_hierro": (200, 160, 130),
    "pico_diamante": (90, 230, 230),
}
NOMBRE_ITEM = {
    "tierra": "Tierra", "piedra": "Piedra", "madera": "Madera", "hojas": "Hojas", "tablas": "Tablas",
    "palo": "Palo", "mesa": "Mesa", "antorcha": "Antorcha", "carbon": "Carbón", "hierro": "Hierro",
    "oro": "Oro", "diamante": "Diamante", "manzana": "Manzana", "pico_piedra": "Pico de piedra",
    "pico_hierro": "Pico de hierro", "pico_diamante": "Pico de diamante",
}
# (nivel, poder): con qué fuerza pica cada herramienta
PICOS = {"pico_piedra": (1, 2.5), "pico_hierro": (2, 4.0), "pico_diamante": (3, 7.0)}

# ---------- Recetas: (nombre, {ingrediente: cantidad}, (item, cantidad), necesita_mesa) ----------
RECETAS = [
    ("4 Tablas", {"madera": 1}, ("tablas", 4), False),
    ("4 Palos", {"tablas": 2}, ("palo", 4), False),
    ("Mesa de crafteo", {"tablas": 4}, ("mesa", 1), False),
    ("4 Antorchas", {"carbon": 1, "palo": 1}, ("antorcha", 4), False),
    ("Pico de piedra", {"piedra": 3, "palo": 2}, ("pico_piedra", 1), True),
    ("Pico de hierro", {"hierro": 3, "palo": 2}, ("pico_hierro", 1), True),
    ("Pico de diamante", {"diamante": 3, "palo": 2}, ("pico_diamante", 1), True),
]

# ---------- Colores ----------
CIELO_DIA = (120, 190, 240)
CIELO_NOCHE = (15, 15, 40)
PIEL = (240, 200, 160)
CAMISA = (60, 110, 200)
PANTALON = (50, 50, 90)
ZOMBIE = (90, 160, 80)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
CORAZON = (230, 60, 90)
CORAZON_VACIO = (70, 50, 70)
COMIDA_COLOR = (220, 40, 40)


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "izquierda": "a", "derecha": "d", "saltar": "space", "crafteo": "c", "comer": "e",
    "guardar": "f5", "cargar": "f9", "reiniciar": "r", "salir": "escape",
}


def carpeta():
    return os.path.dirname(os.path.abspath(__file__))


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(carpeta(), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}      # se llena en main(), después de pygame.init()
TECLAS_CASILLA = [pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5,
                  pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9]


# ---------- Ruido: números "al azar pero suaves" para hacer el terreno ----------
def ruido_1d(x, escala, azar):
    """Suma de ondas: sirve para la altura del suelo."""
    return (math.sin(x / escala + azar[0]) + 0.5 * math.sin(x / (escala / 2.3) + azar[1])
            + 0.25 * math.sin(x / (escala / 5.1) + azar[2]))


class Ruido2D:
    """Una rejilla de números al azar; entre medio se interpola (queda suave).
    Sirve para las cuevas."""

    def __init__(self, rnd, paso=7):
        self.paso = paso
        self.rejilla = {}
        self.rnd = rnd

    def punto(self, i, j):
        if (i, j) not in self.rejilla:
            self.rejilla[(i, j)] = self.rnd.random()
        return self.rejilla[(i, j)]

    def valor(self, x, y):
        i, j = x // self.paso, y // self.paso
        fx, fy = (x % self.paso) / self.paso, (y % self.paso) / self.paso
        fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)     # curva suave
        a = self.punto(i, j) * (1 - fx) + self.punto(i + 1, j) * fx
        b = self.punto(i, j + 1) * (1 - fx) + self.punto(i + 1, j + 1) * fx
        return a * (1 - fy) + b * fy


# ---------- El mundo ----------
class Mundo:
    def __init__(self, generar=True):
        self.ancho, self.alto = MUNDO_ANCHO, MUNDO_ALTO
        self.bloques = [[AIRE] * self.ancho for _ in range(self.alto)]
        self.cielo_y = [0] * self.ancho     # primer bloque sólido de cada columna (para la luz)
        self.antorchas = set()
        if generar:
            self.generar()

    # --- leer y cambiar bloques ---
    def get(self, x, y):
        if 0 <= x < self.ancho and 0 <= y < self.alto:
            return self.bloques[y][x]
        return AIRE if y < 0 else PIEDRA            # afuera: aire arriba, piedra en los bordes y abajo

    def set(self, x, y, b):
        if not (0 <= x < self.ancho and 0 <= y < self.alto):
            return
        self.bloques[y][x] = b
        if b == ANTORCHA:
            self.antorchas.add((x, y))
        else:
            self.antorchas.discard((x, y))
        self.recalcular_cielo(x)

    def solido(self, x, y):
        return self.get(x, y) not in NO_SOLIDOS

    def recalcular_cielo(self, x):
        y = 0
        while y < self.alto and self.bloques[y][x] in NO_SOLIDOS:
            y += 1
        self.cielo_y[x] = y

    def recalcular_todo(self):
        self.antorchas = set()
        for x in range(self.ancho):
            self.recalcular_cielo(x)
            for y in range(self.alto):
                if self.bloques[y][x] == ANTORCHA:
                    self.antorchas.add((x, y))

    # --- generación ---
    def generar(self):
        rnd = random.Random(SEMILLA)
        azar = [rnd.uniform(0, 100) for _ in range(3)]
        base = self.alto * 0.38
        alturas = [int(base + ruido_1d(x, 22, azar) * 6) for x in range(self.ancho)]
        cuevas = Ruido2D(rnd, 7)
        cuevas2 = Ruido2D(rnd, 3)

        for x in range(self.ancho):
            h = alturas[x]
            grosor_tierra = rnd.randint(3, 6)
            for y in range(self.alto):
                if y < h:
                    b = AIRE
                elif y == h:
                    b = PASTO
                elif y <= h + grosor_tierra:
                    b = TIERRA
                else:
                    b = PIEDRA
                    # cuevas: donde el ruido es alto, queda hueco
                    if y > h + 4 and cuevas.valor(x, y) * 0.75 + cuevas2.valor(x, y) * 0.25 > 0.66:
                        b = AIRE
                self.bloques[y][x] = b

        # minerales: pequeños grupitos dentro de la piedra
        for _ in range(int(self.ancho * 2.5)):
            x = rnd.randrange(self.ancho)
            y = rnd.randrange(alturas[x] + 6, self.alto)
            prof = y - alturas[x]
            r = rnd.random()
            if prof > 45 and r < 0.06:
                mineral = DIAMANTE
            elif prof > 25 and r < 0.18:
                mineral = ORO
            elif prof > 10 and r < 0.45:
                mineral = HIERRO
            else:
                mineral = CARBON
            for _ in range(rnd.randint(2, 5)):
                if 0 <= x < self.ancho and 0 <= y < self.alto and self.bloques[y][x] == PIEDRA:
                    self.bloques[y][x] = mineral
                x += rnd.choice((-1, 0, 1))
                y += rnd.choice((-1, 0, 1))

        # árboles sobre el pasto
        x = 3
        while x < self.ancho - 3:
            h = alturas[x]
            if self.bloques[h][x] == PASTO and rnd.random() < 0.14:
                tronco = rnd.randint(4, 6)
                for y in range(h - tronco, h):
                    self.bloques[y][x] = MADERA
                copa_y = h - tronco
                for dy in range(-2, 2):
                    for dx in range(-2, 3):
                        if abs(dx) == 2 and abs(dy + 1) == 1:
                            continue
                        yy, xx = copa_y + dy, x + dx
                        if 0 <= yy < self.alto and self.bloques[yy][xx] == AIRE:
                            self.bloques[yy][xx] = HOJAS_MANZANA if rnd.random() < 0.15 else HOJAS
                x += rnd.randint(4, 8)
            else:
                x += 1
        self.recalcular_todo()

    # --- guardar y cargar ---
    def a_texto(self):
        return ["".join(CHARS[b] for b in fila) for fila in self.bloques]

    def desde_texto(self, filas):
        self.alto, self.ancho = len(filas), len(filas[0])
        self.bloques = [[CHARS.index(c) for c in fila] for fila in filas]
        self.cielo_y = [0] * self.ancho
        self.recalcular_todo()

    def rects_solidos(self, rect):
        """Los bloques sólidos que están alrededor de un rect (para chocar)."""
        x0, x1 = rect.left // TILE - 1, rect.right // TILE + 1
        y0, y1 = rect.top // TILE - 1, rect.bottom // TILE + 1
        lista = []
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                if self.solido(x, y):
                    lista.append(pygame.Rect(x * TILE, y * TILE, TILE, TILE))
        return lista


def mover_con_choques(rect, dx, dy, bloques):
    """Mueve el rect y lo frena contra los bloques. Devuelve (toca_suelo, toca_pared)."""
    toca_suelo = toca_pared = False
    rect.x += dx
    for b in bloques:
        if rect.colliderect(b):
            toca_pared = True
            if dx > 0:
                rect.right = b.left
            elif dx < 0:
                rect.left = b.right
    rect.y += dy
    for b in bloques:
        if rect.colliderect(b):
            if dy > 0:
                rect.bottom = b.top
                toca_suelo = True
            elif dy < 0:
                rect.top = b.bottom
    return toca_suelo, toca_pared


# ---------- Cosas con gravedad (jugador y zombies comparten esto) ----------
class Criatura:
    def __init__(self, x, y, ancho=18, alto=44):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.vel_y = 0.0
        self.en_suelo = False
        self.mira_derecha = True

    def fisica(self, dx, mundo):
        self.vel_y = min(self.vel_y + GRAVEDAD, 14)
        dy = int(self.vel_y)
        if self.vel_y > 0 and dy == 0:
            dy = 1
        cayendo_a = self.vel_y
        solidos = mundo.rects_solidos(self.rect.inflate(abs(dx) * 2 + 4, abs(dy) * 2 + 4))
        self.en_suelo, pared = mover_con_choques(self.rect, int(dx), dy, solidos)
        if self.en_suelo:
            self.vel_y = 0
        if self.rect.top < 0:
            self.rect.top = 0
        return pared, cayendo_a


class Jugador(Criatura):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.vida = VIDA_MAX
        self.comida = COMIDA_MAX
        self.invulnerable = 0
        self.inventario = [[None, 0] for _ in range(9)]
        self.casilla = 0
        self.golpe_espera = 0

    # --- inventario ---
    def agregar(self, item, cantidad=1):
        for slot in self.inventario:
            if slot[0] == item and slot[1] < 99:
                slot[1] += cantidad
                return True
        for slot in self.inventario:
            if slot[0] is None:
                slot[0], slot[1] = item, cantidad
                return True
        return False

    def cuantos(self, item):
        return sum(c for i, c in self.inventario if i == item)

    def quitar(self, item, cantidad=1):
        for slot in self.inventario:
            if slot[0] == item:
                usa = min(cantidad, slot[1])
                slot[1] -= usa
                cantidad -= usa
                if slot[1] == 0:
                    slot[0] = None
                if cantidad == 0:
                    return

    def item_en_mano(self):
        return self.inventario[self.casilla][0]

    def pico(self):
        """(nivel, poder) de lo que tienes en la mano. Mano pelada = (0, 1)."""
        return PICOS.get(self.item_en_mano(), (0, 1.0))

    def herir(self, cuanto, desde_x=None):
        if self.invulnerable > 0:
            return
        self.vida -= cuanto
        self.invulnerable = 45
        if desde_x is not None:
            self.vel_y = -4

    def dibujar(self, pantalla, cam):
        if self.invulnerable > 0 and (self.invulnerable // 4) % 2 == 0:
            return
        r = self.rect.move(-cam[0], -cam[1])
        lado = 1 if self.mira_derecha else -1
        pygame.draw.rect(pantalla, PANTALON, (r.left + 2, r.bottom - 16, 6, 16))
        pygame.draw.rect(pantalla, PANTALON, (r.right - 8, r.bottom - 16, 6, 16))
        pygame.draw.rect(pantalla, CAMISA, (r.left, r.top + 14, r.width, 16))
        pygame.draw.rect(pantalla, PIEL, (r.left + 2, r.top, 14, 14))
        pygame.draw.rect(pantalla, NEGRO, (r.centerx + 3 * lado, r.top + 5, 2, 2))
        # brazo con la herramienta
        item = self.item_en_mano()
        bx = r.centerx + 10 * lado
        pygame.draw.line(pantalla, PIEL, (r.centerx, r.top + 18), (bx, r.top + 24), 4)
        if item in PICOS:
            pygame.draw.line(pantalla, (150, 110, 60), (bx, r.top + 24), (bx + 8 * lado, r.top + 8), 3)
            pygame.draw.rect(pantalla, COLOR_ITEM[item], (bx + 8 * lado - 5, r.top + 4, 10, 6))
        elif item:
            pygame.draw.rect(pantalla, COLOR_ITEM[item], (bx - 4, r.top + 18, 8, 8))


class Zombie(Criatura):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.vida = ZOMBIE_VIDA
        self.herido = 0
        self.empujon = 0

    def actualizar(self, mundo, jugador):
        dx = ZOMBIE_VEL if jugador.rect.centerx > self.rect.centerx else -ZOMBIE_VEL
        self.mira_derecha = dx > 0
        if abs(jugador.rect.centerx - self.rect.centerx) < 6:
            dx = 0
        if self.empujon:
            dx = self.empujon
            self.empujon = int(self.empujon * 0.7)
        pared, _ = self.fisica(dx, mundo)
        # si choca con algo y está en el suelo, salta
        if pared and self.en_suelo:
            self.vel_y = SALTO
        # si el jugador está más arriba y cerca, también intenta saltar
        elif self.en_suelo and jugador.rect.bottom < self.rect.top and abs(jugador.rect.centerx - self.rect.centerx) < TILE * 2:
            self.vel_y = SALTO
        if self.herido > 0:
            self.herido -= 1

    def golpear(self, cuanto, desde_x):
        self.vida -= cuanto
        self.herido = 10
        self.empujon = 6 if self.rect.centerx > desde_x else -6
        self.vel_y = -3

    def dibujar(self, pantalla, cam):
        r = self.rect.move(-cam[0], -cam[1])
        color = BLANCO if self.herido > 6 else ZOMBIE
        lado = 1 if self.mira_derecha else -1
        pygame.draw.rect(pantalla, (40, 70, 40), (r.left + 2, r.bottom - 16, 6, 16))
        pygame.draw.rect(pantalla, (40, 70, 40), (r.right - 8, r.bottom - 16, 6, 16))
        pygame.draw.rect(pantalla, color, (r.left, r.top + 14, r.width, 16))
        pygame.draw.rect(pantalla, color, (r.left + 2, r.top, 14, 14))
        pygame.draw.rect(pantalla, NEGRO, (r.centerx + 3 * lado - 2, r.top + 5, 3, 3))
        pygame.draw.rect(pantalla, NEGRO, (r.centerx - 3 * lado - 2, r.top + 5, 3, 3))
        pygame.draw.line(pantalla, color, (r.centerx, r.top + 18), (r.centerx + 14 * lado, r.top + 18), 4)


# ---------- Día y noche ----------
def luz_del_dia(tiempo):
    """De 0 (noche cerrada) a 1 (pleno día), según los segundos de juego."""
    t = (tiempo % DIA_DURACION) / DIA_DURACION
    if t < 0.42:
        return 1.0
    if t < 0.5:
        return 1 - (t - 0.42) / 0.08
    if t < 0.88:
        return 0.0
    return (t - 0.88) / 0.12


def mezclar(c1, c2, t):
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def calcular_luz(mundo, x0, y0, w, h, luz_dia):
    """Cuánta luz (0 a 1) hay en cada bloque de la zona visible."""
    luz = [[0.0] * w for _ in range(h)]
    minimo = 0.22 + 0.78 * luz_dia          # de noche la superficie se ve poquito
    for j in range(h):
        y = y0 + j
        for i in range(w):
            x = x0 + i
            if 0 <= x < mundo.ancho and y <= mundo.cielo_y[x]:
                luz[j][i] = minimo
    # antorchas: un círculo de luz que se apaga con la distancia
    for (ax, ay) in mundo.antorchas:
        if x0 - 7 <= ax < x0 + w + 7 and y0 - 7 <= ay < y0 + h + 7:
            for j in range(max(0, ay - 7 - y0), min(h, ay + 8 - y0)):
                for i in range(max(0, ax - 7 - x0), min(w, ax + 8 - x0)):
                    d = math.hypot(x0 + i - ax, y0 + j - ay)
                    luz[j][i] = max(luz[j][i], 1 - d / 7.5)
    # la luz se "desparrama" a los vecinos (así las cuevas cerca de la entrada se ven)
    for _ in range(2):
        for j in range(h):
            for i in range(1, w):
                luz[j][i] = max(luz[j][i], luz[j][i - 1] - 0.18)
            for i in range(w - 2, -1, -1):
                luz[j][i] = max(luz[j][i], luz[j][i + 1] - 0.18)
        for i in range(w):
            for j in range(1, h):
                luz[j][i] = max(luz[j][i], luz[j - 1][i] - 0.18)
            for j in range(h - 2, -1, -1):
                luz[j][i] = max(luz[j][i], luz[j + 1][i] - 0.18)
    return luz


# ---------- Dibujar bloques ----------
def dibujar_bloque(pantalla, b, px, py):
    r = pygame.Rect(px, py, TILE, TILE)
    if b == ANTORCHA:
        pygame.draw.rect(pantalla, (150, 110, 60), (px + TILE // 2 - 2, py + 8, 4, TILE - 8))
        pygame.draw.rect(pantalla, (255, 200, 60), (px + TILE // 2 - 4, py + 2, 8, 8))
        pygame.draw.rect(pantalla, (255, 120, 30), (px + TILE // 2 - 2, py + 4, 4, 4))
        return
    color = COLOR_BLOQUE[b]
    pygame.draw.rect(pantalla, color, r)
    oscuro = tuple(max(0, c - 35) for c in color)
    if b == PASTO:
        pygame.draw.rect(pantalla, COLOR_BLOQUE[TIERRA], (px, py + 7, TILE, TILE - 7))
        pygame.draw.rect(pantalla, color, (px, py, TILE, 7))
        for k in range(0, TILE, 6):
            pygame.draw.rect(pantalla, color, (px + k, py + 7, 3, 3))
    elif b in COLOR_MINERAL:
        m = COLOR_MINERAL[b]
        for (dx, dy) in ((4, 5), (14, 4), (8, 14), (17, 15)):
            pygame.draw.rect(pantalla, m, (px + dx, py + dy, 5, 5))
    elif b == MADERA:
        pygame.draw.rect(pantalla, oscuro, (px + 4, py, 3, TILE))
        pygame.draw.rect(pantalla, oscuro, (px + 15, py, 3, TILE))
    elif b in (HOJAS, HOJAS_MANZANA):
        pygame.draw.rect(pantalla, oscuro, (px + 3, py + 3, 5, 5))
        pygame.draw.rect(pantalla, oscuro, (px + 14, py + 12, 5, 5))
        if b == HOJAS_MANZANA:
            pygame.draw.circle(pantalla, COMIDA_COLOR, (px + 15, py + 7), 4)
    elif b == TABLAS:
        pygame.draw.line(pantalla, oscuro, (px, py + 8), (px + TILE, py + 8), 2)
        pygame.draw.line(pantalla, oscuro, (px, py + 16), (px + TILE, py + 16), 2)
    elif b == MESA:
        pygame.draw.rect(pantalla, oscuro, (px + 2, py + 8, 4, TILE - 8))
        pygame.draw.rect(pantalla, oscuro, (px + TILE - 6, py + 8, 4, TILE - 8))
        pygame.draw.rect(pantalla, (120, 120, 125), (px + 8, py + 2, 8, 4))
    elif b == PIEDRA:
        pygame.draw.rect(pantalla, oscuro, (px + 3, py + 6, 8, 3))
        pygame.draw.rect(pantalla, oscuro, (px + 13, py + 15, 7, 3))
    pygame.draw.rect(pantalla, oscuro, r, 1)


def dibujar_item(pantalla, item, cx, cy, tam=16):
    """Un ítem chiquito para el inventario."""
    c = COLOR_ITEM[item]
    if item in PICOS:
        pygame.draw.line(pantalla, (150, 110, 60), (cx - 6, cy + 7), (cx + 6, cy - 5), 3)
        pygame.draw.rect(pantalla, c, (cx, cy - 9, 10, 6))
    elif item == "palo":
        pygame.draw.line(pantalla, c, (cx - 6, cy + 6), (cx + 6, cy - 6), 3)
    elif item == "manzana":
        pygame.draw.circle(pantalla, c, (cx, cy + 1), 7)
        pygame.draw.line(pantalla, (80, 50, 20), (cx, cy - 6), (cx + 2, cy - 10), 2)
    elif item == "antorcha":
        pygame.draw.rect(pantalla, (150, 110, 60), (cx - 2, cy - 2, 4, 10))
        pygame.draw.rect(pantalla, c, (cx - 4, cy - 8, 8, 7))
    elif item in ("carbon", "hierro", "oro", "diamante"):
        pygame.draw.rect(pantalla, (120, 120, 125), (cx - tam // 2, cy - tam // 2, tam, tam))
        for (dx, dy) in ((-5, -5), (2, -3), (-3, 3), (4, 4)):
            pygame.draw.rect(pantalla, c, (cx + dx, cy + dy, 4, 4))
    else:
        pygame.draw.rect(pantalla, c, (cx - tam // 2, cy - tam // 2, tam, tam))
        pygame.draw.rect(pantalla, tuple(max(0, k - 40) for k in c), (cx - tam // 2, cy - tam // 2, tam, tam), 1)


def texto(pantalla, fuente, msg, x, y, color=BLANCO, centrado=False):
    s = fuente.render(msg, True, NEGRO)
    t = fuente.render(msg, True, color)
    if centrado:
        pantalla.blit(s, s.get_rect(center=(x + 1, y + 1)))
        pantalla.blit(t, t.get_rect(center=(x, y)))
    else:
        pantalla.blit(s, (x + 1, y + 1))
        pantalla.blit(t, (x, y))


# ---------- Crafteo ----------
def mesa_cerca(mundo, jugador):
    cx, cy = jugador.rect.centerx // TILE, jugador.rect.centery // TILE
    for y in range(cy - 4, cy + 5):
        for x in range(cx - 5, cx + 6):
            if mundo.get(x, y) == MESA:
                return True
    return False


def puede_craftear(receta, jugador, hay_mesa):
    nombre, ingredientes, resultado, necesita_mesa = receta
    if necesita_mesa and not hay_mesa:
        return False
    return all(jugador.cuantos(i) >= n for i, n in ingredientes.items())


def craftear(receta, jugador, hay_mesa):
    if not puede_craftear(receta, jugador, hay_mesa):
        return False
    nombre, ingredientes, (item, cantidad), _ = receta
    for i, n in ingredientes.items():
        jugador.quitar(i, n)
    jugador.agregar(item, cantidad)
    return True


# ---------- Guardar y cargar ----------
def guardar_mundo(j):
    datos = dict(filas=j["mundo"].a_texto(), jugador=[j["jugador"].rect.x, j["jugador"].rect.y],
                 inventario=j["jugador"].inventario, vida=j["jugador"].vida,
                 comida=j["jugador"].comida, tiempo=j["tiempo"])
    with open(os.path.join(carpeta(), "mundo.json"), "w", encoding="utf-8") as f:
        json.dump(datos, f)


def cargar_mundo():
    with open(os.path.join(carpeta(), "mundo.json"), encoding="utf-8") as f:
        datos = json.load(f)
    mundo = Mundo(generar=False)
    mundo.desde_texto(datos["filas"])
    jugador = Jugador(*datos["jugador"])
    jugador.inventario = [[i, c] for i, c in datos["inventario"]]
    jugador.vida = datos["vida"]
    jugador.comida = datos["comida"]
    return dict(mundo=mundo, jugador=jugador, tiempo=datos["tiempo"], zombies=[],
                picando=None, mensaje=("", 0), crafteo=False, estado="jugando", comida_timer=0.0)


def nuevo_juego():
    mundo = Mundo()
    x = mundo.ancho // 2
    jugador = Jugador(x * TILE + 3, (mundo.cielo_y[x] - 2) * TILE)
    return dict(mundo=mundo, jugador=jugador, tiempo=0.0, zombies=[], picando=None,
                mensaje=("", 0), crafteo=False, estado="jugando", comida_timer=0.0)


def avisar(j, msg):
    j["mensaje"] = (msg, 150)


# ---------- El juego ----------
def main():
    pygame.init()
    TECLA.update(cargar_controles())
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Mina — mundo de bloques de Manu")
    reloj = pygame.time.Clock()
    fuente = pygame.font.SysFont(None, 24)
    fuente_grande = pygame.font.SysFont(None, 64)
    sombra = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)

    j = nuevo_juego()
    avisar(j, "¡Bienvenido! Pica un árbol con clic izquierdo para empezar.")
    def camara(mundo, p):
        return (max(0, min(p.rect.centerx - ANCHO // 2, mundo.ancho * TILE - ANCHO)),
                max(0, min(p.rect.centery - ALTO // 2, mundo.alto * TILE - ALTO)))

    corriendo = True
    while corriendo:
        mundo, p = j["mundo"], j["jugador"]
        hay_mesa = mesa_cerca(mundo, p)
        cam = camara(mundo, p)

        # 1) Eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                corriendo = False
            elif e.type == pygame.KEYDOWN:
                if e.key == TECLA["salir"]:
                    corriendo = False
                elif e.key == TECLA["guardar"]:
                    guardar_mundo(j)
                    avisar(j, "Mundo guardado en mundo.json")
                elif e.key == TECLA["cargar"]:
                    try:
                        j = cargar_mundo()
                        mundo, p = j["mundo"], j["jugador"]
                        avisar(j, "Mundo cargado")
                    except (OSError, ValueError, KeyError):
                        avisar(j, "No hay mundo guardado todavía (F5 guarda)")
                elif j["estado"] == "muerto":
                    if e.key == TECLA["reiniciar"]:
                        x = mundo.ancho // 2
                        p.rect.topleft = (x * TILE + 3, (mundo.cielo_y[x] - 2) * TILE)
                        p.vida, p.comida, p.vel_y = VIDA_MAX, COMIDA_MAX, 0
                        j["zombies"] = []
                        j["estado"] = "jugando"
                elif e.key == TECLA["crafteo"]:
                    j["crafteo"] = not j["crafteo"]
                elif e.key in TECLAS_CASILLA:
                    n = TECLAS_CASILLA.index(e.key)
                    if j["crafteo"]:
                        if n < len(RECETAS):
                            if craftear(RECETAS[n], p, hay_mesa):
                                avisar(j, f"Crafteaste: {RECETAS[n][0]}")
                            elif RECETAS[n][3] and not hay_mesa:
                                avisar(j, "Necesitas una mesa de crafteo cerca")
                            else:
                                avisar(j, "Te faltan materiales")
                    else:
                        p.casilla = n
                elif e.key == TECLA["saltar"] and p.en_suelo:
                    p.vel_y = SALTO
                elif e.key == TECLA["comer"]:
                    if p.cuantos("manzana") > 0:
                        p.quitar("manzana")
                        p.comida = min(COMIDA_MAX, p.comida + 3)
                        p.vida = min(VIDA_MAX, p.vida + 1)
                        avisar(j, "Ñam")
                    else:
                        avisar(j, "No tienes manzanas (están en los árboles)")
            elif e.type == pygame.MOUSEWHEEL:
                p.casilla = (p.casilla - e.y) % 9
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 3 and j["estado"] == "jugando":
                # clic derecho: poner bloque
                mx, my = pygame.mouse.get_pos()
                tx, ty = (mx + cam[0]) // TILE, (my + cam[1]) // TILE
                item = p.item_en_mano()
                destino = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
                cerca = math.hypot(destino.centerx - p.rect.centerx, destino.centery - p.rect.centery) <= ALCANCE
                if item in BLOQUE_DE_ITEM and cerca and mundo.get(tx, ty) == AIRE and not destino.colliderect(p.rect):
                    # tiene que apoyarse en algo (que no quede flotando)
                    apoyo = any(mundo.get(tx + dx, ty + dy) != AIRE for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
                    if apoyo:
                        mundo.set(tx, ty, BLOQUE_DE_ITEM[item])
                        p.quitar(item)

        # 2) Mover
        if j["estado"] == "jugando":
            dt = 1 / FPS
            j["tiempo"] += dt
            teclas = pygame.key.get_pressed()
            dx = 0
            if teclas[TECLA["izquierda"]] or teclas[pygame.K_LEFT]:
                dx = -VELOCIDAD
                p.mira_derecha = False
            if teclas[TECLA["derecha"]] or teclas[pygame.K_RIGHT]:
                dx = VELOCIDAD
                p.mira_derecha = True
            if teclas[TECLA["saltar"]] and p.en_suelo:
                p.vel_y = SALTO
            _, cayendo = p.fisica(dx, mundo)
            if p.en_suelo and cayendo > CAIDA_DANO:
                p.herir(int((cayendo - CAIDA_DANO) / 1.5) + 1)
                avisar(j, "¡Ay! Caída fuerte")
            if p.invulnerable > 0:
                p.invulnerable -= 1
            if p.golpe_espera > 0:
                p.golpe_espera -= 1

            # comida: baja con el tiempo; si llega a 0 pierdes vida
            j["comida_timer"] += dt
            if j["comida_timer"] >= SEGUNDOS_POR_COMIDA:
                j["comida_timer"] = 0
                if p.comida > 0:
                    p.comida -= 1
                else:
                    p.vida -= 1
                    avisar(j, "¡Tienes hambre! Come manzanas (E)")

            # clic izquierdo mantenido: picar o pegarle a un zombie
            cam = camara(mundo, p)
            if pygame.mouse.get_pressed()[0] and not j["crafteo"]:
                mx, my = pygame.mouse.get_pos()
                wx, wy = mx + cam[0], my + cam[1]
                tx, ty = wx // TILE, wy // TILE
                nivel, poder = p.pico()
                # ¿le pegaste a un zombie?
                zombie = next((z for z in j["zombies"] if z.rect.collidepoint(wx, wy)), None)
                if zombie and p.golpe_espera == 0 and math.hypot(zombie.rect.centerx - p.rect.centerx, zombie.rect.centery - p.rect.centery) <= ALCANCE:
                    zombie.golpear(1 + nivel, p.rect.centerx)
                    p.golpe_espera = 20
                else:
                    b = mundo.get(tx, ty)
                    cerca = math.hypot(tx * TILE + TILE // 2 - p.rect.centerx, ty * TILE + TILE // 2 - p.rect.centery) <= ALCANCE
                    if b != AIRE and cerca:
                        if PICO_MINIMO.get(b, 0) > nivel:
                            avisar(j, f"Necesitas un pico mejor para el {NOMBRE_BLOQUE[b]}")
                            j["picando"] = None
                        else:
                            if j["picando"] and j["picando"][0] == (tx, ty):
                                j["picando"][1] += poder
                            else:
                                j["picando"] = [(tx, ty), poder]
                            if j["picando"][1] >= DUREZA[b]:
                                mundo.set(tx, ty, AIRE)
                                drop = DROP.get(b)
                                if drop and not p.agregar(drop):
                                    avisar(j, "Inventario lleno")
                                j["picando"] = None
                    else:
                        j["picando"] = None
            else:
                j["picando"] = None

            # zombies: aparecen de noche, se van de día
            luz = luz_del_dia(j["tiempo"])
            if luz < 0.3 and len(j["zombies"]) < ZOMBIES_MAX and random.random() < 0.01:
                lado = random.choice((-1, 1))
                zx = p.rect.centerx // TILE + lado * random.randint(22, 30)
                if 0 <= zx < mundo.ancho:
                    j["zombies"].append(Zombie(zx * TILE + 3, (mundo.cielo_y[zx] - 2) * TILE))
            for z in j["zombies"]:
                z.actualizar(mundo, p)
                if z.rect.colliderect(p.rect):
                    p.herir(1, z.rect.centerx)
            j["zombies"] = [z for z in j["zombies"] if z.vida > 0 and (luz < 0.6 or random.random() > 0.02)
                            and abs(z.rect.centerx - p.rect.centerx) < TILE * 60]

            if p.vida <= 0:
                j["estado"] = "muerto"

        cam = camara(mundo, p)
        luz_dia = luz_del_dia(j["tiempo"])

        # 3) Dibujar el mundo
        pantalla.fill(mezclar(CIELO_NOCHE, CIELO_DIA, luz_dia))
        # sol o luna
        t = (j["tiempo"] % DIA_DURACION) / DIA_DURACION
        astro_x = int(ANCHO * ((t * 2) % 1.0))
        if t < 0.5:
            pygame.draw.circle(pantalla, (255, 240, 120), (astro_x, 70), 22)
        else:
            pygame.draw.circle(pantalla, (230, 230, 240), (astro_x, 70), 18)
        x0, y0 = cam[0] // TILE, cam[1] // TILE
        w, h = ANCHO // TILE + 2, ALTO // TILE + 2
        for ty in range(y0, y0 + h):
            for tx in range(x0, x0 + w):
                b = mundo.get(tx, ty)
                if b != AIRE and 0 <= tx < mundo.ancho and 0 <= ty < mundo.alto:
                    dibujar_bloque(pantalla, b, tx * TILE - cam[0], ty * TILE - cam[1])
        # grietas del bloque que estás picando
        if j["picando"]:
            (tx, ty), prog = j["picando"]
            b = mundo.get(tx, ty)
            if b != AIRE:
                frac = min(1, prog / DUREZA[b])
                px, py = tx * TILE - cam[0], ty * TILE - cam[1]
                for k in range(int(frac * 6)):
                    pygame.draw.line(pantalla, NEGRO, (px + 4 + k * 3, py + 3), (px + 12 - k * 2, py + 10 + k * 2), 1)
        for z in j["zombies"]:
            z.dibujar(pantalla, cam)
        p.dibujar(pantalla, cam)

        # 4) Oscuridad: noche y cuevas
        luz = calcular_luz(mundo, x0, y0, w, h, luz_dia)
        sombra.fill((0, 0, 0, 0))
        for jj in range(h):
            for ii in range(w):
                a = int((1 - luz[jj][ii]) * 235)
                if a > 0:
                    sombra.fill((0, 0, 20, a), ((x0 + ii) * TILE - cam[0], (y0 + jj) * TILE - cam[1], TILE, TILE))
        pantalla.blit(sombra, (0, 0))

        # marco del bloque bajo el mouse
        mx, my = pygame.mouse.get_pos()
        tx, ty = (mx + cam[0]) // TILE, (my + cam[1]) // TILE
        cerca = math.hypot(tx * TILE + TILE // 2 - p.rect.centerx, ty * TILE + TILE // 2 - p.rect.centery) <= ALCANCE
        pygame.draw.rect(pantalla, BLANCO if cerca else (120, 120, 120), (tx * TILE - cam[0], ty * TILE - cam[1], TILE, TILE), 2)

        # 5) HUD
        for i in range(VIDA_MAX):
            c = CORAZON if i < p.vida else CORAZON_VACIO
            pygame.draw.rect(pantalla, c, (14 + i * 20, 14, 14, 14))
        for i in range(COMIDA_MAX):
            c = COMIDA_COLOR if i < p.comida else CORAZON_VACIO
            pygame.draw.circle(pantalla, c, (21 + i * 20, 44), 7)
        texto(pantalla, fuente, "Día" if luz_dia > 0.5 else "Noche", ANCHO - 70, 14)
        if j["mensaje"][1] > 0:
            texto(pantalla, fuente, j["mensaje"][0], ANCHO // 2, 80, centrado=True)
            j["mensaje"] = (j["mensaje"][0], j["mensaje"][1] - 1)
        # barra de inventario
        base_x = ANCHO // 2 - 9 * 46 // 2
        for i, (item, cant) in enumerate(p.inventario):
            r = pygame.Rect(base_x + i * 46, ALTO - 52, 42, 42)
            pygame.draw.rect(pantalla, (30, 30, 40), r)
            pygame.draw.rect(pantalla, BLANCO if i == p.casilla else (90, 90, 100), r, 3 if i == p.casilla else 1)
            texto(pantalla, fuente, str(i + 1), r.left + 3, r.top + 2, (170, 170, 170))
            if item:
                dibujar_item(pantalla, item, r.centerx, r.centery)
                if cant > 1:
                    texto(pantalla, fuente, str(cant), r.right - 16, r.bottom - 16)
        item = p.item_en_mano()
        if item:
            texto(pantalla, fuente, NOMBRE_ITEM[item], ANCHO // 2, ALTO - 66, centrado=True)

        # panel de crafteo
        if j["crafteo"]:
            panel = pygame.Rect(ANCHO // 2 - 220, 110, 440, 40 + len(RECETAS) * 30 + 30)
            pygame.draw.rect(pantalla, (25, 25, 35), panel)
            pygame.draw.rect(pantalla, BLANCO, panel, 2)
            texto(pantalla, fuente, "CRAFTEO (aprieta el número)   mesa cerca: " + ("sí" if hay_mesa else "no"), panel.left + 12, panel.top + 10)
            for i, rec in enumerate(RECETAS):
                nombre, ingredientes, _, necesita_mesa = rec
                ok = puede_craftear(rec, p, hay_mesa)
                ing = ", ".join(f"{n} {NOMBRE_ITEM[k].lower()}" for k, n in ingredientes.items())
                extra = "  [mesa]" if necesita_mesa else ""
                texto(pantalla, fuente, f"{i + 1}. {nombre}: {ing}{extra}", panel.left + 12, panel.top + 40 + i * 30,
                      (120, 255, 140) if ok else (150, 150, 150))
            texto(pantalla, fuente, f"{pygame.key.name(TECLA['crafteo']).upper()} cierra", panel.left + 12, panel.bottom - 24, (170, 170, 170))

        if j["estado"] == "muerto":
            texto(pantalla, fuente_grande, "MORISTE", ANCHO // 2, ALTO // 2 - 30, CORAZON, centrado=True)
            texto(pantalla, fuente, f"{pygame.key.name(TECLA['reiniciar']).upper()} para revivir (tu mundo sigue ahí)", ANCHO // 2, ALTO // 2 + 20, centrado=True)

        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
