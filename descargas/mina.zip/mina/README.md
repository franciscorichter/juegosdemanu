# Mina — mundo de bloques de Manu

Un mundo 2D de bloques que se genera al azar cada vez: cielo, pasto, tierra,
piedra, cuevas, árboles con manzanas y minerales (carbón, hierro, oro,
diamante). Picas, construyes, crafteas picos y antorchas, sobrevives a los
zombies de la noche y guardas tu mundo. Todo son rectángulos dibujados: no
hay ni una imagen.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 mina.py

En Windows: `python mina.py`. En Linux/Mac también sirve `./jugar.sh`.

| Tecla | Qué hace |
|---|---|
| **A / D** o flechas | caminar |
| **ESPACIO** | saltar |
| **clic izquierdo** (mantener) | picar el bloque bajo el mouse, o pegarle a un zombie |
| **clic derecho** | poner el bloque que tienes en la mano |
| **1 a 9** o rueda del mouse | elegir casilla del inventario |
| **C** | abrir el crafteo; con el panel abierto, **1-9** craftea esa receta |
| **E** | comer una manzana |
| **F5 / F9** | guardar / cargar el mundo (`mundo.json`) |
| **R** | revivir si moriste (tu mundo sigue igual) |
| **ESC** | salir |

## Cómo se juega bien

1. Pica un árbol (madera) y unas hojas con manzanas.
2. Abre el crafteo con **C**: madera → tablas → palos. Con 4 tablas haces una **mesa**.
3. Pon la mesa en el suelo (clic derecho). Cerca de ella puedes craftear picos.
4. Con 3 piedras y 2 palos: **pico de piedra** (pica más rápido y saca hierro y oro).
5. Con 3 hierros: **pico de hierro** (necesario para el diamante).
6. Carbón + palo = 4 **antorchas**. Ponlas en las cuevas: sin luz no ves nada.
7. De noche salen zombies. Enciérrate con bloques o pégales con clic izquierdo.
8. Los corazones son tu vida; los puntos rojos, tu comida. Come manzanas con **E**.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. El mouse y las
casillas 1-9 son fijas. Nombres válidos: letras, flechas (`up`, `down`, `left`,
`right`), `space`, `return`, `tab`, `left shift`, `f1`...`f12`, números.

## Para cambiar cosas

Arriba de `mina.py`: `MUNDO_ANCHO`/`MUNDO_ALTO` (tamaño del mundo), `SEMILLA`
(un número para que salga siempre el mismo mundo), `DIA_DURACION`, `GRAVEDAD`,
`SALTO`, `ZOMBIES_MAX`... Y en `RECETAS` puedes inventar recetas nuevas.

El mundo se guarda en `mundo.json` como texto: cada fila es una línea de
letras, una por bloque. ¡Ábrelo y míralo!

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
