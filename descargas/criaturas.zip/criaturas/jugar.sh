#!/bin/bash
# Abre Criaturas. Si hay una cajita .venv (con pygame adentro) la usa;
# si no, usa el python3 normal del computador.
cd "$(dirname "$0")"
if [ -x .venv/bin/python ]; then
    exec .venv/bin/python criaturas.py "$@"
else
    exec python3 criaturas.py "$@"
fi
