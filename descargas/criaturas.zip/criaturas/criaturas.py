"""
Criaturas — un RPG de batallas por turnos hecho por Manu
=========================================================
Caminas por un mapa, en el pasto alto salen criaturas salvajes, las
atrapas con esferas, suben de nivel, evolucionan al nivel 16 y al final
peleas contra el campeón.

Controles (todos se cambian en controles.txt, al lado de este archivo):
  FLECHAS        -> caminar / moverse por los menús
  ENTER          -> aceptar / hablar / avanzar el texto
  ESC            -> cancelar / abrir el menú en el mapa
  LEFT SHIFT     -> correr
  F5 / F9        -> guardar / cargar la partida (partida.json)

Archivos del juego:
  datos.py     -> las 12 criaturas, ataques, tipos, entrenadores (tablas)
  logica.py    -> cómo pelean, atrapan, suben de nivel, guardan (sin pygame)
  dibujos.py   -> los dibujos de cada criatura (círculos y polígonos)
  criaturas.py -> este archivo: la ventana, el mapa, los menús y la batalla
  mapa.txt     -> el mapa (¡dibuja el tuyo!)
"""

import array
import math
import os
import random
import sys

import pygame

from datos import (COLOR_TIPO, ESPECIES, ATAQUES, OBJETOS, ENTRENADORES, INICIALES,
                   PASTO, PROB_ENCUENTRO, NOMBRE_TIPO)
from logica import Criatura, Batalla, Partida, texto_estado
from dibujos import dibujar_criatura, silueta

# ---------- Ajustes (cámbialos y prueba qué pasa) ----------
ANCHO, ALTO = 960, 640
FPS = 60
TILE = 40                       # tamaño de cada casilla del mapa
PASO_SEG = 0.14                 # segundos por casilla al caminar
PASO_CORRER = 0.07              # ... y al correr
VEL_TEXTO = 40                  # letras por segundo en las cajas de texto
ESPERA_MSG = 2.0                # segundos hasta que un mensaje avanza solo

CARPETA = os.path.dirname(os.path.abspath(__file__))
RUTA_PARTIDA = os.path.join(CARPETA, "partida.json")
RUTA_MAPA = os.path.join(CARPETA, "mapa.txt")

# colores de la interfaz
BLANCO = (250, 250, 245)
NEGRO = (25, 25, 35)
GRIS = (120, 120, 130)
AZUL_CAJA = (50, 70, 110)
VERDE_HP = (80, 200, 90)
AMARILLO_HP = (230, 200, 60)
ROJO_HP = (220, 70, 60)
AZUL_EXP = (90, 150, 240)

# colores del mapa
COLOR_TILE = {
    ".": (205, 190, 140), ",": (120, 190, 90), ";": (80, 160, 70), '"': (50, 120, 60),
    "#": (40, 110, 50), "~": (70, 140, 220), "H": (190, 120, 80), "+": (240, 240, 240),
    "P": (205, 190, 140), "L": (205, 190, 140),
    "1": (205, 190, 140), "2": (205, 190, 140), "3": (205, 190, 140), "K": (205, 190, 140),
}
SOLIDOS = set("#~H123KL")

LETREROS = [
    "Bienvenido a Villa Brote. Camina por el pasto alto para encontrar criaturas.",
    "Centro de curación: entra a la casa blanca con la cruz roja y tu equipo se cura gratis.",
    "Consejo: una criatura con poca vida o dormida es MUCHO más fácil de atrapar.",
    "Al sur hay pasto más peligroso. Fuego quema Planta, Agua apaga Fuego, Planta bebe Agua...",
    "Aquí vive Tomás el Minero. Dicen que sus rocas le ganan a cualquier chispa.",
    "Eléctrico es súper efectivo contra Agua, pero no le hace casi nada a Roca.",
    "Pasto alto, nivel 13 a 18: aquí salen hasta criaturas evolucionadas.",
    "Al Campeón Orión solo lo enfrenta quien venció a los 3 entrenadores. F5 guarda tu partida.",
]


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "izquierda": "left", "derecha": "right", "arriba": "up", "abajo": "down",
    "aceptar": "return", "cancelar": "escape", "correr": "left shift",
    "menu": "m", "guardar": "f5", "cargar": "f9",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(CARPETA, "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}   # se llena en main(), después de pygame.init()


# ---------- Sonidos (fabricados con matemáticas; si no hay audio, silencio) ----------
class Sonidos:
    def __init__(self):
        self.ok = False
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=1)
            self.frec, _, self.canales = pygame.mixer.get_init()
            self.ok = True
        except pygame.error:
            return
        self.seleccion = self._armar(self._beep(880, 0.05, 0.25))
        self.golpe = self._armar(self._ruido(0.12, 0.5) + self._tono_bajando(300, 80, 0.15))
        self.encuentro = self._armar(self._beep(440, 0.08) + self._beep(660, 0.08) + self._beep(880, 0.15))
        self.captura = self._armar(self._beep(523, 0.1) + self._beep(659, 0.1) + self._beep(784, 0.1) + self._beep(1047, 0.3))
        self.escape = self._armar(self._tono_bajando(600, 200, 0.3))
        self.nivel = self._armar(self._beep(659, 0.08) + self._beep(784, 0.08) + self._beep(988, 0.08) + self._beep(1319, 0.25))
        self.curar = self._armar(self._beep(700, 0.1, 0.3) + self._beep(900, 0.1, 0.3) + self._beep(1100, 0.2, 0.3))
        self.ko = self._armar(self._tono_bajando(500, 60, 0.5, 0.6))
        self.esfera = self._armar(self._beep(300, 0.06, 0.4))
        self.evolucion = self._armar(sum((self._beep(400 + 60 * i, 0.06, 0.3) for i in range(12)), []))

    def _beep(self, hz, seg, volumen=0.5):
        n = int(self.frec * seg)
        return [volumen * math.sin(2 * math.pi * hz * i / self.frec) * min(1.0, (n - i) / (n * 0.3))
                for i in range(n)]

    def _tono_bajando(self, hz_inicio, hz_fin, seg, volumen=0.5):
        n = int(self.frec * seg)
        muestras, fase = [], 0.0
        for i in range(n):
            hz = hz_inicio + (hz_fin - hz_inicio) * i / n
            fase += 2 * math.pi * hz / self.frec
            muestras.append(volumen * math.sin(fase) * (1 - i / n))
        return muestras

    def _ruido(self, seg, volumen=0.4):
        n = int(self.frec * seg)
        return [volumen * random.uniform(-1, 1) * (1 - i / n) for i in range(n)]

    def _armar(self, muestras):
        datos = array.array("h")
        for m in muestras:
            v = int(max(-1.0, min(1.0, m)) * 32767)
            for _ in range(self.canales):
                datos.append(v)
        return pygame.mixer.Sound(buffer=datos.tobytes())

    def tocar(self, nombre):
        if self.ok:
            getattr(self, nombre).play()


SONIDO = None


def sonar(nombre):
    if SONIDO is not None:
        SONIDO.tocar(nombre)


# ---------- Ayudas de dibujo ----------
FUENTES = {}


def fuente(tam):
    if tam not in FUENTES:
        FUENTES[tam] = pygame.font.SysFont("dejavusans,freesans,arial", tam)
    return FUENTES[tam]


def texto(surf, cadena, x, y, tam=22, color=NEGRO, centrado=False, sombra=None):
    img = fuente(tam).render(cadena, True, color)
    if centrado:
        x -= img.get_width() // 2
    if sombra:
        surf.blit(fuente(tam).render(cadena, True, sombra), (x + 2, y + 2))
    surf.blit(img, (x, y))
    return img.get_width()


def partir_texto(cadena, tam, ancho_max):
    """Corta un texto largo en líneas que quepan en ancho_max píxeles."""
    palabras = cadena.split(" ")
    lineas, actual = [], ""
    f = fuente(tam)
    for p in palabras:
        prueba = (actual + " " + p).strip()
        if f.size(prueba)[0] <= ancho_max:
            actual = prueba
        else:
            lineas.append(actual)
            actual = p
    if actual:
        lineas.append(actual)
    return lineas


def caja(surf, rect, color=BLANCO, borde=AZUL_CAJA):
    pygame.draw.rect(surf, color, rect, border_radius=10)
    pygame.draw.rect(surf, borde, rect, 4, border_radius=10)


def barra(surf, x, y, ancho, alto, fraccion, color, fondo=(60, 60, 70)):
    pygame.draw.rect(surf, fondo, (x, y, ancho, alto), border_radius=4)
    w = int(ancho * max(0.0, min(1.0, fraccion)))
    if w > 0:
        pygame.draw.rect(surf, color, (x, y, w, alto), border_radius=4)


def color_hp(fraccion):
    if fraccion > 0.5:
        return VERDE_HP
    if fraccion > 0.2:
        return AMARILLO_HP
    return ROJO_HP


# ---------- El mapa ----------
class Mapa:
    def __init__(self, ruta):
        with open(ruta, encoding="utf-8") as f:
            filas = [l.rstrip("\n") for l in f if l.strip() and not l.startswith("//")]
        ancho = max(len(f) for f in filas)
        self.filas = [f.ljust(ancho, "#") for f in filas]
        self.alto = len(self.filas)
        self.ancho = ancho
        self.inicio = (1, 1)
        self.entrenadores = {}      # letra -> (x, y)
        self.letreros = {}          # (x, y) -> texto
        self.centros = []           # casillas de curación
        n_letrero = 0
        for y, fila in enumerate(self.filas):
            for x, ch in enumerate(fila):
                if ch == "P":
                    self.inicio = (x, y)
                elif ch in "123K":
                    self.entrenadores[ch] = (x, y)
                elif ch == "L":
                    self.letreros[(x, y)] = LETREROS[n_letrero % len(LETREROS)]
                    n_letrero += 1
                elif ch == "+":
                    self.centros.append((x, y))
        # decoración fija (florcitas) para que no se vea tan plano
        self.flores = {(x, y): random.Random(x * 131 + y * 17).random()
                       for y in range(self.alto) for x in range(self.ancho)}

    def casilla(self, x, y):
        if 0 <= y < self.alto and 0 <= x < self.ancho:
            return self.filas[y][x]
        return "#"

    def solida(self, x, y):
        return self.casilla(x, y) in SOLIDOS

    def dibujar(self, surf, cam_x, cam_y, t, vencidos):
        c0 = max(0, int(cam_x // TILE))
        f0 = max(0, int(cam_y // TILE))
        for y in range(f0, min(self.alto, f0 + ALTO // TILE + 2)):
            for x in range(c0, min(self.ancho, c0 + ANCHO // TILE + 2)):
                ch = self.casilla(x, y)
                px, py = x * TILE - cam_x, y * TILE - cam_y
                r = pygame.Rect(px, py, TILE, TILE)
                pygame.draw.rect(surf, COLOR_TILE.get(ch, (200, 200, 200)), r)
                self._decorar(surf, ch, x, y, px, py, t)
        for letra, (x, y) in self.entrenadores.items():
            dibujar_persona(surf, x * TILE - cam_x + TILE // 2, y * TILE - cam_y + TILE // 2,
                            ENTRENADORES[letra].get("color", (200, 60, 60)), letra == "K",
                            apagado=letra in vencidos, t=t)

    def _decorar(self, surf, ch, x, y, px, py, t):
        cx, cy = px + TILE // 2, py + TILE // 2
        azar = self.flores[(x, y)]
        if ch == "#":
            pygame.draw.rect(surf, (90, 60, 30), (cx - 4, cy + 4, 8, 14))
            pygame.draw.circle(surf, (30, 90, 40), (cx, cy - 4), 15)
            pygame.draw.circle(surf, (50, 130, 60), (cx - 4, cy - 8), 9)
        elif ch == "~":
            fase = math.sin(t * 2 + x + y * 0.7)
            pygame.draw.line(surf, (140, 190, 240), (px + 6, cy + fase * 3), (px + 18, cy + fase * 3), 2)
            pygame.draw.line(surf, (140, 190, 240), (px + 22, cy + 8 - fase * 3), (px + 34, cy + 8 - fase * 3), 2)
        elif ch in ',;"':
            color = {",": (90, 160, 70), ";": (50, 130, 50), '"': (30, 90, 40)}[ch]
            for i in range(3):
                bx = px + 6 + i * 12 + int(azar * 5)
                alto_h = 8 + (4 if ch == ";" else 10 if ch == '"' else 0)
                pygame.draw.polygon(surf, color, [(bx, py + TILE - 2), (bx + 4, py + TILE - 2 - alto_h), (bx + 8, py + TILE - 2)])
        elif ch == "H":
            pygame.draw.rect(surf, (150, 80, 60), (px, py, TILE, TILE // 3))
            pygame.draw.rect(surf, (230, 210, 170), (px + 6, py + TILE // 2, 10, 10))
            pygame.draw.rect(surf, (230, 210, 170), (px + TILE - 16, py + TILE // 2, 10, 10))
        elif ch == "+":
            pygame.draw.rect(surf, (220, 50, 50), (cx - 3, cy - 12, 6, 24))
            pygame.draw.rect(surf, (220, 50, 50), (cx - 12, cy - 3, 24, 6))
        elif ch == "L":
            pygame.draw.rect(surf, (120, 80, 40), (cx - 2, cy, 4, 16))
            pygame.draw.rect(surf, (200, 160, 90), (cx - 14, cy - 12, 28, 16), border_radius=3)
        elif ch == "." and azar > 0.93:
            pygame.draw.circle(surf, (250, 220, 90) if azar > 0.965 else (240, 120, 150), (cx + 8, cy + 8), 3)


def sombra_elipse(surf, rect, alpha=50):
    """Una elipse oscura medio transparente (hay que dibujarla en una capa aparte)."""
    capa = pygame.Surface((rect[2], rect[3]), pygame.SRCALPHA)
    pygame.draw.ellipse(capa, (0, 0, 0, alpha), (0, 0, rect[2], rect[3]))
    surf.blit(capa, (rect[0], rect[1]))


def dibujar_persona(surf, cx, cy, color, corona=False, apagado=False, t=0.0, mirando_abajo=True):
    if apagado:
        color = tuple(int(c * 0.5 + 60) for c in color)
    sombra_elipse(surf, (cx - 10, cy + 12, 20, 6))
    pygame.draw.rect(surf, color, (cx - 8, cy - 2, 16, 16), border_radius=4)
    pygame.draw.circle(surf, (240, 200, 170), (cx, cy - 8), 8)
    pygame.draw.rect(surf, tuple(int(c * 0.6) for c in color), (cx - 8, cy - 16, 16, 6), border_radius=2)
    if mirando_abajo:
        pygame.draw.circle(surf, NEGRO, (cx - 3, cy - 7), 1)
        pygame.draw.circle(surf, NEGRO, (cx + 3, cy - 7), 1)
    if corona:
        pygame.draw.polygon(surf, (240, 200, 60), [(cx - 8, cy - 16), (cx - 8, cy - 24), (cx - 4, cy - 19), (cx, cy - 25),
                                                   (cx + 4, cy - 19), (cx + 8, cy - 24), (cx + 8, cy - 16)])


# ---------- Menús simples ----------
class Menu:
    """Una lista de opciones con un cursor. Devuelve el índice elegido."""

    def __init__(self, opciones, columnas=1):
        self.opciones = opciones
        self.columnas = columnas
        self.i = 0

    def mover(self, tecla):
        n = len(self.opciones)
        if n == 0:
            return
        if tecla == TECLA["arriba"]:
            self.i = (self.i - self.columnas) % n
        elif tecla == TECLA["abajo"]:
            self.i = (self.i + self.columnas) % n
        elif tecla == TECLA["izquierda"]:
            self.i = (self.i - 1) % n
        elif tecla == TECLA["derecha"]:
            self.i = (self.i + 1) % n
        else:
            return
        sonar("seleccion")


# ---------- La pantalla de batalla ----------
POS_MIA = (250, 400)
POS_ENEMIGA = (700, 210)
TAM_MIA = 190
TAM_ENEMIGA = 150


class PantallaBatalla:
    def __init__(self, juego, batalla, fondo):
        self.juego = juego
        self.b = batalla
        self.fondo = fondo
        self.cola = list(batalla.eventos_inicio())
        self.actual = None          # evento que se está mostrando
        self.tiempo_ev = 0.0        # cuánto lleva
        self.texto = ""
        self.modo = "eventos"       # eventos / menu / ataques / mochila / equipo / objetivo
        self.menu = Menu(["Pelear", "Mochila", "Criaturas", "Huir"], 2)
        self.menu_ataques = Menu([], 2)
        self.menu_mochila = Menu([])
        self.menu_equipo = Menu([])
        self.objeto_elegido = None
        # estado visual: una "foto" de cada criatura que solo cambia con los
        # eventos (la lógica ya sabe todo lo que pasó, pero la pantalla lo
        # va contando de a poco)
        self.foto = {"jugador": self._sacar_foto("jugador"), "enemigo": self._sacar_foto("enemigo")}
        self.hp_visual = {"jugador": self._hp_frac("jugador"), "enemigo": self._hp_frac("enemigo")}
        self.exp_visual = self._exp_frac()
        self.visible = {"jugador": False, "enemigo": self.b.salvaje}
        self.offset = {"jugador": 0, "enemigo": 0}
        self.parpadeo = {"jugador": 0.0, "enemigo": 0.0}
        self.ko_anim = {"jugador": 0.0, "enemigo": 0.0}
        self.esfera_anim = None
        self.evolucion_anim = None
        self.terminado = False
        self.t = 0.0

    # --- utilidades ---
    def _sacar_foto(self, lado):
        c = self.b.criatura(lado)
        return {"especie": c.especie, "nombre": c.nombre, "nivel": c.nivel,
                "hp": c.hp, "hp_max": c.hp_max, "estado": texto_estado(c)}

    def _refrescar(self, lado, con_especie=True):
        nueva = self._sacar_foto(lado)
        if not con_especie:
            nueva["especie"] = self.foto[lado]["especie"]
            nueva["nombre"] = self.foto[lado]["nombre"]
        self.foto[lado] = nueva

    def _hp_frac(self, lado):
        f = self.foto[lado]
        return f["hp"] / f["hp_max"]

    def _exp_frac(self):
        a, b = self.b.mia.exp_siguiente()
        return a / b if b else 0

    def _siguiente_evento(self):
        if self.cola:
            self.actual = self.cola.pop(0)
            self.tiempo_ev = 0.0
            self._empezar_evento(self.actual)
        else:
            self.actual = None
            if self.b.terminada:
                self.terminado = True
            elif self.b.necesita_cambio():
                self._abrir_equipo(obligado=True)
            else:
                self.modo = "menu"
                self.texto = f"¿Qué hará {self.b.mia.nombre}?"

    def _empezar_evento(self, ev):
        tipo = ev[0]
        if tipo == "msg":
            self.texto = ev[1]
        elif tipo == "sacudida":
            pass
        elif tipo == "parpadeo":
            self.parpadeo[ev[1]] = 0.45
            sonar("golpe")
        elif tipo == "ko":
            self.ko_anim[ev[1]] = 0.01
            sonar("ko")
        elif tipo == "hp":
            # la foto cambia, pero sin cambiar el dibujo (eso lo hace "evolucion")
            self._refrescar(ev[1], con_especie=False)
        elif tipo == "exp":
            self._refrescar("jugador", con_especie=False)
        elif tipo == "sale":
            self.visible[ev[1]] = True
            self.ko_anim[ev[1]] = 0.0
            self._refrescar(ev[1])
            self.hp_visual[ev[1]] = self._hp_frac(ev[1])
            if ev[1] == "jugador":
                self.exp_visual = self._exp_frac()
        elif tipo == "esfera":
            self.esfera_anim = {"sacudidas": ev[1], "atrapada": ev[2], "t": 0.0}
        elif tipo == "evolucion":
            self.evolucion_anim = {"antes": ev[1], "despues": ev[2], "t": 0.0}
            sonar("evolucion")
        elif tipo == "fin":
            if ev[1] == "captura":
                sonar("captura")
            elif ev[1] == "huida":
                sonar("escape")

    def _duracion(self, ev):
        tipo = ev[0]
        return {"sacudida": 0.4, "parpadeo": 0.45, "hp": 0.6, "ko": 0.6, "sale": 0.4,
                "exp": 0.6, "fin": 0.3}.get(tipo, 0)

    # --- actualización ---
    def actualizar(self, dt):
        self.t += dt
        for lado in ("jugador", "enemigo"):
            objetivo = self._hp_frac(lado)
            if abs(self.hp_visual[lado] - objetivo) > 0.002:
                self.hp_visual[lado] += (objetivo - self.hp_visual[lado]) * min(1, dt * 6)
            else:
                self.hp_visual[lado] = objetivo
            if self.parpadeo[lado] > 0:
                self.parpadeo[lado] -= dt
            if 0 < self.ko_anim[lado] < 1:
                self.ko_anim[lado] = min(1, self.ko_anim[lado] + dt * 1.8)
        objetivo = self._exp_frac()
        if abs(self.exp_visual - objetivo) > 0.002:
            self.exp_visual += (objetivo - self.exp_visual) * min(1, dt * 5)
        if self.modo != "eventos":
            return
        if self.actual is None:
            self._siguiente_evento()
            return
        self.tiempo_ev += dt
        ev = self.actual
        tipo = ev[0]
        if tipo == "msg":
            if self.tiempo_ev > ESPERA_MSG + len(ev[1]) / VEL_TEXTO:
                self._siguiente_evento()
        elif tipo == "sacudida":
            self.offset[ev[1]] = int(math.sin(self.tiempo_ev * 40) * 10 * (1 - self.tiempo_ev / 0.4))
            if self.tiempo_ev >= 0.4:
                self.offset[ev[1]] = 0
                self._siguiente_evento()
        elif tipo == "esfera":
            a = self.esfera_anim
            a["t"] += dt
            total = 0.6 + 0.5 * a["sacudidas"] + 0.7
            if a["t"] >= total:
                if not a["atrapada"]:
                    self.esfera_anim = None
                self._siguiente_evento()
        elif tipo == "evolucion":
            self.evolucion_anim["t"] += dt
            if self.evolucion_anim["t"] >= 3.0:
                self.evolucion_anim = None
                self._refrescar("jugador")
                self._siguiente_evento()
        else:
            if self.tiempo_ev >= self._duracion(ev):
                self._siguiente_evento()

    def tecla(self, k):
        if self.modo == "eventos":
            if k == TECLA["aceptar"] and self.actual and self.actual[0] == "msg" and self.tiempo_ev > 0.15:
                self._siguiente_evento()
            return
        if self.modo == "menu":
            self.menu.mover(k)
            if k == TECLA["aceptar"]:
                sonar("seleccion")
                op = self.menu.opciones[self.menu.i]
                if op == "Pelear":
                    self.menu_ataques = Menu(list(self.b.mia.ataques), 2)
                    self.modo = "ataques"
                elif op == "Mochila":
                    self._abrir_mochila()
                elif op == "Criaturas":
                    self._abrir_equipo()
                elif op == "Huir":
                    self._ejecutar(("huir",))
        elif self.modo == "ataques":
            self.menu_ataques.mover(k)
            if k == TECLA["aceptar"]:
                self._ejecutar(("atacar", self.menu_ataques.i))
            elif k == TECLA["cancelar"]:
                self.modo = "menu"
        elif self.modo == "mochila":
            self.menu_mochila.mover(k)
            if k == TECLA["aceptar"] and self.menu_mochila.opciones:
                nombre = self.menu_mochila.opciones[self.menu_mochila.i][0]
                if OBJETOS[nombre]["tipo"] == "esfera":
                    self._ejecutar(("objeto", nombre, self.b.activa))
                else:
                    self.objeto_elegido = nombre
                    self._abrir_equipo(para_objeto=True)
            elif k == TECLA["cancelar"]:
                self.modo = "menu"
        elif self.modo == "equipo":
            self.menu_equipo.mover(k)
            if k == TECLA["aceptar"]:
                i = self.menu_equipo.i
                if self.objeto_elegido:
                    self._ejecutar(("objeto", self.objeto_elegido, i))
                    self.objeto_elegido = None
                else:
                    if i == self.b.activa or self.b.equipo[i].ko:
                        sonar("escape")
                    else:
                        self._ejecutar(("cambiar", i))
            elif k == TECLA["cancelar"] and not self.b.necesita_cambio():
                self.objeto_elegido = None
                self.modo = "menu"

    def _abrir_mochila(self):
        self.menu_mochila = Menu(self.b.mochila.lista())
        self.modo = "mochila"

    def _abrir_equipo(self, obligado=False, para_objeto=False):
        self.menu_equipo = Menu(list(self.b.equipo))
        self.modo = "equipo"
        self.texto = "Elige una criatura." if not para_objeto else f"¿A quién le das {self.objeto_elegido}?"

    def _ejecutar(self, accion):
        self.cola += self.b.turno(accion)
        self.modo = "eventos"
        self.actual = None

    # --- dibujo ---
    def dibujar(self, surf):
        surf.blit(self.fondo, (0, 0))
        # plataformas
        sombra_elipse(surf, (POS_MIA[0] - 120, POS_MIA[1] + 60, 240, 40))
        sombra_elipse(surf, (POS_ENEMIGA[0] - 100, POS_ENEMIGA[1] + 50, 200, 34))
        self._dibujar_criatura("enemigo", POS_ENEMIGA, TAM_ENEMIGA, -1)
        self._dibujar_criatura("jugador", POS_MIA, TAM_MIA, 1)
        if self.esfera_anim:
            self._dibujar_esfera(surf)
        self._panel(surf, "enemigo", 40, 40)
        self._panel(surf, "jugador", ANCHO - 340, 330)
        # caja de texto y menús
        caja(surf, pygame.Rect(20, ALTO - 150, ANCHO - 40, 130))
        if self.modo in ("eventos", "menu"):
            self._dibujar_texto(surf, self.texto, 40, ALTO - 135, ANCHO - 400 if self.modo == "menu" else ANCHO - 80)
        if self.modo == "menu":
            self._dibujar_menu(surf, self.menu, ANCHO - 360, ALTO - 140, 160, 2)
        elif self.modo == "ataques":
            self._dibujar_ataques(surf)
        elif self.modo == "mochila":
            self._dibujar_mochila(surf)
        elif self.modo == "equipo":
            self._dibujar_equipo(surf)

    def _dibujar_criatura(self, lado, pos, tam, mirando):
        surf = self.juego.pantalla
        if not self.visible[lado]:
            return
        if self.ko_anim[lado] >= 1:
            return
        if self.esfera_anim and lado == "enemigo":
            a = self.esfera_anim
            if a["t"] > 0.5 and (a["atrapada"] or a["t"] < 0.6 + 0.5 * a["sacudidas"] + 0.2):
                return  # está adentro de la esfera
        if self.parpadeo[lado] > 0 and int(self.parpadeo[lado] * 20) % 2 == 0:
            return
        x = pos[0] + self.offset[lado]
        y = pos[1] + int(self.ko_anim[lado] * 120)
        if self.evolucion_anim and lado == "jugador":
            a = self.evolucion_anim
            fase = int(a["t"] * (4 + a["t"] * 4)) % 2
            especie = a["despues"] if (a["t"] > 2.4 or fase) else a["antes"]
            if a["t"] < 2.4:
                silueta(surf, especie, x, y, tam, (255, 255, 255), self.t, mirando)
                return
            dibujar_criatura(surf, especie, x, y, tam, self.t, mirando)
            return
        f = self.foto[lado]
        if f["estado"] == "ZZZ" and int(self.t * 2) % 2 == 0:
            texto(surf, "z", x + tam // 2, y - tam // 2 - 10, 26, NEGRO)
        dibujar_criatura(surf, f["especie"], x, y, tam, self.t, mirando)

    def _dibujar_esfera(self, surf):
        a = self.esfera_anim
        t = a["t"]
        ex, ey = POS_ENEMIGA
        if t < 0.5:
            k = t / 0.5
            x = POS_MIA[0] + (ex - POS_MIA[0]) * k
            y = POS_MIA[1] - 80 + (ey - POS_MIA[1] + 80) * k - math.sin(k * math.pi) * 200
        else:
            x, y = ex, ey + 40
            s = t - 0.6
            if 0 <= s < 0.5 * a["sacudidas"]:
                x += int(math.sin(s * 25) * 10)
        color = (220, 60, 60)
        if a["atrapada"] and t > 0.6 + 0.5 * a["sacudidas"]:
            color = (250, 200, 60)
        pygame.draw.circle(surf, color, (int(x), int(y)), 18)
        pygame.draw.circle(surf, BLANCO, (int(x), int(y)), 18, 3)
        pygame.draw.line(surf, NEGRO, (x - 18, y), (x + 18, y), 3)
        pygame.draw.circle(surf, BLANCO, (int(x), int(y)), 6)
        pygame.draw.circle(surf, NEGRO, (int(x), int(y)), 6, 2)

    def _panel(self, surf, lado, x, y):
        if not self.visible[lado]:
            return
        f = self.foto[lado]
        alto = 100 if lado == "jugador" else 80
        caja(surf, pygame.Rect(x, y, 300, alto))
        texto(surf, f["nombre"], x + 15, y + 10, 24)
        texto(surf, f"Nv {f['nivel']}", x + 220, y + 10, 22)
        est = f["estado"]
        if est:
            pygame.draw.rect(surf, (120, 80, 200) if est == "ZZZ" else (140, 60, 160), (x + 160, y + 12, 44, 20), border_radius=4)
            texto(surf, est, x + 165, y + 13, 16, BLANCO)
        frac = self.hp_visual[lado]
        texto(surf, "PS", x + 15, y + 42, 16, GRIS)
        barra(surf, x + 45, y + 44, 235, 14, frac, color_hp(frac))
        if lado == "jugador":
            texto(surf, f"{f['hp']}/{f['hp_max']}", x + 180, y + 60, 18)
            texto(surf, "EXP", x + 15, y + 78, 14, GRIS)
            barra(surf, x + 55, y + 80, 225, 8, self.exp_visual, AZUL_EXP)

    def _dibujar_texto(self, surf, cadena, x, y, ancho):
        if self.modo == "eventos" and self.actual and self.actual[0] == "msg":
            n = int(self.tiempo_ev * VEL_TEXTO)
            cadena = cadena[:n]
        for i, linea in enumerate(partir_texto(cadena, 26, ancho)):
            texto(surf, linea, x, y + i * 32, 26)
        if self.modo == "eventos" and self.actual and self.actual[0] == "msg" and int(self.t * 3) % 2:
            texto(surf, "▼", ANCHO - 60, ALTO - 55, 22, AZUL_CAJA)

    def _dibujar_menu(self, surf, menu, x, y, ancho_col, columnas):
        for i, op in enumerate(menu.opciones):
            col, fila = i % columnas, i // columnas
            px, py = x + col * ancho_col, y + fila * 50
            if i == menu.i:
                texto(surf, "▶", px - 22, py + 8, 22, AZUL_CAJA)
            texto(surf, op, px, py + 5, 26)

    def _dibujar_ataques(self, surf):
        m = self.menu_ataques
        for i, nombre in enumerate(m.opciones):
            col, fila = i % 2, i // 2
            px, py = 60 + col * 300, ALTO - 135 + fila * 55
            at = ATAQUES[nombre]
            pygame.draw.rect(surf, COLOR_TIPO[at["tipo"]], (px - 6, py + 6, 8, 28), border_radius=3)
            if i == m.i:
                texto(surf, "▶", px - 30, py + 8, 22, AZUL_CAJA)
            texto(surf, nombre, px + 10, py + 5, 24)
        at = ATAQUES[m.opciones[m.i]]
        x = ANCHO - 320
        caja(surf, pygame.Rect(x, ALTO - 140, 280, 110), (235, 240, 250))
        texto(surf, f"Tipo: {NOMBRE_TIPO[at['tipo']]}", x + 15, ALTO - 130, 20)
        texto(surf, f"Poder: {at['poder'] or '--'}   Precisión: {at['precision']}%", x + 15, ALTO - 105, 20)
        efecto = {"dormir": "Duerme al rival", "veneno": "Envenena al rival",
                  "subir_ataque": "Sube tu ataque", None: "Sin efecto extra"}[at["efecto"]]
        texto(surf, efecto, x + 15, ALTO - 80, 20, AZUL_CAJA)
        texto(surf, "ESC: volver", x + 15, ALTO - 55, 16, GRIS)

    def _dibujar_mochila(self, surf):
        m = self.menu_mochila
        if not m.opciones:
            texto(surf, "La mochila está vacía.", 40, ALTO - 135, 26)
            return
        for i, (nombre, n) in enumerate(m.opciones):
            col, fila = i % 2, i // 2
            px, py = 60 + col * 300, ALTO - 140 + fila * 40
            if i == m.i:
                texto(surf, "▶", px - 30, py + 6, 20, AZUL_CAJA)
            texto(surf, f"{nombre} x{n}", px, py + 4, 22)
        nombre = m.opciones[m.i][0]
        x = ANCHO - 320
        caja(surf, pygame.Rect(x, ALTO - 140, 280, 110), (235, 240, 250))
        for j, linea in enumerate(partir_texto(OBJETOS[nombre]["descripcion"], 20, 250)):
            texto(surf, linea, x + 15, ALTO - 130 + j * 24, 20)
        texto(surf, "ESC: volver", x + 15, ALTO - 55, 16, GRIS)

    def _dibujar_equipo(self, surf):
        m = self.menu_equipo
        # el equipo se dibuja sobre la caja, en una lista más grande
        caja(surf, pygame.Rect(20, 20, ANCHO - 40, ALTO - 190), (240, 244, 250))
        texto(surf, self.texto, 40, 30, 24)
        for i, c in enumerate(m.opciones):
            col, fila = i % 2, i // 2
            px, py = 50 + col * 450, 70 + fila * 120
            r = pygame.Rect(px, py, 420, 105)
            pygame.draw.rect(surf, (215, 225, 245) if i == m.i else (250, 250, 250), r, border_radius=8)
            pygame.draw.rect(surf, AZUL_CAJA if i == m.i else GRIS, r, 3, border_radius=8)
            dibujar_criatura(surf, c.especie, px + 55, py + 52, 70, self.t)
            texto(surf, c.nombre + ("  (en batalla)" if i == self.b.activa else ""), px + 110, py + 12, 22)
            texto(surf, f"Nv {c.nivel}   {NOMBRE_TIPO[c.tipo]}   {texto_estado(c)}", px + 110, py + 40, 18, GRIS)
            frac = c.hp / c.hp_max
            barra(surf, px + 110, py + 68, 220, 12, frac, color_hp(frac))
            texto(surf, f"{c.hp}/{c.hp_max}", px + 340, py + 62, 18)


# ---------- El juego completo ----------
class Juego:
    def __init__(self):
        self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        pygame.display.set_caption("Criaturas")
        self.reloj = pygame.time.Clock()
        self.mapa = Mapa(RUTA_MAPA)
        self.partida = Partida()
        self.estado = "titulo"
        self.menu = Menu(["Nueva partida", "Continuar (F9)", "Salir"])
        self.menu_inicial = Menu(INICIALES)
        self.menu_pausa = Menu(["Criaturas", "Mochila", "Guardar (F5)", "Cargar (F9)", "Seguir jugando", "Salir del juego"])
        self.menu_equipo = Menu([])
        self.menu_mochila = Menu([])
        self.intercambio = None
        self.objeto_elegido = None
        self.x, self.y = self.mapa.inicio
        self.mirando = (0, 1)
        self.paso_timer = 0.0
        self.mensajes = []          # textos que se muestran sobre el mapa
        self.batalla = None
        self.transicion = 0.0
        self.batalla_pendiente = None
        self.t = 0.0
        self.aviso = ("", 0.0)
        self.punto_curacion = self.mapa.centros[0] if self.mapa.centros else self.mapa.inicio
        self.corriendo = True
        self.fondos = {}

    # --- partida ---
    def nueva_partida(self, inicial):
        self.partida = Partida()
        self.partida.equipo = [Criatura(inicial, 5)]
        self.x, self.y = self.mapa.inicio
        self.partida.pos = (self.x, self.y)
        self.estado = "mapa"
        self.mensajes = [f"¡{inicial} es tu primera criatura! Al norte hay pasto bajo para practicar.",
                         "ENTER habla y avanza el texto. ESC abre el menú. F5 guarda."]

    def guardar(self):
        self.partida.pos = (self.x, self.y)
        try:
            self.partida.guardar(RUTA_PARTIDA)
            self.aviso = ("Partida guardada en partida.json", 2.0)
            sonar("curar")
        except OSError as e:
            self.aviso = (f"No se pudo guardar: {e}", 3.0)

    def cargar(self):
        if not os.path.exists(RUTA_PARTIDA):
            self.aviso = ("No hay partida guardada todavía.", 2.0)
            return False
        try:
            self.partida = Partida.cargar(RUTA_PARTIDA)
        except (OSError, ValueError, KeyError) as e:
            self.aviso = (f"No se pudo cargar: {e}", 3.0)
            return False
        if self.partida.pos and not self.mapa.solida(*self.partida.pos):
            self.x, self.y = self.partida.pos
        else:
            self.x, self.y = self.mapa.inicio
        if not self.partida.equipo:
            self.partida.equipo = [Criatura(INICIALES[0], 5)]
        self.estado = "mapa"
        self.aviso = ("Partida cargada.", 2.0)
        sonar("curar")
        return True

    # --- eventos ---
    def manejar_tecla(self, k):
        if self.estado == "titulo":
            self.menu.mover(k)
            if k == TECLA["cargar"]:
                self.cargar()
            elif k == TECLA["aceptar"]:
                sonar("seleccion")
                op = self.menu.i
                if op == 0:
                    self.estado = "elegir"
                elif op == 1:
                    self.cargar()
                else:
                    self.corriendo = False
        elif self.estado == "elegir":
            self.menu_inicial.mover(k)
            if k == TECLA["aceptar"]:
                sonar("captura")
                self.nueva_partida(INICIALES[self.menu_inicial.i])
            elif k == TECLA["cancelar"]:
                self.estado = "titulo"
        elif self.estado == "mapa":
            if self.mensajes:
                if k == TECLA["aceptar"]:
                    self.mensajes.pop(0)
                    sonar("seleccion")
                return
            if k == TECLA["guardar"]:
                self.guardar()
            elif k == TECLA["cargar"]:
                self.cargar()
            elif k in (TECLA["cancelar"], TECLA["menu"]):
                self.estado = "pausa"
                self.menu_pausa.i = 0
                sonar("seleccion")
            elif k == TECLA["aceptar"]:
                self.interactuar()
        elif self.estado == "pausa":
            self.manejar_pausa(k)
        elif self.estado == "equipo":
            self.manejar_equipo(k)
        elif self.estado == "mochila":
            self.manejar_mochila(k)
        elif self.estado == "batalla":
            if self.batalla:
                self.batalla.tecla(k)
        elif self.estado == "final":
            if k == TECLA["aceptar"]:
                self.estado = "mapa"

    def manejar_pausa(self, k):
        self.menu_pausa.mover(k)
        if k in (TECLA["cancelar"], TECLA["menu"]):
            self.estado = "mapa"
        elif k == TECLA["guardar"]:
            self.guardar()
        elif k == TECLA["cargar"]:
            self.cargar()
        elif k == TECLA["aceptar"]:
            sonar("seleccion")
            op = self.menu_pausa.i
            if op == 0:
                self.menu_equipo = Menu(list(self.partida.equipo))
                self.intercambio = None
                self.objeto_elegido = None
                self.estado = "equipo"
            elif op == 1:
                self.menu_mochila = Menu(self.partida.mochila.lista())
                self.estado = "mochila"
            elif op == 2:
                self.guardar()
            elif op == 3:
                self.cargar()
            elif op == 4:
                self.estado = "mapa"
            else:
                self.corriendo = False

    def manejar_equipo(self, k):
        self.menu_equipo.mover(k)
        if k == TECLA["cancelar"]:
            self.estado = "pausa" if not self.objeto_elegido else "mochila"
            self.objeto_elegido = None
            self.intercambio = None
        elif k == TECLA["aceptar"]:
            i = self.menu_equipo.i
            eq = self.partida.equipo
            if self.objeto_elegido:
                self.usar_objeto_mapa(self.objeto_elegido, eq[i])
            elif self.intercambio is None:
                self.intercambio = i
                sonar("seleccion")
            else:
                eq[self.intercambio], eq[i] = eq[i], eq[self.intercambio]
                self.menu_equipo = Menu(list(eq))
                self.menu_equipo.i = i
                self.intercambio = None
                sonar("seleccion")

    def manejar_mochila(self, k):
        self.menu_mochila.mover(k)
        if k == TECLA["cancelar"]:
            self.estado = "pausa"
        elif k == TECLA["aceptar"] and self.menu_mochila.opciones:
            nombre = self.menu_mochila.opciones[self.menu_mochila.i][0]
            if OBJETOS[nombre]["tipo"] == "esfera":
                self.aviso = ("Las esferas se usan en batalla.", 2.0)
                sonar("escape")
            else:
                self.objeto_elegido = nombre
                self.menu_equipo = Menu(list(self.partida.equipo))
                self.estado = "equipo"

    def usar_objeto_mapa(self, nombre, c):
        obj = OBJETOS[nombre]
        if obj["tipo"] == "curar":
            if c.ko or c.hp >= c.hp_max:
                self.aviso = ("No le hace falta.", 1.5)
                sonar("escape")
                return
            c.curar(obj["valor"])
        elif obj["tipo"] == "estado":
            if c.estado is None:
                self.aviso = ("No le hace falta.", 1.5)
                sonar("escape")
                return
            c.estado = None
            c.turnos_dormido = 0
        self.partida.mochila.quitar(nombre)
        sonar("curar")
        self.aviso = (f"Usaste {nombre} en {c.nombre}.", 2.0)
        self.objeto_elegido = None
        self.menu_mochila = Menu(self.partida.mochila.lista())
        self.estado = "mochila"

    # --- mapa ---
    def interactuar(self):
        """ENTER en el mapa: mira la casilla de enfrente."""
        fx, fy = self.x + self.mirando[0], self.y + self.mirando[1]
        ch = self.mapa.casilla(fx, fy)
        if (fx, fy) in self.mapa.letreros:
            self.mensajes.append(self.mapa.letreros[(fx, fy)])
            sonar("seleccion")
        elif ch in "123K":
            self.hablar_entrenador(ch)

    def hablar_entrenador(self, letra):
        datos = ENTRENADORES[letra]
        if letra in self.partida.vencidos:
            self.mensajes.append(f"{datos['nombre']}: {datos['despues']}")
            return
        if letra == "K" and len([v for v in self.partida.vencidos if v != "K"]) < 3:
            self.mensajes.append(f"{datos['nombre']}: Vuelve cuando hayas vencido a los 3 entrenadores.")
            return
        if not self.partida.tiene_vivas():
            self.mensajes.append("Tus criaturas están agotadas. Ve al centro de curación primero.")
            return
        enemigos = [Criatura(e, n) for e, n in datos["equipo"]]
        self.empezar_batalla(enemigos, entrenador=letra)

    def mover(self, dx, dy, corriendo):
        self.mirando = (dx, dy)
        nx, ny = self.x + dx, self.y + dy
        ch = self.mapa.casilla(nx, ny)
        if self.mapa.solida(nx, ny):
            if (nx, ny) in self.mapa.letreros or ch in "123K":
                # chocar con un letrero o entrenador también sirve para hablar
                if self.paso_timer <= 0:
                    self.interactuar()
                    self.paso_timer = 0.4
            return
        self.x, self.y = nx, ny
        self.paso_timer = PASO_CORRER if corriendo else PASO_SEG
        if ch == "+":
            self.curar_en_centro()
        elif ch in PASTO and self.partida.tiene_vivas() and random.random() < PROB_ENCUENTRO:
            nmin, nmax, especies = PASTO[ch]
            salvaje = Criatura(random.choice(especies), random.randint(nmin, nmax))
            self.empezar_batalla([salvaje], pasto=ch)

    def curar_en_centro(self):
        self.partida.curar_equipo()
        self.punto_curacion = (self.x, self.y)
        self.aviso = ("¡Tu equipo está curado!", 2.0)
        sonar("curar")

    def empezar_batalla(self, enemigos, entrenador=None, pasto=None):
        datos = ENTRENADORES[entrenador] if entrenador else None
        b = Batalla(self.partida.equipo, self.partida.mochila, enemigos, datos, caja=self.partida.caja)
        self.batalla_pendiente = (b, entrenador, pasto)
        self.transicion = 0.01
        sonar("encuentro")

    def fondo_batalla(self, pasto):
        clave = pasto or "."
        if clave not in self.fondos:
            s = pygame.Surface((ANCHO, ALTO))
            arriba, abajo = {
                ",": ((170, 220, 250), (130, 200, 110)),
                ";": ((150, 200, 240), (80, 160, 80)),
                '"': ((110, 150, 200), (50, 110, 60)),
                ".": ((230, 210, 170), (190, 160, 110)),
            }[clave]
            for y in range(ALTO):
                k = y / ALTO
                color = tuple(int(arriba[i] + (abajo[i] - arriba[i]) * k) for i in range(3))
                pygame.draw.line(s, color, (0, y), (ANCHO, y))
            self.fondos[clave] = s
        return self.fondos[clave]

    def terminar_batalla(self):
        b = self.batalla.b
        letra = self.batalla_letra
        self.batalla = None
        self.estado = "mapa"
        if b.resultado == "victoria" and letra:
            if letra not in self.partida.vencidos:
                self.partida.vencidos.append(letra)
            if letra == "K":
                self.partida.campeon = True
                self.estado = "final"
        elif b.resultado == "derrota":
            self.partida.curar_equipo()
            self.x, self.y = self.punto_curacion
            self.mensajes.append("Te quedaste sin criaturas... Corriste al centro de curación y ya están bien.")
            if letra:
                self.mensajes.append("Consejo: entrena en el pasto y vuelve más fuerte.")

    # --- actualización ---
    def actualizar(self, dt):
        self.t += dt
        if self.aviso[1] > 0:
            self.aviso = (self.aviso[0], self.aviso[1] - dt)
        if self.transicion > 0:
            self.transicion += dt
            if self.transicion > 0.7 and self.batalla_pendiente:
                b, letra, pasto = self.batalla_pendiente
                self.batalla = PantallaBatalla(self, b, self.fondo_batalla(pasto))
                self.batalla_letra = letra
                self.batalla_pendiente = None
                self.estado = "batalla"
            if self.transicion > 1.0:
                self.transicion = 0.0
            return
        if self.estado == "mapa":
            self.paso_timer -= dt
            if not self.mensajes and self.paso_timer <= 0:
                teclas = pygame.key.get_pressed()
                corriendo = teclas[TECLA["correr"]]
                if teclas[TECLA["izquierda"]]:
                    self.mover(-1, 0, corriendo)
                elif teclas[TECLA["derecha"]]:
                    self.mover(1, 0, corriendo)
                elif teclas[TECLA["arriba"]]:
                    self.mover(0, -1, corriendo)
                elif teclas[TECLA["abajo"]]:
                    self.mover(0, 1, corriendo)
        elif self.estado == "batalla" and self.batalla:
            self.batalla.actualizar(dt)
            if self.batalla.terminado:
                self.terminar_batalla()

    # --- dibujo ---
    def dibujar(self):
        s = self.pantalla
        if self.estado == "titulo":
            self.dibujar_titulo(s)
        elif self.estado == "elegir":
            self.dibujar_elegir(s)
        elif self.estado in ("mapa", "pausa", "equipo", "mochila"):
            self.dibujar_mapa(s)
            if self.estado == "pausa":
                self.dibujar_pausa(s)
            elif self.estado == "equipo":
                self.dibujar_equipo(s)
            elif self.estado == "mochila":
                self.dibujar_mochila(s)
        elif self.estado == "batalla" and self.batalla:
            self.batalla.dibujar(s)
        elif self.estado == "final":
            self.dibujar_final(s)
        if self.aviso[1] > 0:
            w = fuente(22).size(self.aviso[0])[0] + 30
            caja(s, pygame.Rect(ANCHO // 2 - w // 2, 15, w, 40))
            texto(s, self.aviso[0], ANCHO // 2, 24, 22, centrado=True)
        if self.transicion > 0:
            k = self.transicion if self.transicion < 0.7 else 1 - (self.transicion - 0.7) / 0.3
            k = max(0.0, min(1.0, k / 0.7 if self.transicion < 0.7 else k))
            velo = pygame.Surface((ANCHO, ALTO))
            velo.fill(NEGRO)
            velo.set_alpha(int(255 * k))
            s.blit(velo, (0, 0))
            if self.transicion < 0.7:
                # rayas que se cierran, como en los juegos de antes
                n = int(k * 12)
                for i in range(n):
                    pygame.draw.rect(s, NEGRO, (0, i * ALTO // 12, ANCHO, ALTO // 24))

    def dibujar_titulo(self, s):
        s.fill((40, 60, 100))
        for i, esp in enumerate(ESPECIES):
            ang = self.t * 0.3 + i * math.pi * 2 / 12
            x = ANCHO // 2 + math.cos(ang) * 380
            y = ALTO // 2 + math.sin(ang) * 220
            dibujar_criatura(s, esp, int(x), int(y), 70, self.t, 1 if math.cos(ang) < 0 else -1)
        texto(s, "CRIATURAS", ANCHO // 2, 150, 80, (250, 230, 120), centrado=True, sombra=(30, 30, 50))
        texto(s, "un juego de Manu", ANCHO // 2, 240, 26, BLANCO, centrado=True)
        for i, op in enumerate(self.menu.opciones):
            y = 330 + i * 50
            if i == self.menu.i:
                texto(s, "▶", ANCHO // 2 - 120, y, 30, (250, 230, 120))
            texto(s, op, ANCHO // 2 - 80, y, 30, BLANCO)
        texto(s, "Flechas: moverse   ENTER: elegir", ANCHO // 2, ALTO - 50, 20, (180, 190, 210), centrado=True)

    def dibujar_elegir(self, s):
        s.fill((230, 235, 225))
        texto(s, "Elige tu primera criatura", ANCHO // 2, 50, 40, NEGRO, centrado=True)
        for i, esp in enumerate(self.menu_inicial.opciones):
            x = ANCHO // 2 + (i - 1) * 300
            elegido = i == self.menu_inicial.i
            r = pygame.Rect(x - 130, 130, 260, 400)
            pygame.draw.rect(s, (255, 255, 255) if elegido else (240, 240, 235), r, border_radius=14)
            pygame.draw.rect(s, COLOR_TIPO[ESPECIES[esp]["tipo"]] if elegido else GRIS, r, 5, border_radius=14)
            dibujar_criatura(s, esp, x, 280, 170 if elegido else 140, self.t)
            texto(s, esp, x, 380, 32, centrado=True)
            texto(s, NOMBRE_TIPO[ESPECIES[esp]["tipo"]], x, 420, 22, COLOR_TIPO[ESPECIES[esp]["tipo"]], centrado=True)
            for j, linea in enumerate(partir_texto(ESPECIES[esp]["descripcion"], 18, 230)):
                texto(s, linea, x, 455 + j * 22, 18, GRIS, centrado=True)
        texto(s, "Izquierda / derecha para mirar, ENTER para elegir", ANCHO // 2, ALTO - 50, 22, GRIS, centrado=True)

    def dibujar_mapa(self, s):
        cam_x = self.x * TILE - ANCHO // 2 + TILE // 2
        cam_y = self.y * TILE - ALTO // 2 + TILE // 2
        cam_x = max(0, min(self.mapa.ancho * TILE - ANCHO, cam_x))
        cam_y = max(0, min(self.mapa.alto * TILE - ALTO, cam_y))
        s.fill((30, 80, 40))
        self.mapa.dibujar(s, cam_x, cam_y, self.t, self.partida.vencidos)
        bob = int(abs(math.sin(self.t * 12)) * 3) if self.paso_timer > 0 else 0
        dibujar_persona(s, self.x * TILE - cam_x + TILE // 2, self.y * TILE - cam_y + TILE // 2 - bob,
                        (60, 120, 220), mirando_abajo=self.mirando != (0, -1))
        # mini panel con el equipo
        eq = self.partida.equipo
        for i, c in enumerate(eq):
            px = 15 + i * 46
            pygame.draw.rect(s, (255, 255, 255), (px, ALTO - 60, 42, 48), border_radius=6)
            dibujar_criatura(s, c.especie, px + 21, ALTO - 42, 26, self.t)
            frac = c.hp / c.hp_max
            barra(s, px + 4, ALTO - 18, 34, 5, frac, color_hp(frac))
        if self.mensajes:
            caja(s, pygame.Rect(20, ALTO - 150, ANCHO - 40, 130))
            for i, linea in enumerate(partir_texto(self.mensajes[0], 24, ANCHO - 90)):
                texto(s, linea, 40, ALTO - 135 + i * 30, 24)
            if int(self.t * 3) % 2:
                texto(s, "▼ ENTER", ANCHO - 130, ALTO - 50, 18, AZUL_CAJA)
        else:
            texto(s, "ESC: menú   F5: guardar   F9: cargar", ANCHO - 15 - fuente(16).size("ESC: menú   F5: guardar   F9: cargar")[0],
                  ALTO - 25, 16, BLANCO, sombra=NEGRO)
            insignias = len([v for v in self.partida.vencidos if v != "K"])
            texto(s, f"Entrenadores vencidos: {insignias}/3" + ("   ★ CAMPEÓN" if self.partida.campeon else ""),
                  ANCHO - 15 - fuente(18).size(f"Entrenadores vencidos: {insignias}/3   ★ CAMPEÓN")[0], 15, 18, BLANCO, sombra=NEGRO)

    def dibujar_pausa(self, s):
        r = pygame.Rect(ANCHO // 2 - 160, 120, 320, 340)
        caja(s, r)
        texto(s, "MENÚ", ANCHO // 2, 135, 30, centrado=True)
        for i, op in enumerate(self.menu_pausa.opciones):
            y = 190 + i * 42
            if i == self.menu_pausa.i:
                texto(s, "▶", r.x + 25, y + 3, 22, AZUL_CAJA)
            texto(s, op, r.x + 55, y, 24)

    def dibujar_equipo(self, s):
        caja(s, pygame.Rect(20, 20, ANCHO - 40, ALTO - 40), (240, 244, 250))
        if self.objeto_elegido:
            titulo = f"¿A quién le das {self.objeto_elegido}?"
        elif self.intercambio is not None:
            titulo = f"¿Con quién cambias a {self.partida.equipo[self.intercambio].nombre}?"
        else:
            titulo = "Tu equipo  (ENTER dos veces para cambiar el orden; la primera pelea)"
        texto(s, titulo, 40, 30, 22)
        m = self.menu_equipo
        for i, c in enumerate(m.opciones):
            col, fila = i % 2, i // 2
            px, py = 50 + col * 450, 70 + fila * 160
            r = pygame.Rect(px, py, 420, 145)
            marcado = i == m.i or i == self.intercambio
            pygame.draw.rect(s, (215, 225, 245) if marcado else (250, 250, 250), r, border_radius=8)
            pygame.draw.rect(s, AZUL_CAJA if marcado else GRIS, r, 3, border_radius=8)
            dibujar_criatura(s, c.especie, px + 60, py + 70, 90, self.t)
            texto(s, c.nombre, px + 125, py + 12, 24)
            texto(s, f"Nv {c.nivel}   {NOMBRE_TIPO[c.tipo]}   {texto_estado(c)}", px + 125, py + 42, 18, GRIS)
            frac = c.hp / c.hp_max
            barra(s, px + 125, py + 68, 200, 12, frac, color_hp(frac))
            texto(s, f"{c.hp}/{c.hp_max}", px + 335, py + 62, 18)
            a, b = c.exp_siguiente()
            barra(s, px + 125, py + 90, 200, 6, a / b if b else 0, AZUL_EXP)
            texto(s, "  ".join(c.ataques[:2]), px + 125, py + 100, 15, GRIS)
            texto(s, "  ".join(c.ataques[2:]), px + 125, py + 118, 15, GRIS)
        if self.partida.caja:
            texto(s, f"En la caja: {len(self.partida.caja)} criatura(s)", 40, ALTO - 50, 18, GRIS)
        texto(s, "ESC: volver", ANCHO - 140, ALTO - 50, 18, GRIS)

    def dibujar_mochila(self, s):
        r = pygame.Rect(ANCHO // 2 - 250, 100, 500, 400)
        caja(s, r)
        texto(s, "MOCHILA", ANCHO // 2, 115, 30, centrado=True)
        m = self.menu_mochila
        if not m.opciones:
            texto(s, "Está vacía.", ANCHO // 2, 200, 24, GRIS, centrado=True)
        for i, (nombre, n) in enumerate(m.opciones):
            y = 170 + i * 40
            if i == m.i:
                texto(s, "▶", r.x + 30, y + 3, 22, AZUL_CAJA)
            texto(s, f"{nombre}  x{n}", r.x + 60, y, 24)
        if m.opciones:
            nombre = m.opciones[m.i][0]
            texto(s, OBJETOS[nombre]["descripcion"], ANCHO // 2, r.bottom - 70, 20, AZUL_CAJA, centrado=True)
        texto(s, "ENTER: usar   ESC: volver", ANCHO // 2, r.bottom - 40, 18, GRIS, centrado=True)

    def dibujar_final(self, s):
        s.fill((250, 230, 120))
        texto(s, "¡ERES EL NUEVO CAMPEÓN!", ANCHO // 2, 80, 60, (120, 60, 20), centrado=True, sombra=(255, 250, 200))
        eq = self.partida.equipo
        for i, c in enumerate(eq):
            x = ANCHO // 2 + (i - (len(eq) - 1) / 2) * 150
            y = 330 + math.sin(self.t * 4 + i) * 15
            dibujar_criatura(s, c.especie, int(x), int(y), 120, self.t)
            texto(s, f"{c.nombre} Nv {c.nivel}", int(x), 420, 18, NEGRO, centrado=True)
        texto(s, "Puedes seguir jugando, atrapando y entrenando. ¡Gracias por jugar!", ANCHO // 2, 520, 24, NEGRO, centrado=True)
        texto(s, "ENTER para volver al mapa", ANCHO // 2, 570, 20, GRIS, centrado=True)

    # --- bucle principal ---
    def correr(self, segundos=None):
        """Si le pasas segundos, se cierra solo después (para las pruebas)."""
        transcurrido = 0.0
        while self.corriendo:
            dt = min(0.1, self.reloj.tick(FPS) / 1000.0)
            transcurrido += dt
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.corriendo = False
                elif ev.type == pygame.KEYDOWN:
                    self.manejar_tecla(ev.key)
            self.actualizar(dt)
            self.dibujar()
            pygame.display.flip()
            if segundos is not None and transcurrido >= segundos:
                break
        pygame.quit()


def main():
    global TECLA, SONIDO
    pygame.init()
    TECLA = cargar_controles()
    SONIDO = Sonidos()
    segundos = None
    if "--segundos" in sys.argv:
        segundos = float(sys.argv[sys.argv.index("--segundos") + 1])
    Juego().correr(segundos)


if __name__ == "__main__":
    main()
