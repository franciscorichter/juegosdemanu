"""
Dibujos de las 12 criaturas, hechos solo con círculos, elipses y polígonos.
No hay imágenes. Cada criatura tiene su propia función.

Todas reciben lo mismo:
  surf    -> dónde dibujar
  cx, cy  -> el centro
  tam     -> el tamaño (alto aprox. en píxeles)
  t       -> el tiempo en segundos (para que "respiren")
  mirando -> 1 si mira a la derecha, -1 si mira a la izquierda

Truco: todas dibujan pensando en un cuadrado de -1 a 1 y la función P()
convierte esas coordenadas a píxeles. Así el mismo dibujo sirve grande
(en la batalla) o chiquito (en el menú).
"""

import math

import pygame

from datos import COLOR_TIPO


def _mas_oscuro(color, cuanto=0.65):
    return tuple(int(c * cuanto) for c in color)


def _mas_claro(color, cuanto=0.35):
    return tuple(int(c + (255 - c) * cuanto) for c in color)


class Lienzo:
    """Convierte coordenadas de -1..1 a píxeles y da funciones cómodas."""

    def __init__(self, surf, cx, cy, tam, mirando=1):
        self.surf = surf
        self.cx, self.cy = cx, cy
        self.r = tam / 2
        self.m = mirando

    def P(self, x, y):
        return (int(self.cx + x * self.r * self.m), int(self.cy + y * self.r))

    def circulo(self, color, x, y, radio, borde=0):
        pygame.draw.circle(self.surf, color, self.P(x, y), max(1, int(radio * self.r)), borde)

    def elipse(self, color, x, y, ancho, alto):
        w, h = max(2, int(ancho * self.r)), max(2, int(alto * self.r))
        px, py = self.P(x, y)
        pygame.draw.ellipse(self.surf, color, pygame.Rect(px - w // 2, py - h // 2, w, h))

    def poligono(self, color, puntos):
        pygame.draw.polygon(self.surf, color, [self.P(x, y) for x, y in puntos])

    def linea(self, color, a, b, grosor=2):
        pygame.draw.line(self.surf, color, self.P(*a), self.P(*b), max(1, int(grosor * self.r / 40)))

    def ojo(self, x, y, radio=0.1, color_pupila=(20, 20, 30), enojado=False):
        self.circulo((255, 255, 255), x, y, radio)
        self.circulo(color_pupila, x + 0.02 * 1, y + 0.02, radio * 0.55)
        self.circulo((255, 255, 255), x + 0.04, y - 0.03, radio * 0.2)
        if enojado:
            self.linea((20, 20, 30), (x - radio, y - radio * 1.3), (x + radio, y - radio * 0.6), 3)

    def boca(self, x, y, ancho=0.2, feliz=True):
        px, py = self.P(x, y)
        w = int(ancho * self.r)
        h = int(0.12 * self.r)
        rect = pygame.Rect(px - w // 2, py - h // 2, w, h)
        grosor = max(1, int(self.r / 25))
        if feliz:
            pygame.draw.arc(self.surf, (20, 20, 30), rect, math.pi, 2 * math.pi, grosor)
        else:
            pygame.draw.arc(self.surf, (20, 20, 30), rect, 0, math.pi, grosor)


# ---------- FUEGO ----------
def brasita(L, t):
    c = COLOR_TIPO["fuego"]
    ondula = math.sin(t * 6) * 0.06
    # llama de la cabeza
    L.poligono((255, 200, 60), [(-0.35, -0.3), (-0.2, -0.7 + ondula), (-0.05, -0.45),
                                (0.05, -0.95 - ondula), (0.15, -0.5), (0.35, -0.75 + ondula), (0.35, -0.3)])
    L.poligono(c, [(-0.25, -0.3), (-0.12, -0.55 + ondula), (0.0, -0.4), (0.08, -0.7 - ondula),
                   (0.2, -0.45), (0.25, -0.3)])
    # patitas
    L.elipse(_mas_oscuro(c), -0.25, 0.75, 0.3, 0.16)
    L.elipse(_mas_oscuro(c), 0.25, 0.75, 0.3, 0.16)
    # cuerpo
    L.circulo(c, 0, 0.15, 0.55)
    L.circulo(_mas_claro(c), -0.1, 0.25, 0.3)
    L.ojo(-0.18, 0.0, 0.11)
    L.ojo(0.18, 0.0, 0.11)
    L.boca(0.0, 0.3, 0.22)


def volcanor(L, t):
    c = _mas_oscuro(COLOR_TIPO["fuego"], 0.8)
    burbuja = (math.sin(t * 5) + 1) / 2
    # brazos
    L.elipse(c, -0.75, 0.2, 0.3, 0.5)
    L.elipse(c, 0.75, 0.2, 0.3, 0.5)
    # cuerpo grande
    L.poligono(c, [(-0.6, 0.85), (-0.55, -0.1), (-0.3, -0.5), (0.3, -0.5), (0.55, -0.1), (0.6, 0.85)])
    L.elipse((90, 40, 30), -0.3, 0.85, 0.35, 0.18)
    L.elipse((90, 40, 30), 0.3, 0.85, 0.35, 0.18)
    # cráter con lava
    L.poligono((90, 60, 50), [(-0.35, -0.5), (-0.2, -0.9), (0.2, -0.9), (0.35, -0.5)])
    L.elipse((255, 170, 40), 0, -0.9, 0.4, 0.14)
    L.circulo((255, 230, 90), 0.05, -0.95 - 0.15 * burbuja, 0.06 + 0.03 * burbuja)
    L.circulo((255, 230, 90), -0.1, -1.0 - 0.1 * (1 - burbuja), 0.04)
    # grietas de lava en el cuerpo
    L.linea((255, 150, 40), (-0.3, 0.1), (-0.1, 0.4), 4)
    L.linea((255, 150, 40), (0.2, 0.0), (0.35, 0.5), 4)
    L.ojo(-0.2, -0.2, 0.12, (200, 40, 20), enojado=True)
    L.ojo(0.2, -0.2, 0.12, (200, 40, 20), enojado=True)
    L.boca(0, 0.15, 0.3, feliz=False)


# ---------- AGUA ----------
def gotix(L, t):
    c = _mas_claro(COLOR_TIPO["agua"], 0.25)
    rebote = abs(math.sin(t * 4)) * 0.08
    # gota: triángulo arriba + círculo abajo
    L.poligono(c, [(0, -0.95 + rebote), (-0.5, 0.15), (0.5, 0.15)])
    L.circulo(c, 0, 0.3 - rebote * 0.5, 0.6)
    L.circulo((255, 255, 255), -0.25, 0.05, 0.13)
    L.circulo((255, 255, 255), -0.3, -0.25, 0.06)
    L.ojo(-0.2, 0.3, 0.14)
    L.ojo(0.2, 0.3, 0.14)
    L.circulo((255, 150, 170), -0.4, 0.5, 0.08)
    L.circulo((255, 150, 170), 0.4, 0.5, 0.08)
    L.boca(0, 0.58, 0.22)


def marejon(L, t):
    c = COLOR_TIPO["agua"]
    o = math.sin(t * 3) * 0.05
    # ola grande que se enrolla
    L.poligono(c, [(-0.95, 0.9), (-0.9, 0.2), (-0.7, -0.4), (-0.3, -0.85 + o), (0.2, -0.95),
                   (0.6, -0.8 + o), (0.75, -0.5), (0.65, -0.25), (0.4, -0.35), (0.5, -0.55),
                   (0.3, -0.6), (0.45, 0.1), (0.95, 0.9)])
    L.poligono(_mas_oscuro(c), [(-0.95, 0.9), (-0.85, 0.5), (0.9, 0.55), (0.95, 0.9)])
    # espuma
    for i, (x, y) in enumerate([(-0.3, -0.85), (0.0, -0.98), (0.35, -0.9), (0.62, -0.72), (-0.6, -0.4)]):
        L.circulo((240, 250, 255), x, y + o * (1 if i % 2 else -1), 0.12)
    L.ojo(-0.35, 0.0, 0.14, enojado=True)
    L.ojo(0.05, 0.0, 0.14, enojado=True)
    L.boca(-0.15, 0.35, 0.4, feliz=False)
    # dientes
    L.poligono((255, 255, 255), [(-0.3, 0.35), (-0.25, 0.48), (-0.2, 0.35)])
    L.poligono((255, 255, 255), [(0.0, 0.35), (0.05, 0.48), (0.1, 0.35)])


# ---------- PLANTA ----------
def brotin(L, t):
    c = COLOR_TIPO["planta"]
    v = math.sin(t * 3) * 0.06
    # hojas
    L.elipse(c, -0.35, -0.65 + v, 0.55, 0.28)
    L.elipse(c, 0.35, -0.65 - v, 0.55, 0.28)
    L.linea(_mas_oscuro(c), (0, -0.4), (0, -0.85), 4)
    # patitas
    L.elipse(_mas_oscuro(c), -0.2, 0.85, 0.26, 0.14)
    L.elipse(_mas_oscuro(c), 0.2, 0.85, 0.26, 0.14)
    # cuerpo: un brote verde claro
    L.elipse(_mas_claro(c, 0.3), 0, 0.2, 1.0, 1.15)
    L.elipse(c, 0, 0.55, 0.9, 0.5)
    L.ojo(-0.2, 0.05, 0.11)
    L.ojo(0.2, 0.05, 0.11)
    L.boca(0, 0.32, 0.2)


def selvarak(L, t):
    verde = COLOR_TIPO["planta"]
    tronco = (110, 75, 45)
    v = math.sin(t * 2) * 0.03
    # raíces / brazos
    L.poligono(tronco, [(-0.3, 0.5), (-0.9, 0.75), (-0.95, 0.9), (-0.25, 0.8)])
    L.poligono(tronco, [(0.3, 0.5), (0.9, 0.75), (0.95, 0.9), (0.25, 0.8)])
    # tronco
    L.poligono(tronco, [(-0.35, 0.95), (-0.3, -0.1), (0.3, -0.1), (0.35, 0.95)])
    # copa: varios círculos
    for x, y, r in [(-0.45, -0.3, 0.38), (0.45, -0.3, 0.38), (0, -0.65 + v, 0.45), (-0.25, -0.05, 0.3),
                    (0.25, -0.05, 0.3), (0, -0.25, 0.4)]:
        L.circulo(_mas_oscuro(verde, 0.85), x, y, r)
    for x, y, r in [(-0.4, -0.35, 0.25), (0.4, -0.35, 0.25), (0, -0.7 + v, 0.3)]:
        L.circulo(verde, x, y, r)
    # cara en el tronco
    L.ojo(-0.13, 0.15, 0.1, (60, 30, 20), enojado=True)
    L.ojo(0.13, 0.15, 0.1, (60, 30, 20), enojado=True)
    L.boca(0, 0.45, 0.25, feliz=False)


# ---------- ELÉCTRICO ----------
def chispin(L, t):
    c = COLOR_TIPO["electrico"]
    salto = abs(math.sin(t * 8)) * 0.08
    y0 = 0.05 - salto
    # cuerpo: una chispa con 8 puntas (como una estrella redondita)
    puntas = []
    for i in range(16):
        ang = math.pi * 2 * i / 16 + t * 1.5
        r = 0.72 if i % 2 == 0 else 0.5
        puntas.append((math.cos(ang) * r, y0 + math.sin(ang) * r))
    L.poligono(_mas_claro(c, 0.2), puntas)
    L.circulo(c, 0, y0, 0.48)
    # antena con bolita que brilla
    L.linea(_mas_oscuro(c), (0.0, y0 - 0.45), (0.15, y0 - 0.85), 3)
    brillo = (255, 255, 255) if int(t * 5) % 2 else (255, 240, 120)
    L.circulo(brillo, 0.15, y0 - 0.88, 0.09)
    # mejillas azules (electricidad guardada)
    L.circulo((90, 170, 255), -0.3, y0 + 0.15, 0.09)
    L.circulo((90, 170, 255), 0.3, y0 + 0.15, 0.09)
    L.ojo(-0.16, y0 - 0.05, 0.1)
    L.ojo(0.16, y0 - 0.05, 0.1)
    L.boca(0, y0 + 0.2, 0.15)
    # patitas
    L.elipse(_mas_oscuro(c), -0.2, 0.75, 0.22, 0.12)
    L.elipse(_mas_oscuro(c), 0.2, 0.75, 0.22, 0.12)


def tormentux(L, t):
    gris = (110, 115, 135)
    ray = COLOR_TIPO["electrico"]
    f = math.sin(t * 2) * 0.04
    # nube: varios círculos grises
    for x, y, r in [(-0.55, 0.0, 0.4), (0.55, 0.0, 0.4), (-0.2, -0.35 + f, 0.45), (0.25, -0.3 + f, 0.42),
                    (0, 0.1, 0.5)]:
        L.circulo(gris, x, y, r)
    for x, y, r in [(-0.5, -0.1, 0.25), (0.2, -0.4 + f, 0.25)]:
        L.circulo(_mas_claro(gris, 0.3), x, y, r)
    # rayo que cuelga
    brillo = ray if int(t * 6) % 3 else (255, 255, 200)
    L.poligono(brillo, [(0.0, 0.45), (-0.25, 0.7), (-0.05, 0.7), (-0.3, 1.0), (0.2, 0.65), (0.0, 0.65), (0.25, 0.45)])
    # chispas a los lados
    L.poligono(ray, [(-0.85, -0.4), (-0.95, -0.6), (-0.7, -0.5)])
    L.poligono(ray, [(0.85, -0.5), (0.95, -0.7), (0.7, -0.6)])
    L.ojo(-0.2, -0.05, 0.13, (40, 40, 60), enojado=True)
    L.ojo(0.2, -0.05, 0.13, (40, 40, 60), enojado=True)
    L.boca(0, 0.25, 0.25, feliz=False)


# ---------- ROCA ----------
def pedrolo(L, t):
    c = COLOR_TIPO["roca"]
    # piedra irregular
    L.poligono(c, [(-0.7, 0.3), (-0.6, -0.4), (-0.2, -0.7), (0.4, -0.65), (0.75, -0.1), (0.65, 0.55), (0.1, 0.75), (-0.5, 0.65)])
    L.poligono(_mas_claro(c, 0.2), [(-0.5, -0.2), (-0.2, -0.55), (0.3, -0.5), (0.1, -0.1)])
    # grietas
    L.linea(_mas_oscuro(c), (0.3, 0.1), (0.55, 0.4), 3)
    L.linea(_mas_oscuro(c), (0.55, 0.4), (0.45, 0.6), 3)
    L.linea(_mas_oscuro(c), (-0.55, 0.3), (-0.35, 0.5), 3)
    # un solo ojo grande que parpadea
    if int(t * 1.3) % 5 == 4 and (t * 1.3) % 1 < 0.3:
        L.linea((40, 30, 20), (-0.2, 0.0), (0.2, 0.0), 4)
    else:
        L.ojo(0, 0.0, 0.2)
    L.boca(0, 0.4, 0.2)
    L.elipse(_mas_oscuro(c), -0.35, 0.8, 0.3, 0.14)
    L.elipse(_mas_oscuro(c), 0.35, 0.8, 0.3, 0.14)


def montaraz(L, t):
    c = _mas_oscuro(COLOR_TIPO["roca"], 0.85)
    # brazos de roca
    L.poligono(c, [(-0.7, 0.2), (-0.95, 0.5), (-0.9, 0.85), (-0.6, 0.7)])
    L.poligono(c, [(0.7, 0.2), (0.95, 0.5), (0.9, 0.85), (0.6, 0.7)])
    # montaña
    L.poligono(c, [(-0.8, 0.9), (0.0, -0.95), (0.8, 0.9)])
    L.poligono(_mas_oscuro(c), [(-0.8, 0.9), (-0.3, 0.9), (0.0, 0.2), (-0.35, -0.1)])
    # nieve arriba
    L.poligono((245, 245, 255), [(-0.22, -0.45), (0.0, -0.95), (0.22, -0.45), (0.12, -0.35), (0.0, -0.5), (-0.12, -0.35)])
    # árbolitos
    L.poligono(COLOR_TIPO["planta"], [(0.4, 0.5), (0.5, 0.25), (0.6, 0.5)])
    L.poligono(COLOR_TIPO["planta"], [(-0.55, 0.7), (-0.45, 0.45), (-0.35, 0.7)])
    L.ojo(-0.15, 0.1, 0.11, (40, 30, 20), enojado=True)
    L.ojo(0.15, 0.1, 0.11, (40, 30, 20), enojado=True)
    L.boca(0, 0.4, 0.25, feliz=False)


# ---------- FANTASMA ----------
def _cuerpo_fantasma(L, color, t, escala=1.0):
    ancho = 0.6 * escala
    flota = math.sin(t * 2.5) * 0.06
    L.circulo(color, 0, -0.3 + flota, ancho)
    ondas = []
    n = 5
    for i in range(n + 1):
        x = -ancho + 2 * ancho * i / n
        y = 0.55 * escala + flota + (0.15 if i % 2 else 0) * escala
        ondas.append((x, y))
    L.poligono(color, [(-ancho, -0.3 + flota)] + ondas + [(ancho, -0.3 + flota)])
    return flota


def sombrilo(L, t):
    c = COLOR_TIPO["fantasma"]
    flota = _cuerpo_fantasma(L, c, t)
    # ojos grandes blancos
    L.ojo(-0.22, -0.35 + flota, 0.17, (60, 20, 90))
    L.ojo(0.22, -0.35 + flota, 0.17, (60, 20, 90))
    # sonrisa traviesa (con un diente)
    L.boca(0.05, -0.02 + flota, 0.35)
    L.poligono((255, 255, 255), [(0.12, -0.02 + flota), (0.16, 0.1 + flota), (0.2, -0.02 + flota)])
    # bracitos
    L.elipse(c, -0.7, -0.05 + flota, 0.3, 0.2)
    L.elipse(c, 0.7, -0.05 + flota, 0.3, 0.2)


def espectrum(L, t):
    c = _mas_oscuro(COLOR_TIPO["fantasma"], 0.7)
    flota = _cuerpo_fantasma(L, c, t, 1.25)
    # capa oscura
    L.poligono((40, 20, 60), [(-0.75, -0.3 + flota), (-0.95, 0.75 + flota), (-0.55, 0.55 + flota)])
    L.poligono((40, 20, 60), [(0.75, -0.3 + flota), (0.95, 0.75 + flota), (0.55, 0.55 + flota)])
    # corona
    oro = (240, 200, 60)
    L.poligono(oro, [(-0.45, -0.85 + flota), (-0.45, -1.15 + flota), (-0.22, -0.95 + flota), (0.0, -1.2 + flota),
                     (0.22, -0.95 + flota), (0.45, -1.15 + flota), (0.45, -0.85 + flota)])
    L.circulo((230, 60, 60), 0, -0.95 + flota, 0.06)
    # ojos rojos
    L.ojo(-0.25, -0.4 + flota, 0.16, (200, 30, 40), enojado=True)
    L.ojo(0.25, -0.4 + flota, 0.16, (200, 30, 40), enojado=True)
    L.boca(0, 0.0 + flota, 0.4, feliz=False)
    L.poligono((255, 255, 255), [(-0.15, 0.0 + flota), (-0.1, 0.14 + flota), (-0.05, 0.0 + flota)])
    L.poligono((255, 255, 255), [(0.05, 0.0 + flota), (0.1, 0.14 + flota), (0.15, 0.0 + flota)])


DIBUJOS = {
    "Brasita": brasita, "Volcanor": volcanor,
    "Gotix": gotix, "Marejón": marejon,
    "Brotín": brotin, "Selvarak": selvarak,
    "Chispín": chispin, "Tormentux": tormentux,
    "Pedrolo": pedrolo, "Montaraz": montaraz,
    "Sombrilo": sombrilo, "Espectrum": espectrum,
}


def dibujar_criatura(surf, especie, cx, cy, tam, t=0.0, mirando=1):
    """Dibuja la criatura pedida. Si no existe, dibuja un círculo gris."""
    L = Lienzo(surf, cx, cy, tam, mirando)
    fn = DIBUJOS.get(especie)
    if fn is None:
        L.circulo((150, 150, 150), 0, 0, 0.6)
        return
    fn(L, t)


def silueta(surf, especie, cx, cy, tam, color, t=0.0, mirando=1):
    """La misma criatura pero de un solo color (para la evolución y la esfera)."""
    ancho = int(tam * 2.4)
    capa = pygame.Surface((ancho, ancho), pygame.SRCALPHA)
    dibujar_criatura(capa, especie, ancho // 2, ancho // 2, tam, t, mirando)
    mascara = pygame.mask.from_surface(capa)
    forma = mascara.to_surface(setcolor=color, unsetcolor=(0, 0, 0, 0))
    surf.blit(forma, (cx - ancho // 2, cy - ancho // 2))
