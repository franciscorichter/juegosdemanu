"""Pruebas de la lógica (sin ventana). Correr con:
    .venv/bin/python -m unittest discover -s tests -v
"""
import json
import os
import random
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datos import ESPECIES, ATAQUES, ENTRENADORES, TIPOS, efectividad  # noqa: E402
from logica import (Criatura, Batalla, Mochila, Partida, probabilidad_captura,  # noqa: E402
                    exp_para_nivel)


def jugar_hasta_el_final(b, elegir=None, max_turnos=500):
    """Simula una batalla entera atacando siempre (o con la función elegir)."""
    eventos = list(b.eventos_inicio())
    turnos = 0
    while not b.terminada and turnos < max_turnos:
        if b.necesita_cambio():
            i = next(i for i, c in enumerate(b.equipo) if not c.ko)
            accion = ("cambiar", i)
        elif elegir:
            accion = elegir(b)
        else:
            accion = ("atacar", len(b.mia.ataques) - 1)
        eventos += b.turno(accion)
        turnos += 1
    return eventos


class TestDatos(unittest.TestCase):
    def test_doce_criaturas_con_cuatro_ataques(self):
        self.assertEqual(len(ESPECIES), 12)
        for nombre, d in ESPECIES.items():
            self.assertIn(d["tipo"], TIPOS, nombre)
            self.assertEqual(len(d["ataques"]), 4, nombre)
            efectos = 0
            for at, nivel in d["ataques"]:
                self.assertIn(at, ATAQUES, f"{nombre}: {at}")
                if ATAQUES[at]["efecto"]:
                    efectos += 1
            self.assertGreaterEqual(efectos, 1, f"{nombre} necesita un ataque con efecto")
            if d["evoluciona"]:
                self.assertIn(d["evoluciona"][0], ESPECIES)

    def test_tabla_efectividad(self):
        self.assertEqual(efectividad("fuego", "planta"), 2.0)
        self.assertEqual(efectividad("agua", "fuego"), 2.0)
        self.assertEqual(efectividad("fuego", "agua"), 0.5)
        self.assertEqual(efectividad("normal", "planta"), 1.0)

    def test_entrenadores(self):
        self.assertEqual(set(ENTRENADORES), {"1", "2", "3", "K"})
        for d in ENTRENADORES.values():
            for esp, nivel in d["equipo"]:
                self.assertIn(esp, ESPECIES)


class TestCriatura(unittest.TestCase):
    def test_ataques_por_nivel(self):
        c = Criatura("Brasita", 3)
        self.assertEqual(c.ataques, ["Golpe", "Chispa"])
        c = Criatura("Brasita", 12)
        self.assertEqual(len(c.ataques), 4)

    def test_subir_nivel_y_evolucionar(self):
        c = Criatura("Gotix", 14)
        hp_antes = c.hp_max
        eventos = c.ganar_exp(exp_para_nivel(16) - c.exp)
        self.assertEqual(c.nivel, 16)
        self.assertEqual(c.especie, "Marejón")
        self.assertIn(("evolucion", "Gotix", "Marejón"), eventos)
        self.assertIn(("nivel", 15), eventos)
        self.assertGreater(c.hp_max, hp_antes)
        self.assertEqual(c.hp, c.hp_max)          # la vida extra se suma
        self.assertIn("Chorro", c.ataques)
        # no evoluciona dos veces
        self.assertFalse(c.evolucionar())

    def test_apodo_sobrevive_la_evolucion(self):
        c = Criatura("Brotín", 15, apodo="Verdi")
        c.ganar_exp(exp_para_nivel(16) - c.exp)
        self.assertEqual(c.nombre, "Verdi")
        self.assertEqual(c.especie, "Selvarak")


class TestBatalla(unittest.TestCase):
    def test_batalla_salvaje_completa(self):
        azar = random.Random(7)
        equipo = [Criatura("Brasita", 10)]
        b = Batalla(equipo, Mochila(), [Criatura("Brotín", 4)], azar=azar)
        eventos = jugar_hasta_el_final(b)
        self.assertTrue(b.terminada)
        self.assertEqual(b.resultado, "victoria")
        tipos = [e[0] for e in eventos]
        self.assertIn("sacudida", tipos)
        self.assertIn("parpadeo", tipos)
        self.assertIn("ko", tipos)
        self.assertEqual(eventos[-1], ("fin", "victoria"))
        self.assertGreater(equipo[0].exp, exp_para_nivel(10))
        self.assertEqual(equipo[0].etapa_ataque, 0)

    def test_batalla_contra_entrenador_con_cambios(self):
        azar = random.Random(11)
        equipo = [Criatura("Chispín", 6), Criatura("Brasita", 12), Criatura("Gotix", 12)]
        mochila = Mochila()
        datos = ENTRENADORES["1"]
        enemigos = [Criatura(e, n) for e, n in datos["equipo"]]
        b = Batalla(equipo, mochila, enemigos, entrenador=datos, azar=azar)
        eventos = jugar_hasta_el_final(b)
        self.assertEqual(b.resultado, "victoria")
        self.assertTrue(all(e.ko for e in enemigos))
        self.assertIn(("msg", "¡Recibiste 2 x Poción!"), eventos)
        self.assertEqual(mochila.objetos["Poción"], 6)
        # el segundo enemigo salió con un evento "sale"
        self.assertGreaterEqual([e[0] for e in eventos].count("sale"), 3)

    def test_no_se_puede_huir_de_entrenador(self):
        b = Batalla([Criatura("Gotix", 5)], Mochila(), [Criatura("Brotín", 5)],
                    entrenador=ENTRENADORES["1"], azar=random.Random(1))
        ev = b.turno(("huir",))
        self.assertEqual(ev[0], ("msg", "¡No puedes huir de un entrenador!"))
        self.assertFalse(b.terminada)

    def test_huir_de_salvaje(self):
        b = Batalla([Criatura("Chispín", 20)], Mochila(), [Criatura("Pedrolo", 3)], azar=random.Random(2))
        for _ in range(20):
            b.turno(("huir",))
            if b.terminada:
                break
        self.assertEqual(b.resultado, "huida")

    def test_derrota(self):
        b = Batalla([Criatura("Brotín", 2)], Mochila(), [Criatura("Volcanor", 30)], azar=random.Random(3))
        jugar_hasta_el_final(b)
        self.assertEqual(b.resultado, "derrota")

    def test_efectos_de_estado(self):
        azar = random.Random(5)
        mia = Criatura("Gotix", 20)
        b = Batalla([mia], Mochila(), [Criatura("Montaraz", 5)], azar=azar)
        i = mia.ataques.index("Canción de Marea")
        dormido = False
        for _ in range(10):
            b.turno(("atacar", i))
            if b.enemiga.estado == "dormido":
                dormido = True
                break
        self.assertTrue(dormido)
        # veneno: Brotín con Polen Tóxico
        mia = Criatura("Brotín", 20)
        b = Batalla([mia], Mochila(), [Criatura("Montaraz", 5)], azar=azar)
        i = mia.ataques.index("Polen Tóxico")
        for _ in range(10):
            hp = b.enemiga.hp
            ev = b.turno(("atacar", i))
            if b.enemiga.estado == "envenenado":
                self.assertIn(("msg", "Montaraz sufre por el veneno."), ev)
                break
        self.assertEqual(b.enemiga.estado, "envenenado")
        # subir ataque
        mia = Criatura("Brasita", 20)
        b = Batalla([mia], Mochila(), [Criatura("Montaraz", 5)], azar=azar)
        atk = mia.ataque
        b.turno(("atacar", mia.ataques.index("Rugido Ardiente")))
        self.assertGreater(mia.ataque, atk)
        self.assertEqual(mia.etapa_ataque, 1)


class TestCaptura(unittest.TestCase):
    def test_probabilidad(self):
        c = Criatura("Brasita", 5)
        llena = probabilidad_captura(c)
        c.hp = 1
        casi_ko = probabilidad_captura(c)
        self.assertGreater(casi_ko, llena)
        c.estado = "dormido"
        self.assertGreaterEqual(probabilidad_captura(c), casi_ko)
        self.assertGreater(probabilidad_captura(c, "Superesfera"), probabilidad_captura(c, "Esfera") * 0.99)
        self.assertLessEqual(probabilidad_captura(c, "Superesfera"), 1.0)

    def test_capturar_se_une_al_equipo(self):
        azar = random.Random(4)
        equipo = [Criatura("Brasita", 10)]
        mochila = Mochila({"Esfera": 30})
        salvaje = Criatura("Gotix", 3)
        salvaje.hp = 1
        b = Batalla(equipo, mochila, [salvaje], azar=azar)
        eventos = jugar_hasta_el_final(b, elegir=lambda b: ("objeto", "Esfera"))
        self.assertEqual(b.resultado, "captura")
        self.assertIn(salvaje, equipo)
        self.assertLess(mochila.objetos.get("Esfera", 0), 30)
        esferas = [e for e in eventos if e[0] == "esfera"]
        self.assertEqual(esferas[-1], ("esfera", 3, True))

    def test_equipo_lleno_va_a_la_caja(self):
        equipo = [Criatura("Brasita", 10) for _ in range(6)]
        caja = []
        salvaje = Criatura("Gotix", 3)
        salvaje.hp = 1
        b = Batalla(equipo, Mochila({"Superesfera": 50}), [salvaje], azar=random.Random(9), caja=caja)
        jugar_hasta_el_final(b, elegir=lambda b: ("objeto", "Superesfera"))
        self.assertEqual(b.resultado, "captura")
        self.assertEqual(len(equipo), 6)
        self.assertIn(salvaje, caja)

    def test_no_capturar_de_entrenador(self):
        b = Batalla([Criatura("Brasita", 10)], Mochila(), [Criatura("Brotín", 6)],
                    entrenador=ENTRENADORES["1"], azar=random.Random(1))
        ev = b.turno(("objeto", "Esfera", 0))
        self.assertEqual(ev, [("msg", "¡No puedes atrapar la criatura de otro entrenador!")])


class TestGuardarCargar(unittest.TestCase):
    def test_guardar_y_cargar(self):
        p = Partida()
        p.equipo = [Criatura("Brasita", 7, apodo="Fuegui"), Criatura("Gotix", 5)]
        p.equipo[0].hp = 3
        p.equipo[0].estado = "envenenado"
        p.caja = [Criatura("Pedrolo", 4)]
        p.mochila.agregar("Superpoción", 2)
        p.pos = (12, 5)
        p.vencidos = ["1", "2"]
        with tempfile.TemporaryDirectory() as d:
            ruta = os.path.join(d, "partida.json")
            p.guardar(ruta)
            with open(ruta, encoding="utf-8") as f:
                crudo = json.load(f)
            self.assertEqual(crudo["equipo"][0]["apodo"], "Fuegui")
            q = Partida.cargar(ruta)
        self.assertEqual([c.especie for c in q.equipo], ["Brasita", "Gotix"])
        self.assertEqual(q.equipo[0].nombre, "Fuegui")
        self.assertEqual(q.equipo[0].hp, 3)
        self.assertEqual(q.equipo[0].estado, "envenenado")
        self.assertEqual(q.equipo[0].nivel, 7)
        self.assertEqual(q.caja[0].especie, "Pedrolo")
        self.assertEqual(q.mochila.objetos["Superpoción"], 2)
        self.assertEqual(q.pos, (12, 5))
        self.assertEqual(q.vencidos, ["1", "2"])
        # la evolución después de cargar sigue funcionando
        q.equipo[1].ganar_exp(exp_para_nivel(16))
        self.assertEqual(q.equipo[1].especie, "Marejón")


if __name__ == "__main__":
    unittest.main()
