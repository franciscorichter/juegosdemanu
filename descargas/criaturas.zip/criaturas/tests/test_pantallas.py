"""Pruebas del juego completo con pygame en modo "dummy" (sin ventana ni audio).
Maneja el juego con teclas simuladas por todas sus pantallas.
    SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy .venv/bin/python -m unittest tests.test_pantallas -v
"""
import os
import random
import sys
import unittest

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

import criaturas as C  # noqa: E402
from logica import Criatura  # noqa: E402


class TestPantallas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pygame.init()
        C.TECLA = C.cargar_controles()
        C.SONIDO = C.Sonidos()
        cls.K = C.TECLA

    def setUp(self):
        random.seed(3)
        self.j = C.Juego()
        C.RUTA_PARTIDA = os.path.join(C.CARPETA, "partida_prueba.json")

    def tearDown(self):
        if os.path.exists(C.RUTA_PARTIDA):
            os.remove(C.RUTA_PARTIDA)

    def frames(self, n, dt=1 / 60):
        for _ in range(n):
            self.j.actualizar(dt)
            self.j.dibujar()

    def tecla(self, nombre, n=2):
        self.j.manejar_tecla(self.K[nombre])
        self.frames(n)

    def pelear_hasta_el_final(self, max_frames=20000, ataque=0):
        j, K = self.j, self.K
        n = 0
        while j.estado == "batalla" and n < max_frames:
            b = j.batalla
            if b.modo == "menu":
                j.manejar_tecla(K["aceptar"])
                for _ in range(ataque):
                    j.manejar_tecla(K["derecha"])
                j.manejar_tecla(K["aceptar"])
            elif b.modo == "equipo":
                j.manejar_tecla(K["abajo"])
                j.manejar_tecla(K["aceptar"])
            self.frames(1)
            n += 1
        self.assertNotEqual(j.estado, "batalla", "la batalla no terminó")

    def test_titulo_elegir_y_menus_del_mapa(self):
        j = self.j
        self.frames(5)
        self.assertEqual(j.estado, "titulo")
        self.tecla("aceptar")
        self.assertEqual(j.estado, "elegir")
        self.tecla("derecha")
        self.tecla("aceptar")
        self.assertEqual(j.estado, "mapa")
        self.assertEqual(j.partida.equipo[0].especie, "Gotix")
        while j.mensajes:
            self.tecla("aceptar")
        self.tecla("cancelar")
        self.assertEqual(j.estado, "pausa")
        self.tecla("aceptar")
        self.assertEqual(j.estado, "equipo")
        self.tecla("cancelar")
        self.tecla("abajo")
        self.tecla("aceptar")
        self.assertEqual(j.estado, "mochila")
        self.tecla("aceptar")       # Poción -> elegir criatura
        self.assertEqual(j.estado, "equipo")
        self.tecla("aceptar")       # no le hace falta (sigue en equipo)
        self.assertEqual(j.estado, "equipo")
        self.tecla("cancelar")
        self.assertEqual(j.estado, "mochila")
        self.tecla("cancelar")
        self.assertEqual(j.estado, "pausa")
        self.tecla("cancelar")
        self.assertEqual(j.estado, "mapa")
        # caminar un poco en cada dirección (con encuentros desactivados)
        C.PROB_ENCUENTRO_ORIGINAL = C.PROB_ENCUENTRO
        C.PROB_ENCUENTRO = 0.0
        try:
            for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
                j.mover(dx, dy, False)
                self.frames(3)
        finally:
            C.PROB_ENCUENTRO = C.PROB_ENCUENTRO_ORIGINAL
        self.assertTrue(0 <= j.x < j.mapa.ancho)

    def test_batalla_salvaje_y_captura_en_pantalla(self):
        j, K = self.j, self.K
        j.partida.equipo = [Criatura("Brasita", 12)]
        j.partida.mochila.agregar("Esfera", 40)
        j.estado = "mapa"
        salvaje = Criatura("Gotix", 4)
        j.empezar_batalla([salvaje], pasto=",")
        self.frames(80)
        self.assertEqual(j.estado, "batalla")
        self.frames(400)
        n = 0
        while j.estado == "batalla" and n < 20000:
            b = j.batalla
            if b.modo == "menu":
                while b.menu.opciones[b.menu.i] != "Mochila":
                    j.manejar_tecla(K["derecha"])
                j.manejar_tecla(K["aceptar"])
                self.assertEqual(b.modo, "mochila")
                idx = [o[0] for o in b.menu_mochila.opciones].index("Esfera")
                for _ in range(idx):
                    j.manejar_tecla(K["abajo"])
                j.manejar_tecla(K["aceptar"])
            self.frames(1)
            n += 1
        self.assertEqual(j.estado, "mapa")
        self.assertIn(salvaje, j.partida.equipo)

    def test_entrenador_evolucion_guardar_cargar(self):
        j = self.j
        j.partida.equipo = [Criatura("Brasita", 15)]
        j.partida.equipo[0].exp = 16 ** 3 - 50      # a punto de subir
        j.estado = "mapa"
        j.hablar_entrenador("1")
        self.frames(80)
        self.assertEqual(j.estado, "batalla")
        self.pelear_hasta_el_final(ataque=3)         # Llamarada
        self.assertIn("1", j.partida.vencidos)
        self.assertEqual(j.partida.equipo[0].especie, "Volcanor")
        while j.mensajes:
            self.tecla("aceptar")
        self.tecla("guardar")
        self.assertTrue(os.path.exists(C.RUTA_PARTIDA))
        j.partida.equipo[0].nivel = 1
        self.tecla("cargar")
        self.assertEqual(j.partida.equipo[0].especie, "Volcanor")
        self.assertGreaterEqual(j.partida.equipo[0].nivel, 16)
        self.assertIn("1", j.partida.vencidos)

    def test_campeon_y_final(self):
        j = self.j
        j.partida.equipo = [Criatura("Tormentux", 45), Criatura("Marejón", 45)]
        j.estado = "mapa"
        j.hablar_entrenador("K")
        self.assertTrue(j.mensajes)     # todavía no venciste a los 3
        j.mensajes.clear()
        j.partida.vencidos = ["1", "2", "3"]
        j.hablar_entrenador("K")
        self.frames(80)
        self.assertEqual(j.estado, "batalla")
        self.pelear_hasta_el_final(ataque=1)
        self.assertTrue(j.partida.campeon)
        self.assertEqual(j.estado, "final")
        self.frames(5)
        self.tecla("aceptar")
        self.assertEqual(j.estado, "mapa")

    def test_derrota_te_lleva_al_centro(self):
        j = self.j
        j.partida.equipo = [Criatura("Brotín", 2)]
        j.estado = "mapa"
        j.empezar_batalla([Criatura("Volcanor", 30)], pasto='"')
        self.frames(80)
        self.pelear_hasta_el_final()
        self.assertEqual((j.x, j.y), j.punto_curacion)
        self.assertEqual(j.partida.equipo[0].hp, j.partida.equipo[0].hp_max)
        self.assertTrue(j.mensajes)


if __name__ == "__main__":
    unittest.main()
