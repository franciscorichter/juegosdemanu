"""
Datos de Criaturas: tipos, tabla de efectividad, ataques, las 12 criaturas
y los entrenadores. Aquí NO hay código de dibujo ni de pygame: son solo
"tablas". Cambia un número y el juego cambia.
"""

# ---------- Tipos ----------
TIPOS = ["fuego", "agua", "planta", "electrico", "roca", "fantasma"]

# Color de cada tipo (se usa para los dibujos y las etiquetas)
COLOR_TIPO = {
    "fuego": (235, 90, 40),
    "agua": (60, 130, 230),
    "planta": (70, 180, 80),
    "electrico": (240, 210, 40),
    "roca": (160, 130, 90),
    "fantasma": (130, 90, 190),
    "normal": (170, 170, 170),
}

NOMBRE_TIPO = {
    "fuego": "Fuego", "agua": "Agua", "planta": "Planta",
    "electrico": "Eléctrico", "roca": "Roca", "fantasma": "Fantasma",
    "normal": "Normal",
}

# Tabla de efectividad: EFECTIVIDAD[tipo_del_ataque][tipo_del_que_recibe]
# 2.0 = súper efectivo, 0.5 = poco efectivo, 1.0 = normal.
# Si un par no aparece, es 1.0.
EFECTIVIDAD = {
    "fuego":     {"planta": 2.0, "agua": 0.5, "roca": 0.5, "fuego": 0.5},
    "agua":      {"fuego": 2.0, "roca": 2.0, "agua": 0.5, "planta": 0.5},
    "planta":    {"agua": 2.0, "roca": 2.0, "fuego": 0.5, "planta": 0.5},
    "electrico": {"agua": 2.0, "planta": 0.5, "roca": 0.5, "electrico": 0.5},
    "roca":      {"fuego": 2.0, "electrico": 2.0, "planta": 0.5, "agua": 0.5},
    "fantasma":  {"fantasma": 2.0, "roca": 0.5, "electrico": 0.5},
    "normal":    {"roca": 0.5, "fantasma": 0.5},
}


def efectividad(tipo_ataque, tipo_defensor):
    return EFECTIVIDAD.get(tipo_ataque, {}).get(tipo_defensor, 1.0)


# ---------- Ataques ----------
# poder 0 = no hace daño, solo el efecto.
# efecto: None, "dormir", "veneno" o "subir_ataque".
ATAQUES = {
    # normales
    "Golpe":            {"tipo": "normal", "poder": 40, "precision": 100, "efecto": None},
    "Embestida":        {"tipo": "normal", "poder": 55, "precision": 95, "efecto": None},
    "Arañazo":          {"tipo": "normal", "poder": 40, "precision": 100, "efecto": None},
    # fuego
    "Chispa":           {"tipo": "fuego", "poder": 40, "precision": 100, "efecto": None},
    "Llamarada":        {"tipo": "fuego", "poder": 65, "precision": 90, "efecto": None},
    "Erupción":         {"tipo": "fuego", "poder": 90, "precision": 80, "efecto": None},
    "Rugido Ardiente":  {"tipo": "fuego", "poder": 0, "precision": 100, "efecto": "subir_ataque"},
    # agua
    "Burbuja":          {"tipo": "agua", "poder": 40, "precision": 100, "efecto": None},
    "Chorro":           {"tipo": "agua", "poder": 65, "precision": 90, "efecto": None},
    "Tsunami":          {"tipo": "agua", "poder": 90, "precision": 80, "efecto": None},
    "Canción de Marea": {"tipo": "agua", "poder": 0, "precision": 70, "efecto": "dormir"},
    # planta
    "Hoja Filosa":      {"tipo": "planta", "poder": 45, "precision": 100, "efecto": None},
    "Látigo Verde":     {"tipo": "planta", "poder": 65, "precision": 90, "efecto": None},
    "Raíz Gigante":     {"tipo": "planta", "poder": 90, "precision": 80, "efecto": None},
    "Polen Tóxico":     {"tipo": "planta", "poder": 0, "precision": 80, "efecto": "veneno"},
    # eléctrico
    "Chispazo":         {"tipo": "electrico", "poder": 40, "precision": 100, "efecto": None},
    "Rayo":             {"tipo": "electrico", "poder": 65, "precision": 90, "efecto": None},
    "Trueno":           {"tipo": "electrico", "poder": 90, "precision": 80, "efecto": None},
    "Carga Eléctrica":  {"tipo": "electrico", "poder": 0, "precision": 100, "efecto": "subir_ataque"},
    # roca
    "Pedrada":          {"tipo": "roca", "poder": 45, "precision": 100, "efecto": None},
    "Derrumbe":         {"tipo": "roca", "poder": 65, "precision": 90, "efecto": None},
    "Avalancha":        {"tipo": "roca", "poder": 90, "precision": 80, "efecto": None},
    "Arena Somnífera":  {"tipo": "roca", "poder": 0, "precision": 70, "efecto": "dormir"},
    # fantasma
    "Susurro":          {"tipo": "fantasma", "poder": 40, "precision": 100, "efecto": None},
    "Garra Sombría":    {"tipo": "fantasma", "poder": 65, "precision": 90, "efecto": None},
    "Pesadilla":        {"tipo": "fantasma", "poder": 90, "precision": 80, "efecto": None},
    "Maldición":        {"tipo": "fantasma", "poder": 0, "precision": 85, "efecto": "veneno"},
}

# ---------- Las 12 criaturas ----------
# stats base: hp, ataque, defensa, velocidad (como en un juego de rol).
# "captura": qué tan fácil es atraparla (1.0 = fácil, 0.3 = difícil).
# "exp_base": cuánta experiencia da cuando la vences.
# "evoluciona": (nombre_de_la_forma_nueva, nivel) o None.
# "ataques": (nombre, nivel en que lo aprende). Cada criatura tiene 4.
NIVEL_EVOLUCION = 16

ESPECIES = {
    # --- Fuego ---
    "Brasita": {
        "tipo": "fuego", "hp": 42, "ataque": 55, "defensa": 40, "velocidad": 60,
        "captura": 0.9, "exp_base": 60, "evoluciona": ("Volcanor", NIVEL_EVOLUCION),
        "ataques": [("Golpe", 1), ("Chispa", 1), ("Rugido Ardiente", 5), ("Llamarada", 10)],
        "descripcion": "Una brasa con patitas. Si se enoja, echa humo.",
    },
    "Volcanor": {
        "tipo": "fuego", "hp": 70, "ataque": 85, "defensa": 60, "velocidad": 80,
        "captura": 0.3, "exp_base": 150, "evoluciona": None,
        "ataques": [("Golpe", 1), ("Llamarada", 1), ("Rugido Ardiente", 1), ("Erupción", 20)],
        "descripcion": "Tiene un cráter en la cabeza que hierve todo el día.",
    },
    # --- Agua ---
    "Gotix": {
        "tipo": "agua", "hp": 50, "ataque": 45, "defensa": 50, "velocidad": 50,
        "captura": 0.9, "exp_base": 60, "evoluciona": ("Marejón", NIVEL_EVOLUCION),
        "ataques": [("Golpe", 1), ("Burbuja", 1), ("Canción de Marea", 5), ("Chorro", 10)],
        "descripcion": "Una gota gigante que rebota. Canta cuando llueve.",
    },
    "Marejón": {
        "tipo": "agua", "hp": 85, "ataque": 70, "defensa": 75, "velocidad": 65,
        "captura": 0.3, "exp_base": 150, "evoluciona": None,
        "ataques": [("Embestida", 1), ("Chorro", 1), ("Canción de Marea", 1), ("Tsunami", 20)],
        "descripcion": "Una ola con cara. Puede tragarse un bote entero.",
    },
    # --- Planta ---
    "Brotín": {
        "tipo": "planta", "hp": 48, "ataque": 48, "defensa": 55, "velocidad": 42,
        "captura": 0.9, "exp_base": 60, "evoluciona": ("Selvarak", NIVEL_EVOLUCION),
        "ataques": [("Arañazo", 1), ("Hoja Filosa", 1), ("Polen Tóxico", 5), ("Látigo Verde", 10)],
        "descripcion": "Un brote que caminó fuera de la maceta.",
    },
    "Selvarak": {
        "tipo": "planta", "hp": 80, "ataque": 78, "defensa": 85, "velocidad": 50,
        "captura": 0.3, "exp_base": 150, "evoluciona": None,
        "ataques": [("Arañazo", 1), ("Látigo Verde", 1), ("Polen Tóxico", 1), ("Raíz Gigante", 20)],
        "descripcion": "Un árbol enojado. Sus raíces atrapan cualquier cosa.",
    },
    # --- Eléctrico ---
    "Chispín": {
        "tipo": "electrico", "hp": 38, "ataque": 52, "defensa": 35, "velocidad": 75,
        "captura": 0.8, "exp_base": 65, "evoluciona": ("Tormentux", NIVEL_EVOLUCION),
        "ataques": [("Golpe", 1), ("Chispazo", 1), ("Carga Eléctrica", 5), ("Rayo", 10)],
        "descripcion": "Una chispa con orejas. Nunca se queda quieto.",
    },
    "Tormentux": {
        "tipo": "electrico", "hp": 65, "ataque": 85, "defensa": 55, "velocidad": 100,
        "captura": 0.3, "exp_base": 155, "evoluciona": None,
        "ataques": [("Embestida", 1), ("Rayo", 1), ("Carga Eléctrica", 1), ("Trueno", 20)],
        "descripcion": "Una nube de tormenta con ojos. Truena al respirar.",
    },
    # --- Roca ---
    "Pedrolo": {
        "tipo": "roca", "hp": 55, "ataque": 50, "defensa": 70, "velocidad": 25,
        "captura": 0.8, "exp_base": 70, "evoluciona": ("Montaraz", NIVEL_EVOLUCION),
        "ataques": [("Golpe", 1), ("Pedrada", 1), ("Arena Somnífera", 5), ("Derrumbe", 10)],
        "descripcion": "Una piedra que parpadea. Le gusta dormir siglos.",
    },
    "Montaraz": {
        "tipo": "roca", "hp": 90, "ataque": 80, "defensa": 110, "velocidad": 35,
        "captura": 0.3, "exp_base": 160, "evoluciona": None,
        "ataques": [("Embestida", 1), ("Derrumbe", 1), ("Arena Somnífera", 1), ("Avalancha", 20)],
        "descripcion": "Una montañita con brazos. Casi nada la mueve.",
    },
    # --- Fantasma ---
    "Sombrilo": {
        "tipo": "fantasma", "hp": 40, "ataque": 55, "defensa": 40, "velocidad": 65,
        "captura": 0.6, "exp_base": 70, "evoluciona": ("Espectrum", NIVEL_EVOLUCION),
        "ataques": [("Arañazo", 1), ("Susurro", 1), ("Maldición", 5), ("Garra Sombría", 10)],
        "descripcion": "Una sombra traviesa. Se esconde debajo de las camas.",
    },
    "Espectrum": {
        "tipo": "fantasma", "hp": 65, "ataque": 90, "defensa": 60, "velocidad": 90,
        "captura": 0.25, "exp_base": 160, "evoluciona": None,
        "ataques": [("Arañazo", 1), ("Garra Sombría", 1), ("Maldición", 1), ("Pesadilla", 20)],
        "descripcion": "Un fantasma con corona. Dicen que fue rey de algo.",
    },
}

# Las 6 criaturas "básicas" (las que salen en el pasto bajo y medio)
BASICAS = [n for n, d in ESPECIES.items() if d["evoluciona"] is not None]
EVOLUCIONADAS = [n for n, d in ESPECIES.items() if d["evoluciona"] is None]

# Con cuál empiezas (Manu: cámbiala si quieres empezar con otra)
INICIALES = ["Brasita", "Gotix", "Brotín"]

# ---------- Objetos de la mochila ----------
OBJETOS = {
    "Poción":       {"tipo": "curar", "valor": 20, "descripcion": "Cura 20 de vida."},
    "Superpoción":  {"tipo": "curar", "valor": 50, "descripcion": "Cura 50 de vida."},
    "Esfera":       {"tipo": "esfera", "valor": 1.0, "descripcion": "Atrapa criaturas salvajes."},
    "Superesfera":  {"tipo": "esfera", "valor": 1.6, "descripcion": "Atrapa mejor que la Esfera."},
    "Antídoto":     {"tipo": "estado", "valor": 0, "descripcion": "Quita veneno y despierta."},
}

MOCHILA_INICIAL = {"Poción": 4, "Esfera": 6, "Superesfera": 1, "Antídoto": 1}

# ---------- Pasto: qué sale en cada tipo de pasto ----------
# letra del mapa -> (nivel mínimo, nivel máximo, lista de especies)
PASTO = {
    ",": (3, 6, BASICAS),
    ";": (8, 12, BASICAS),
    '"': (13, 18, BASICAS + EVOLUCIONADAS),
}
PROB_ENCUENTRO = 0.14   # probabilidad de encuentro por paso en el pasto

# ---------- Entrenadores ----------
# El número es la letra del mapa. "campeon" es la K.
ENTRENADORES = {
    "1": {
        "nombre": "Lía la Jardinera",
        "equipo": [("Brotín", 6), ("Gotix", 7)],
        "antes": "¡Mis plantitas te van a enredar!",
        "despues": "Uy... les faltó sol.",
        "premio": {"Poción": 2},
    },
    "2": {
        "nombre": "Tomás el Minero",
        "equipo": [("Pedrolo", 10), ("Chispín", 11), ("Pedrolo", 12)],
        "antes": "¡Aquí abajo mandan las rocas!",
        "despues": "Qué golpe... bien jugado.",
        "premio": {"Superpoción": 2, "Esfera": 3},
    },
    "3": {
        "nombre": "Nadia la Nocturna",
        "equipo": [("Sombrilo", 14), ("Brasita", 14), ("Sombrilo", 15)],
        "antes": "Shhh... ¿escuchas los susurros?",
        "despues": "Los fantasmas también pierden, parece.",
        "premio": {"Superesfera": 2, "Antídoto": 2},
    },
    "K": {
        "nombre": "Campeón Orión",
        "equipo": [("Tormentux", 17), ("Selvarak", 18), ("Volcanor", 18), ("Espectrum", 19)],
        "antes": "Venciste a los tres. Ahora veamos si puedes conmigo.",
        "despues": "...Increíble. Eres el nuevo campeón.",
        "premio": {"Superesfera": 5},
    },
}
