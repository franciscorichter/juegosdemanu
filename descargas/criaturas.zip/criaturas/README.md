# Criaturas

Un RPG de batallas por turnos hecho en Python con pygame. Caminas por un
mapa, en el pasto alto salen criaturas salvajes, las atrapas con esferas,
suben de nivel, evolucionan al nivel 16 y al final peleas contra el campeón.
Las 12 criaturas, sus ataques y sus dibujos son inventados: todo está hecho
con círculos y polígonos, y los sonidos se fabrican con matemáticas.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 criaturas.py

En Windows: `python criaturas.py`. En Linux/Mac también sirve `./jugar.sh`.

| Tecla        | Qué hace                                        |
|--------------|-------------------------------------------------|
| Flechas      | caminar por el mapa / moverse por los menús     |
| ENTER        | aceptar, hablar con alguien, avanzar el texto   |
| ESC          | cancelar / abrir el menú en el mapa             |
| Shift izq.   | correr                                          |
| M            | abrir el menú (igual que ESC)                   |
| F5 / F9      | guardar / cargar la partida (`partida.json`)    |

### El mapa

- `,` pasto bajo (nivel 3-6), `;` pasto medio (8-12), `"` pasto alto (13-18,
  ahí salen hasta criaturas evolucionadas).
- La casa blanca con la cruz roja es el **centro de curación**: pisa la cruz
  y tu equipo queda como nuevo. También es donde despiertas si pierdes.
- Los letreros (choca con ellos o pon ENTER mirándolos) dan consejos.
- Hay **3 entrenadores** (Lía, Tomás y Nadia) y el **Campeón Orión** al sur.
  El campeón solo pelea contigo cuando venciste a los otros tres.

### La batalla

Menú de **Pelear / Mochila / Criaturas / Huir**. Cada criatura tiene hasta 4
ataques con poder, precisión y tipo; uno de ellos tiene un efecto:
dormir al rival, envenenarlo o subir tu ataque. Los ataques se aprenden al
subir de nivel (mira `datos.py`).

Tipos: Fuego > Planta > Agua > Fuego, Eléctrico > Agua, Roca > Fuego y
Eléctrico, Agua y Planta > Roca, Fantasma > Fantasma. La tabla completa
está en `EFECTIVIDAD` dentro de `datos.py`.

### Atrapar criaturas

En la Mochila, lanza una **Esfera** (o una **Superesfera**, que atrapa
mejor). La probabilidad sube mucho si la criatura tiene poca vida y más
todavía si está dormida o envenenada. Solo se atrapan criaturas salvajes.
Tu equipo tiene 6 lugares; las demás van a la caja.

### Las 12 criaturas

| Básica   | Tipo      | Evoluciona (nivel 16) |
|----------|-----------|-----------------------|
| Brasita  | Fuego     | Volcanor              |
| Gotix    | Agua      | Marejón               |
| Brotín   | Planta    | Selvarak              |
| Chispín  | Eléctrico | Tormentux             |
| Pedrolo  | Roca      | Montaraz              |
| Sombrilo | Fantasma  | Espectrum             |

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo, para
aceptar con espacio y correr con Z:

```
aceptar = space
correr  = z
```

Nombres válidos: letras, flechas (`up`, `down`, `left`, `right`), `space`,
`return`, `escape`, `tab`, `left shift`, `f1`...`f12`, números. Si escribes
una tecla que no existe, el juego avisa en la terminal y usa la de siempre.

## Para cambiar cosas

- `datos.py`: las criaturas (vida, ataque, defensa, velocidad, qué ataques
  aprende y a qué nivel), los ataques, la tabla de tipos, los objetos y los
  equipos de los entrenadores. Cambia un número, guarda y corre el juego.
- `mapa.txt`: el mapa. Es texto: dibuja pasto, casas, agua y árboles con las
  letras que dice arriba del archivo. Puedes mover a los entrenadores.
- `dibujos.py`: el dibujo de cada criatura es una función. Copia una, cambia
  colores y formas, y ponla en `DIBUJOS`.
- `criaturas.py`: arriba están los ajustes (`TILE`, `PASO_SEG`, `VEL_TEXTO`...).
- `logica.py`: la fórmula de daño (`calcular_daño`), la de captura
  (`probabilidad_captura`) y la experiencia (`exp_para_nivel`).

## Pruebas

    python3 -m unittest discover -s tests -v

Prueban la lógica (batallas completas, captura, evolución, guardar/cargar)
y el juego entero manejado con teclas simuladas, sin abrir ventana.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola. (El pip que la armó está
desempacado en `~/.local/opt/pip`, sin sudo.)
