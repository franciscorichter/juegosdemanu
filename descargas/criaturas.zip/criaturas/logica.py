"""
Lógica de Criaturas: cómo pelean, cómo se atrapan, cómo suben de nivel y
cómo se guarda la partida. Aquí NO hay pygame: esto se puede probar sin
abrir una ventana (mira la carpeta tests/).

La batalla funciona con "eventos": cada turno devuelve una lista de cosas
que pasaron (mensajes, sacudidas, cambios de vida...) y la pantalla los va
mostrando uno por uno. Así la lógica no sabe nada de dibujos.
"""

import json
import math
import random

from datos import (ATAQUES, ESPECIES, OBJETOS, MOCHILA_INICIAL, efectividad,
                   NOMBRE_TIPO)

MAX_EQUIPO = 6


# ---------- Experiencia ----------
def exp_para_nivel(nivel):
    """Cuánta experiencia total se necesita para estar en ese nivel."""
    return nivel ** 3


# ---------- Criatura ----------
class Criatura:
    def __init__(self, especie, nivel, apodo=None):
        if especie not in ESPECIES:
            raise ValueError(f"No existe la criatura '{especie}'")
        self.especie = especie
        self.nivel = nivel
        self.exp = exp_para_nivel(nivel)
        self.apodo = apodo
        self.ataques = self.ataques_conocidos()
        self.hp = self.hp_max
        self.estado = None          # None, "dormido" o "envenenado"
        self.turnos_dormido = 0
        self.etapa_ataque = 0       # de 0 a 6: cuánto subió el ataque en esta batalla

    def ataques_conocidos(self):
        """Los ataques de la especie que ya aprendió a este nivel."""
        return [n for n, nv in ESPECIES[self.especie]["ataques"] if nv <= self.nivel]

    # --- datos de la especie ---
    @property
    def datos(self):
        return ESPECIES[self.especie]

    @property
    def nombre(self):
        return self.apodo or self.especie

    @property
    def tipo(self):
        return self.datos["tipo"]

    def _stat(self, nombre):
        return self.datos[nombre] * 2 * self.nivel // 100 + 5

    @property
    def hp_max(self):
        return self.datos["hp"] * 3 * self.nivel // 100 + self.nivel + 12

    @property
    def ataque(self):
        return int(self._stat("ataque") * (1 + 0.5 * self.etapa_ataque))

    @property
    def defensa(self):
        return self._stat("defensa")

    @property
    def velocidad(self):
        return self._stat("velocidad")

    @property
    def ko(self):
        return self.hp <= 0

    # --- vida ---
    def dañar(self, cantidad):
        self.hp = max(0, self.hp - int(cantidad))

    def curar(self, cantidad):
        antes = self.hp
        self.hp = min(self.hp_max, self.hp + int(cantidad))
        return self.hp - antes

    def curar_todo(self):
        self.hp = self.hp_max
        self.estado = None
        self.turnos_dormido = 0

    def terminar_batalla(self):
        self.etapa_ataque = 0

    # --- experiencia y evolución ---
    def ganar_exp(self, cantidad):
        """Suma experiencia. Devuelve una lista de eventos: ("nivel", n) por
        cada nivel que subió y ("evolucion", antes, despues) si evolucionó."""
        eventos = []
        self.exp += int(cantidad)
        while self.nivel < 100 and self.exp >= exp_para_nivel(self.nivel + 1):
            hp_antes = self.hp_max
            self.nivel += 1
            self.hp += self.hp_max - hp_antes   # al subir de nivel ganas la vida nueva
            eventos.append(("nivel", self.nivel))
            for nombre, nv in self.datos["ataques"]:
                if nv == self.nivel and nombre not in self.ataques:
                    self.ataques.append(nombre)
                    eventos.append(("aprende", nombre))
            evo = self.datos["evoluciona"]
            if evo is not None and self.nivel >= evo[1]:
                antes = self.especie
                self.evolucionar()
                eventos.append(("evolucion", antes, self.especie))
        return eventos

    def evolucionar(self):
        evo = self.datos["evoluciona"]
        if evo is None:
            return False
        hp_antes = self.hp_max
        if self.apodo == self.especie:
            self.apodo = None
        self.especie = evo[0]
        self.ataques = self.ataques_conocidos()
        self.hp += self.hp_max - hp_antes
        return True

    def exp_siguiente(self):
        """Cuánta exp falta para el siguiente nivel (y cuánto es el tramo)."""
        base = exp_para_nivel(self.nivel)
        tope = exp_para_nivel(self.nivel + 1)
        return self.exp - base, tope - base

    # --- guardar / cargar ---
    def a_dict(self):
        return {"especie": self.especie, "nivel": self.nivel, "exp": self.exp,
                "apodo": self.apodo, "hp": self.hp, "estado": self.estado,
                "ataques": self.ataques}

    @classmethod
    def desde_dict(cls, d):
        c = cls(d["especie"], d["nivel"], d.get("apodo"))
        c.exp = d.get("exp", c.exp)
        c.hp = min(d.get("hp", c.hp_max), c.hp_max)
        c.estado = d.get("estado")
        c.ataques = list(d.get("ataques", c.ataques))
        return c


# ---------- Cálculos de batalla ----------
def calcular_daño(atacante, defensor, nombre_ataque, azar=random):
    """Devuelve (daño, efectividad, fue_critico). Fórmula parecida a la de
    los juegos de rol: depende del nivel, el poder y ataque/defensa."""
    at = ATAQUES[nombre_ataque]
    if at["poder"] == 0:
        return 0, 1.0, False
    base = (2 * atacante.nivel / 5 + 2) * at["poder"] * atacante.ataque / max(1, defensor.defensa) / 50 + 2
    mismo_tipo = 1.5 if at["tipo"] == atacante.tipo else 1.0
    efe = efectividad(at["tipo"], defensor.tipo)
    critico = azar.random() < 1 / 16
    # el nivel importa: pegar a alguien de menor nivel duele más (y al revés)
    ventaja = max(0.6, min(1.6, math.sqrt(atacante.nivel / max(1, defensor.nivel))))
    daño = base * mismo_tipo * efe * ventaja * (1.5 if critico else 1.0) * azar.uniform(0.85, 1.0)
    return max(1, int(daño)), efe, critico


def probabilidad_captura(criatura, esfera="Esfera"):
    """Más fácil si tiene poca vida, si está dormida o envenenada, y con
    una esfera mejor. Devuelve un número entre 0 y 1."""
    hp_max = criatura.hp_max
    vida = (3 * hp_max - 2 * criatura.hp) / (3 * hp_max)      # 1/3 con vida llena, ~1 casi muerta
    tasa = ESPECIES[criatura.especie]["captura"]
    bono_esfera = OBJETOS[esfera]["valor"]
    bono_estado = {"dormido": 2.0, "envenenado": 1.5}.get(criatura.estado, 1.0)
    return min(1.0, vida * tasa * bono_esfera * bono_estado * 0.85)


def exp_por_vencer(vencida, contra_entrenador):
    base = ESPECIES[vencida.especie]["exp_base"] * vencida.nivel / 7
    return int(base * (1.5 if contra_entrenador else 1.0)) + 1


# ---------- Mochila ----------
class Mochila:
    def __init__(self, contenido=None):
        self.objetos = dict(contenido if contenido is not None else MOCHILA_INICIAL)

    def tiene(self, nombre):
        return self.objetos.get(nombre, 0) > 0

    def agregar(self, nombre, cantidad=1):
        self.objetos[nombre] = self.objetos.get(nombre, 0) + cantidad

    def quitar(self, nombre):
        if not self.tiene(nombre):
            return False
        self.objetos[nombre] -= 1
        if self.objetos[nombre] == 0:
            del self.objetos[nombre]
        return True

    def lista(self):
        return [(n, c) for n, c in self.objetos.items() if c > 0]


# ---------- Batalla ----------
class Batalla:
    """Una batalla entre tu equipo y un enemigo (salvaje o entrenador).

    Cada llamada a turno(accion) devuelve eventos. Los eventos son tuplas:
      ("msg", texto)                  mostrar texto y esperar
      ("sacudida", lado)              el dibujo de ese lado tiembla
      ("parpadeo", lado)              el dibujo de ese lado parpadea (recibió daño)
      ("hp", lado)                    la barra de vida se actualiza
      ("ko", lado)                    esa criatura cayó
      ("sale", lado)                  entra una criatura nueva por ese lado
      ("esfera", sacudidas, atrapada) animación de captura
      ("exp", lado)                   barra de exp se actualiza
      ("evolucion", antes, despues)   animación de evolución
      ("fin", resultado)              terminó: "victoria", "derrota", "huida", "captura"
    lado es "jugador" o "enemigo".
    """

    def __init__(self, equipo, mochila, enemigos, entrenador=None, azar=None, caja=None):
        self.equipo = equipo
        self.mochila = mochila
        self.enemigos = enemigos
        self.entrenador = entrenador          # dict de datos.ENTRENADORES o None
        self.salvaje = entrenador is None
        self.azar = azar or random.Random()
        self.caja = caja if caja is not None else []
        self.activa = next(i for i, c in enumerate(equipo) if not c.ko)
        self.enemigo_i = 0
        self.terminada = False
        self.resultado = None
        self.intentos_huir = 0
        self.capturada = None

    # --- accesos cómodos ---
    @property
    def mia(self):
        return self.equipo[self.activa]

    @property
    def enemiga(self):
        return self.enemigos[self.enemigo_i]

    def criatura(self, lado):
        return self.mia if lado == "jugador" else self.enemiga

    def otro(self, lado):
        return "enemigo" if lado == "jugador" else "jugador"

    def eventos_inicio(self):
        ev = []
        if self.salvaje:
            ev.append(("msg", f"¡Apareció un {self.enemiga.nombre} salvaje!"))
        else:
            ev.append(("msg", f"¡{self.entrenador['nombre']} quiere pelear!"))
            ev.append(("msg", f"{self.entrenador['nombre']}: {self.entrenador['antes']}"))
            ev.append(("sale", "enemigo"))
            ev.append(("msg", f"{self.entrenador['nombre']} saca a {self.enemiga.nombre}."))
        ev.append(("sale", "jugador"))
        ev.append(("msg", f"¡Adelante, {self.mia.nombre}!"))
        return ev

    def necesita_cambio(self):
        """True si tu criatura activa cayó pero te quedan otras."""
        return self.mia.ko and any(not c.ko for c in self.equipo)

    # --- el turno ---
    def turno(self, accion):
        """accion: ("atacar", i) / ("objeto", nombre, indice_criatura) /
        ("cambiar", i) / ("huir",)"""
        if self.terminada:
            return []
        ev = []
        tipo = accion[0]

        if self.mia.ko:
            # tu criatura cayó: solo se puede cambiar (el enemigo no ataca)
            if tipo == "cambiar":
                ev += self._cambiar(accion[1])
            return ev

        enemigo_ataca = True
        if tipo == "huir":
            if not self.salvaje:
                ev.append(("msg", "¡No puedes huir de un entrenador!"))
                return ev
            self.intentos_huir += 1
            prob = 0.5 + 0.1 * self.intentos_huir + (0.2 if self.mia.velocidad >= self.enemiga.velocidad else 0)
            if self.azar.random() < prob:
                ev.append(("msg", "¡Escapaste sin problemas!"))
                return ev + self._terminar("huida")
            ev.append(("msg", "¡No pudiste escapar!"))
        elif tipo == "objeto":
            ev_obj, gasta_turno = self._usar_objeto(accion[1], accion[2] if len(accion) > 2 else self.activa)
            ev += ev_obj
            if self.terminada:
                return ev
            if not gasta_turno:
                return ev
        elif tipo == "cambiar":
            ev += self._cambiar(accion[1])
        elif tipo == "atacar":
            nombre = self.mia.ataques[accion[1]]
            at_enemigo = self._elegir_ataque_enemigo()
            yo_primero = self.mia.velocidad > self.enemiga.velocidad or (
                self.mia.velocidad == self.enemiga.velocidad and self.azar.random() < 0.5)
            orden = [("jugador", nombre), ("enemigo", at_enemigo)]
            if not yo_primero:
                orden.reverse()
            enemigo_antes = self.enemigo_i
            for lado, ataque in orden:
                if self.terminada:
                    return ev
                if self.criatura(lado).ko or self.criatura(self.otro(lado)).ko:
                    continue
                if lado == "enemigo" and self.enemigo_i != enemigo_antes:
                    continue    # la criatura nueva del rival recién salió: no ataca todavía
                ev += self._atacar(lado, ataque)
            enemigo_ataca = False

        if enemigo_ataca and not self.terminada and not self.enemiga.ko and not self.mia.ko:
            ev += self._atacar("enemigo", self._elegir_ataque_enemigo())

        # veneno al final del turno
        for lado in ("jugador", "enemigo"):
            if self.terminada:
                break
            c = self.criatura(lado)
            if not c.ko and c.estado == "envenenado":
                c.dañar(max(1, c.hp_max // 8))
                ev.append(("parpadeo", lado))
                ev.append(("hp", lado))
                ev.append(("msg", f"{c.nombre} sufre por el veneno."))
                if c.ko:
                    ev += self._cayo(lado)
        return ev

    # --- piezas del turno ---
    def _elegir_ataque_enemigo(self):
        """El enemigo elige: 7 de cada 10 veces el ataque que más daño haría."""
        e = self.enemiga
        if self.azar.random() < 0.3:
            return self.azar.choice(e.ataques)

        def puntaje(nombre):
            at = ATAQUES[nombre]
            if at["poder"] == 0:
                # un ataque de efecto vale la pena solo si aún no lo aplicó
                ya = (at["efecto"] == "subir_ataque" and e.etapa_ataque >= 2) or \
                     (at["efecto"] in ("dormir", "veneno") and self.mia.estado is not None)
                return 0 if ya else 45
            return at["poder"] * efectividad(at["tipo"], self.mia.tipo) * at["precision"] / 100
        return max(e.ataques, key=puntaje)

    def _atacar(self, lado, nombre):
        ev = []
        atacante = self.criatura(lado)
        defensor = self.criatura(self.otro(lado))
        # ¿está dormida?
        if atacante.estado == "dormido":
            atacante.turnos_dormido -= 1
            if atacante.turnos_dormido > 0:
                ev.append(("msg", f"{atacante.nombre} está dormida... zZz"))
                return ev
            atacante.estado = None
            ev.append(("hp", lado))
            ev.append(("msg", f"¡{atacante.nombre} se despertó!"))
        at = ATAQUES[nombre]
        ev.append(("msg", f"{atacante.nombre} usa {nombre}."))
        ev.append(("sacudida", lado))
        if self.azar.random() * 100 >= at["precision"]:
            ev.append(("msg", "...pero falló."))
            return ev
        if at["poder"] > 0:
            daño, efe, critico = calcular_daño(atacante, defensor, nombre, self.azar)
            defensor.dañar(daño)
            ev.append(("parpadeo", self.otro(lado)))
            ev.append(("hp", self.otro(lado)))
            if critico:
                ev.append(("msg", "¡Golpe crítico!"))
            if efe >= 2:
                ev.append(("msg", "¡Es súper efectivo!"))
            elif efe < 1:
                ev.append(("msg", "No es muy efectivo..."))
            if defensor.ko:
                ev += self._cayo(self.otro(lado))
                return ev
        efecto = at["efecto"]
        if efecto == "subir_ataque":
            if atacante.etapa_ataque < 6:
                atacante.etapa_ataque += 1
                ev.append(("msg", f"¡El ataque de {atacante.nombre} subió!"))
            else:
                ev.append(("msg", f"El ataque de {atacante.nombre} no puede subir más."))
        elif efecto == "dormir":
            if defensor.estado is None:
                defensor.estado = "dormido"
                defensor.turnos_dormido = self.azar.randint(2, 4)
                ev.append(("hp", self.otro(lado)))
                ev.append(("msg", f"¡{defensor.nombre} se quedó dormida!"))
            else:
                ev.append(("msg", "No pasó nada."))
        elif efecto == "veneno":
            if defensor.estado is None:
                defensor.estado = "envenenado"
                ev.append(("hp", self.otro(lado)))
                ev.append(("msg", f"¡{defensor.nombre} quedó envenenada!"))
            else:
                ev.append(("msg", "No pasó nada."))
        return ev

    def _cayo(self, lado):
        ev = [("ko", lado)]
        c = self.criatura(lado)
        ev.append(("msg", f"¡{c.nombre} cayó!"))
        if lado == "enemigo":
            ev += self._dar_exp()
            siguiente = next((i for i, e in enumerate(self.enemigos) if not e.ko), None)
            if siguiente is None:
                if self.salvaje:
                    ev.append(("msg", f"¡Venciste al {c.nombre} salvaje!"))
                else:
                    ev.append(("msg", f"{self.entrenador['nombre']}: {self.entrenador['despues']}"))
                    for obj, n in self.entrenador.get("premio", {}).items():
                        self.mochila.agregar(obj, n)
                        ev.append(("msg", f"¡Recibiste {n} x {obj}!"))
                ev += self._terminar("victoria")
            else:
                self.enemigo_i = siguiente
                ev.append(("sale", "enemigo"))
                ev.append(("msg", f"{self.entrenador['nombre']} saca a {self.enemiga.nombre}."))
        else:
            if not any(not c.ko for c in self.equipo):
                ev.append(("msg", "No te quedan criaturas..."))
                ev += self._terminar("derrota")
            else:
                ev.append(("msg", "¡Elige otra criatura!"))
        return ev

    def _dar_exp(self):
        ev = []
        if self.mia.ko:
            return ev
        cantidad = exp_por_vencer(self.enemiga, not self.salvaje)
        ev.append(("msg", f"{self.mia.nombre} gana {cantidad} puntos de experiencia."))
        for e in self.mia.ganar_exp(cantidad):
            if e[0] == "nivel":
                ev.append(("exp", "jugador"))
                ev.append(("hp", "jugador"))
                ev.append(("msg", f"¡{self.mia.nombre} subió al nivel {e[1]}!"))
            elif e[0] == "aprende":
                ev.append(("msg", f"¡{self.mia.nombre} aprendió {e[1]}!"))
            elif e[0] == "evolucion":
                ev.append(("msg", f"¿Qué? ¡{e[1]} está cambiando de forma!"))
                ev.append(("evolucion", e[1], e[2]))
                ev.append(("hp", "jugador"))
                ev.append(("msg", f"¡{e[1]} evolucionó en {e[2]}!"))
        ev.append(("exp", "jugador"))
        return ev

    def _cambiar(self, i):
        ev = []
        if i == self.activa or self.equipo[i].ko:
            return [("msg", "Esa no puede salir ahora.")]
        if not self.mia.ko:
            ev.append(("msg", f"¡Vuelve, {self.mia.nombre}!"))
        self.mia.terminar_batalla()
        self.activa = i
        ev.append(("sale", "jugador"))
        ev.append(("msg", f"¡Adelante, {self.mia.nombre}!"))
        return ev

    def _usar_objeto(self, nombre, objetivo_i):
        """Devuelve (eventos, gasta_turno)."""
        if not self.mochila.tiene(nombre):
            return [("msg", f"No te quedan {nombre}.")], False
        obj = OBJETOS[nombre]
        objetivo = self.equipo[objetivo_i]
        if obj["tipo"] == "curar":
            if objetivo.ko:
                return [("msg", f"{objetivo.nombre} está fuera de combate.")], False
            if objetivo.hp >= objetivo.hp_max:
                return [("msg", f"{objetivo.nombre} ya tiene toda su vida.")], False
            self.mochila.quitar(nombre)
            curado = objetivo.curar(obj["valor"])
            ev = [("hp", "jugador"), ("msg", f"{objetivo.nombre} recupera {curado} de vida.")]
            return ev, True
        if obj["tipo"] == "estado":
            if objetivo.estado is None:
                return [("msg", f"{objetivo.nombre} está bien, no lo necesita.")], False
            self.mochila.quitar(nombre)
            objetivo.estado = None
            objetivo.turnos_dormido = 0
            return [("hp", "jugador"), ("msg", f"¡{objetivo.nombre} se siente mejor!")], True
        if obj["tipo"] == "esfera":
            if not self.salvaje:
                return [("msg", "¡No puedes atrapar la criatura de otro entrenador!")], False
            self.mochila.quitar(nombre)
            ev = [("msg", f"¡Lanzaste una {nombre}!")]
            prob = probabilidad_captura(self.enemiga, nombre)
            # 3 sacudidas: cada una tiene que "pasar" para atrapar
            sacudidas = 0
            por_sacudida = prob ** (1 / 3)
            for _ in range(3):
                if self.azar.random() < por_sacudida:
                    sacudidas += 1
                else:
                    break
            atrapada = sacudidas == 3
            ev.append(("esfera", sacudidas, atrapada))
            if atrapada:
                ev.append(("msg", f"¡Atrapaste a {self.enemiga.nombre}!"))
                self.capturada = self.enemiga
                self.enemiga.terminar_batalla()
                if len(self.equipo) < MAX_EQUIPO:
                    self.equipo.append(self.enemiga)
                    ev.append(("msg", f"{self.enemiga.nombre} se une a tu equipo."))
                else:
                    self.caja.append(self.enemiga)
                    ev.append(("msg", "Tu equipo está lleno: fue a la caja."))
                return ev + self._terminar("captura"), False
            frases = ["¡Se escapó al toque!", "¡Casi... pero se escapó!",
                      "¡Uf, faltó poquito!"]
            ev.append(("msg", frases[min(sacudidas, 2)]))
            return ev, True
        return [("msg", "Eso no se puede usar aquí.")], False

    def _terminar(self, resultado):
        self.terminada = True
        self.resultado = resultado
        for c in self.equipo:
            c.terminar_batalla()
        return [("fin", resultado)]


# ---------- Partida (guardar y cargar) ----------
class Partida:
    def __init__(self):
        self.equipo = []
        self.caja = []
        self.mochila = Mochila()
        self.pos = None                 # (columna, fila) en el mapa
        self.vencidos = []              # letras de entrenadores vencidos
        self.nombre = "Manu"
        self.campeon = False

    def a_dict(self):
        return {
            "version": 1,
            "nombre": self.nombre,
            "pos": list(self.pos) if self.pos else None,
            "equipo": [c.a_dict() for c in self.equipo],
            "caja": [c.a_dict() for c in self.caja],
            "mochila": self.mochila.objetos,
            "vencidos": self.vencidos,
            "campeon": self.campeon,
        }

    @classmethod
    def desde_dict(cls, d):
        p = cls()
        p.nombre = d.get("nombre", "Manu")
        p.pos = tuple(d["pos"]) if d.get("pos") else None
        p.equipo = [Criatura.desde_dict(x) for x in d.get("equipo", [])]
        p.caja = [Criatura.desde_dict(x) for x in d.get("caja", [])]
        p.mochila = Mochila(d.get("mochila", {}))
        p.vencidos = list(d.get("vencidos", []))
        p.campeon = bool(d.get("campeon", False))
        return p

    def guardar(self, ruta):
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump(self.a_dict(), f, ensure_ascii=False, indent=2)

    @classmethod
    def cargar(cls, ruta):
        with open(ruta, encoding="utf-8") as f:
            return cls.desde_dict(json.load(f))

    def curar_equipo(self):
        for c in self.equipo:
            c.curar_todo()

    def tiene_vivas(self):
        return any(not c.ko for c in self.equipo)


def texto_estado(criatura):
    if criatura.estado == "dormido":
        return "ZZZ"
    if criatura.estado == "envenenado":
        return "VEN"
    return ""


def texto_tipo(tipo):
    return NOMBRE_TIPO.get(tipo, tipo)
