# Manu Pack

Paquete de texturas (resource pack) para **Minecraft 1.21.4**, dibujado píxel a píxel con código Python (pygame).

## Cómo instalar

1. Copia `manu-pack.zip` a la carpeta de resource packs de tu Minecraft:
   - Minecraft (Flatpak): `~/.var/app/com.mojang.Minecraft/.minecraft/resourcepacks/`
   - Otro launcher: la carpeta `resourcepacks` dentro de tu `.minecraft`.
2. Abre Minecraft → **Opciones → Paquetes de recursos**.
3. Busca **Manu Pack** en la lista de la izquierda y haz clic para pasarlo a la derecha.
4. Dale a **Listo**. ¡Ya está!

## Qué cambia

Ítems: espada y pico de diamante, diamante, manzana, manzana dorada, perla de ender,
tótem de la inmortalidad, pan y filete cocido.

Bloques: piedra, tierra, tablas de roble, pasto, glowstone, bloque de diamante,
mena de diamante (normal y de pizarra), TNT (con calavera) y mesa de crafteo.

HUD: el corazón de vida.

## Cómo volver a dibujar las texturas

El script está en `.tmp/dibujar.py`. Cada textura es una lista de 16 textos donde
cada letra es un color y el punto `.` es transparente. Para regenerar todo:

```bash
SDL_VIDEODRIVER=dummy ~/GameStudio/flappy/.venv/bin/python .tmp/dibujar.py
```

Y para armar el zip de nuevo (desde dentro de la carpeta `manu-pack`):

```bash
zip -r ../manu-pack.zip pack.mcmeta pack.png README.md assets -x '.*' '*/._*'
```
