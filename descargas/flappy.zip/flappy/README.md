# Flappy de Manu

Un Flappy Bird hecho en Python con pygame.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 flappy.py

En Windows: `python flappy.py`. En Linux/Mac también sirve `./jugar.sh`.

- **ESPACIO** salta · **R** reinicia cuando perdiste · **ESC** cierra.
- **1, 2, 3** antes de empezar: eliges el pájaro (Clásico, Azulito o Fueguito).
- Cada punto los tubos van un poco más rápido y el hueco se achica un poquito.
- Tu récord se guarda en `record.txt` (bórralo para empezar de cero).
- Los sonidos (salto, punto, golpe) se fabrican con matemáticas al abrir el
  juego: no hay archivos de audio. Mira `fabricar_sonido` en `flappy.py`.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo, para
saltar con W y reiniciar con ENTER:

```
saltar    = w
reiniciar = return
pajaro1   = q
```

Nombres válidos: letras (`a`, `b`...), flechas (`up`, `down`, `left`, `right`),
`space`, `return`, `tab`, `left shift`, `left ctrl`, números. Si escribes una
tecla que no existe, el juego avisa en la terminal y usa la de siempre.

## Para cambiar cosas

Arriba de `flappy.py` están los ajustes: `GRAVEDAD`, `SALTO`, `HUECO_TUBO`,
`VELOCIDAD_TUBOS`, `HUECO_POR_PUNTO` (qué tan rápido se pone difícil)...
Y en `SKINS` puedes cambiar los colores de cada pájaro o inventar el tuyo. Cambia un número, guarda, y vuelve a correrlo.

## Para poner tu propio pájaro

1. Guarda un PNG (con fondo transparente) en esta carpeta, por ejemplo `pajaro.png`.
2. En `flappy.py` busca `>>> TU SPRITE AQUÍ <<<` y descomenta las dos líneas
   de `self.imagen`.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola. (El pip que la armó está
desempacado en `~/.local/opt/pip`, sin sudo.)
