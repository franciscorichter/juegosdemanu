"""
Flappy Bird — versión de Manu
==============================
Controles:
  ESPACIO  -> el pájaro salta
  1, 2, 3  -> elegir pájaro (antes de empezar)
  R        -> reiniciar cuando perdiste
  ESC      -> salir
  Todas las teclas se cambian en controles.txt (al lado de este archivo).

Todo se dibuja con figuras de colores. Si quieres tu propio dibujo
del pájaro, busca la parte que dice  >>> TU SPRITE AQUÍ <<<  más abajo.
Los sonidos también se fabrican con matemáticas: no hay archivos .wav.
Tu récord se guarda en record.txt.
"""

import array
import math
import os
import random

import pygame

# ---------- Ajustes del juego (cámbialos y prueba qué pasa) ----------
ANCHO, ALTO = 400, 600          # tamaño de la ventana
FPS = 60                        # cuadros por segundo

GRAVEDAD = 0.5                  # cuánto cae el pájaro cada cuadro
SALTO = -9                      # fuerza del salto (negativo = hacia arriba)
RADIO_PAJARO = 16               # tamaño del pájaro (es un círculo)

ANCHO_TUBO = 70                 # qué tan gordos son los tubos
HUECO_TUBO = 170                # espacio entre tubos al empezar
HUECO_MINIMO = 115              # el hueco nunca se achica más que esto
VELOCIDAD_TUBOS = 3             # velocidad de los tubos al empezar
VELOCIDAD_MAXIMA = 7
CADA_CUANTO_TUBO = 1500         # milisegundos entre un tubo y el siguiente
CADA_CUANTO_MINIMO = 900

# cada punto: el hueco se achica y los tubos aceleran un poquito
HUECO_POR_PUNTO = 2.5
VELOCIDAD_POR_PUNTO = 0.12
TIEMPO_POR_PUNTO = 20

ALTO_SUELO = 60                 # franja café de abajo

# ---------- Colores (rojo, verde, azul: cada uno de 0 a 255) ----------
CIELO = (110, 200, 240)
VERDE_TUBO = (80, 190, 80)
VERDE_OSCURO = (40, 120, 40)
SUELO = (200, 160, 90)
AMARILLO = (255, 220, 40)
NARANJA = (255, 140, 0)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
ROJO = (220, 50, 50)

# ---------- Skins del pájaro: (nombre, cuerpo, pico, adorno) ----------
SKINS = [
    ("Clásico", (255, 220, 40), (255, 140, 0), None),
    ("Azulito", (80, 150, 255), (255, 200, 60), "cresta"),
    ("Fueguito", (240, 70, 40), (255, 230, 80), "llamas"),
]


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "saltar": "space", "reiniciar": "r", "salir": "escape",
    "pajaro1": "1", "pajaro2": "2", "pajaro3": "3",
}


def carpeta():
    return os.path.dirname(os.path.abspath(__file__))


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(carpeta(), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}      # se llena en main(), después de pygame.init()


# ---------- Récord (se guarda en record.txt) ----------
def leer_record():
    try:
        with open(os.path.join(carpeta(), "record.txt"), encoding="utf-8") as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return 0


def guardar_record(puntos):
    with open(os.path.join(carpeta(), "record.txt"), "w", encoding="utf-8") as f:
        f.write(f"{puntos}\n")


# ---------- Sonidos fabricados con matemáticas ----------
FRECUENCIA_AUDIO = 22050


def fabricar_sonido(duracion, tono_inicio, tono_fin, volumen=0.4, ruido=0.0):
    """Crea un sonido: una onda que va de tono_inicio a tono_fin (en Hz).
    ruido = 0 es un pitido limpio, ruido = 1 es puro ruido (para el golpe)."""
    n = int(FRECUENCIA_AUDIO * duracion)
    datos = array.array("h")        # 'h' = enteros de 16 bits, como un .wav
    fase = 0.0
    for i in range(n):
        t = i / n
        tono = tono_inicio + (tono_fin - tono_inicio) * t
        fase += 2 * math.pi * tono / FRECUENCIA_AUDIO
        onda = math.sin(fase)
        if ruido:
            onda = onda * (1 - ruido) + random.uniform(-1, 1) * ruido
        apagado = 1 - t             # se va apagando hacia el final
        datos.append(int(onda * apagado * volumen * 32767))
    return pygame.mixer.Sound(buffer=datos.tobytes())


def cargar_sonidos():
    """Devuelve un diccionario de sonidos, o vacío si no hay audio."""
    try:
        # pygame.init() ya abrió el audio con otra configuración; lo abrimos
        # de nuevo con la nuestra (22050 Hz, 16 bits, mono) para que los
        # datos que fabricamos suenen a la velocidad correcta.
        pygame.mixer.quit()
        pygame.mixer.init(FRECUENCIA_AUDIO, -16, 1, 512)
        return {
            "salto": fabricar_sonido(0.10, 400, 800),
            "punto": fabricar_sonido(0.15, 900, 1400, 0.3),
            "golpe": fabricar_sonido(0.30, 200, 60, 0.5, ruido=0.6),
        }
    except pygame.error as e:
        print("Sin sonido:", e)
        return {}


def sonar(sonidos, nombre):
    if nombre in sonidos:
        sonidos[nombre].play()


# ---------- El pájaro ----------
class Pajaro:
    def __init__(self, skin=0):
        self.x = 90
        self.y = ALTO // 2
        self.vel = 0            # velocidad vertical: + baja, - sube
        self.skin = skin

        # >>> TU SPRITE AQUÍ <<<
        # Si quieres usar tu propio dibujo, pon un PNG en esta carpeta
        # (por ejemplo "pajaro.png") y descomenta estas dos líneas:
        #
        # self.imagen = pygame.image.load("pajaro.png").convert_alpha()
        # self.imagen = pygame.transform.scale(self.imagen, (40, 40))
        #
        # Si no existe self.imagen, se dibuja el pájaro de figuras.
        self.imagen = None

    def saltar(self):
        self.vel = SALTO

    def actualizar(self):
        self.vel += GRAVEDAD    # la gravedad lo empuja hacia abajo
        self.y += self.vel      # y se mueve según su velocidad

    def rect(self):
        """La 'caja' del pájaro, para saber si choca con algo."""
        return pygame.Rect(self.x - RADIO_PAJARO, self.y - RADIO_PAJARO,
                           RADIO_PAJARO * 2, RADIO_PAJARO * 2)

    def dibujar(self, pantalla, x=None, y=None):
        x = self.x if x is None else x
        y = int(self.y) if y is None else y
        if self.imagen is not None:
            # Con sprite: lo centramos en la posición del pájaro
            r = self.imagen.get_rect(center=(x, y))
            pantalla.blit(self.imagen, r)
            return

        nombre, cuerpo, pico, adorno = SKINS[self.skin]
        centro = (x, y)
        if adorno == "llamas":
            # colita de fuego detrás
            for i, c in enumerate(((255, 200, 0), (255, 120, 0), (220, 40, 0))):
                largo = 26 - i * 7
                pygame.draw.polygon(pantalla, c, [(x - 8, y - 6 + i * 2), (x - 8 - largo, y + random.randint(-3, 3)), (x - 8, y + 6 - i * 2)])
        pygame.draw.circle(pantalla, cuerpo, centro, RADIO_PAJARO)
        pygame.draw.circle(pantalla, NEGRO, centro, RADIO_PAJARO, 2)
        if adorno == "cresta":
            pygame.draw.polygon(pantalla, pico, [(x - 4, y - 14), (x, y - 26), (x + 4, y - 14)])
            pygame.draw.polygon(pantalla, pico, [(x + 2, y - 14), (x + 9, y - 22), (x + 8, y - 12)])
        # ojo y pico
        pygame.draw.circle(pantalla, BLANCO, (x + 6, y - 5), 5)
        pygame.draw.circle(pantalla, NEGRO, (x + 7, y - 5), 2)
        pygame.draw.polygon(pantalla, pico, [(x + 14, y), (x + 26, y + 3), (x + 14, y + 7)])


# ---------- Un par de tubos (arriba y abajo) ----------
class Tubo:
    def __init__(self, hueco):
        self.x = ANCHO
        self.hueco = hueco
        # dónde empieza el hueco, al azar pero sin pegarse a los bordes
        margen = 60
        self.hueco_y = random.randint(margen, ALTO - ALTO_SUELO - hueco - margen)
        self.contado = False    # para sumar el punto solo una vez

    def actualizar(self, velocidad):
        self.x -= velocidad

    def rects(self):
        arriba = pygame.Rect(self.x, 0, ANCHO_TUBO, self.hueco_y)
        abajo_y = self.hueco_y + self.hueco
        abajo = pygame.Rect(self.x, abajo_y, ANCHO_TUBO, ALTO - ALTO_SUELO - abajo_y)
        return arriba, abajo

    def fuera_de_pantalla(self):
        return self.x + ANCHO_TUBO < 0

    def dibujar(self, pantalla):
        for r in self.rects():
            pygame.draw.rect(pantalla, VERDE_TUBO, r)
            pygame.draw.rect(pantalla, VERDE_OSCURO, r, 3)


# ---------- Dificultad según los puntos ----------
def dificultad(puntos):
    """Devuelve (hueco, velocidad, milisegundos entre tubos) para estos puntos."""
    hueco = max(HUECO_MINIMO, HUECO_TUBO - puntos * HUECO_POR_PUNTO)
    velocidad = min(VELOCIDAD_MAXIMA, VELOCIDAD_TUBOS + puntos * VELOCIDAD_POR_PUNTO)
    cada = max(CADA_CUANTO_MINIMO, CADA_CUANTO_TUBO - puntos * TIEMPO_POR_PUNTO)
    return hueco, velocidad, cada


# ---------- Funciones de ayuda ----------
def texto(pantalla, fuente, msg, y, color=BLANCO, sombra=True):
    """Escribe un texto centrado en la pantalla, a la altura y."""
    if sombra:
        s = fuente.render(msg, True, NEGRO)
        pantalla.blit(s, s.get_rect(center=(ANCHO // 2 + 2, y + 2)))
    t = fuente.render(msg, True, color)
    pantalla.blit(t, t.get_rect(center=(ANCHO // 2, y)))


def nuevo_juego(skin):
    """Devuelve todo lo que necesita un juego recién empezado."""
    return Pajaro(skin), [], 0


# ---------- El juego ----------
def main():
    pygame.init()
    TECLA.update(cargar_controles())
    sonidos = cargar_sonidos()
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Flappy de Manu")
    reloj = pygame.time.Clock()
    fuente_grande = pygame.font.SysFont(None, 64)
    fuente_chica = pygame.font.SysFont(None, 32)
    fuente_mini = pygame.font.SysFont(None, 22)

    record = leer_record()
    skin = 0
    pajaro, tubos, puntos = nuevo_juego(skin)
    perdiste = False
    empezo = False              # antes del primer salto, el pájaro flota
    nuevo_record = False
    ultimo_tubo = pygame.time.get_ticks()
    teclas_skin = [TECLA["pajaro1"], TECLA["pajaro2"], TECLA["pajaro3"]]

    corriendo = True
    while corriendo:
        # 1) Leer teclas y eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                corriendo = False
            elif e.type == pygame.KEYDOWN:
                if e.key == TECLA["salir"]:
                    corriendo = False
                elif e.key == TECLA["saltar"] and not perdiste:
                    empezo = True
                    pajaro.saltar()
                    sonar(sonidos, "salto")
                elif e.key == TECLA["reiniciar"] and perdiste:
                    pajaro, tubos, puntos = nuevo_juego(skin)
                    perdiste = False
                    empezo = False
                    nuevo_record = False
                    ultimo_tubo = pygame.time.get_ticks()
                elif not empezo and e.key in teclas_skin:
                    skin = teclas_skin.index(e.key)
                    pajaro.skin = skin

        # 2) Mover cosas (solo si el juego está andando)
        if empezo and not perdiste:
            hueco, velocidad, cada = dificultad(puntos)
            pajaro.actualizar()

            ahora = pygame.time.get_ticks()
            if ahora - ultimo_tubo > cada:
                tubos.append(Tubo(int(hueco)))
                ultimo_tubo = ahora

            for t in tubos:
                t.actualizar(velocidad)
                # ¿el pájaro ya pasó este tubo? -> punto
                if not t.contado and t.x + ANCHO_TUBO < pajaro.x:
                    t.contado = True
                    puntos += 1
                    sonar(sonidos, "punto")
            tubos = [t for t in tubos if not t.fuera_de_pantalla()]

            # 3) Choques
            caja = pajaro.rect()
            toca_suelo = pajaro.y + RADIO_PAJARO >= ALTO - ALTO_SUELO
            toca_techo = pajaro.y - RADIO_PAJARO <= 0
            toca_tubo = any(caja.colliderect(r) for t in tubos for r in t.rects())
            if toca_suelo or toca_techo or toca_tubo:
                perdiste = True
                sonar(sonidos, "golpe")
                if puntos > record:
                    record = puntos
                    nuevo_record = True
                    guardar_record(record)

        # 4) Dibujar todo
        pantalla.fill(CIELO)
        for t in tubos:
            t.dibujar(pantalla)
        pygame.draw.rect(pantalla, SUELO, (0, ALTO - ALTO_SUELO, ANCHO, ALTO_SUELO))
        pygame.draw.line(pantalla, VERDE_OSCURO, (0, ALTO - ALTO_SUELO), (ANCHO, ALTO - ALTO_SUELO), 4)
        pajaro.dibujar(pantalla)

        texto(pantalla, fuente_grande, str(puntos), 50)
        texto(pantalla, fuente_mini, f"Récord: {record}", 90)

        if not empezo:
            texto(pantalla, fuente_chica, f"{pygame.key.name(TECLA['saltar']).upper()} para saltar", ALTO // 2 + 80)
            # menú de pájaros: los tres dibujados, el elegido con marco
            texto(pantalla, fuente_mini, "Elige tu pájaro:", ALTO // 2 + 120)
            for i in range(3):
                x = ANCHO // 2 + (i - 1) * 90
                y = ALTO // 2 + 165
                if i == skin:
                    pygame.draw.rect(pantalla, BLANCO, (x - 30, y - 30, 60, 60), 3, border_radius=8)
                Pajaro(i).dibujar(pantalla, x, y)
                tecla = pygame.key.name(teclas_skin[i]).upper()
                texto_mini = fuente_mini.render(f"{tecla}: {SKINS[i][0]}", True, NEGRO)
                pantalla.blit(texto_mini, texto_mini.get_rect(center=(x, y + 42)))
        if perdiste:
            texto(pantalla, fuente_grande, "PERDISTE", ALTO // 2 - 40, ROJO)
            texto(pantalla, fuente_chica, f"Puntos: {puntos}", ALTO // 2 + 10)
            if nuevo_record:
                texto(pantalla, fuente_chica, "¡NUEVO RÉCORD!", ALTO // 2 + 45, AMARILLO)
            texto(pantalla, fuente_chica, f"{pygame.key.name(TECLA['reiniciar']).upper()} para jugar de nuevo", ALTO // 2 + 85)

        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
