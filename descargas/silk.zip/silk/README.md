# Silk — plataformas de Manu

Un juego de plataformas en Python con pygame. Corres, saltas (¡doble salto!),
haces dash, atacas con una aguja, esquivas pinchos y pasas 5 niveles con
dos jefes distintos. Tu mejor tiempo queda guardado en `record.txt`.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 silk.py

En Windows: `python silk.py`. En Linux/Mac también sirve `./jugar.sh`.

- **Flechas** correr · **ESPACIO** saltar (dos veces = doble salto)
- **X** atacar con la aguja · **SHIFT izquierdo** dash (impulso rápido, con cooldown)
- **R** reiniciar · **ESC** cerrar
- Tienes 3 corazones. Los enemigos, el jefe y los pinchos te quitan uno.
- Las banderas grises son **checkpoints**: si te caes, reapareces en la última que tocaste.
- En el nivel 3 la bandera de meta está apagada hasta que venzas al **jefe**
  (5 golpes de aguja; salta hacia ti, así que esquívalo y pégale por el lado).
- Desde el nivel 4 hay **voladores**: flotan tranquilos hasta que te ven, y ahí
  te persiguen por el aire. Un golpe de aguja los baja.
- En el nivel 5 espera la **polilla** (6 golpes): vuela alto y se lanza en
  picada hacia donde estabas. Esquiva la picada y pégale cuando está abajo o
  sube a las plataformas.
- Arriba a la derecha va el cronómetro y tu récord. Si terminas los 3 niveles
  más rápido que nunca, se guarda en `record.txt` (bórralo para empezar de cero).

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo, para WASD:

```
izquierda = a
derecha   = d
saltar    = w
atacar    = j
dash      = k
```

Nombres válidos: letras (`a`, `b`...), flechas (`up`, `down`, `left`, `right`),
`space`, `return`, `tab`, `left shift`, `left ctrl`, números. Si escribes una
tecla que no existe, el juego avisa en la terminal y usa la de siempre.

## Dibuja tu propio nivel

Los niveles son `nivel1.txt` a `nivel5.txt` (lista `NIVELES` arriba de
`silk.py`; agrega los tuyos ahí). Cada letra es un cuadrito:

    #  bloque        E  enemigo       V  volador      ^  pincho
    C  checkpoint    M  meta          P  donde empiezas
    J  jefe saltarín K  jefe polilla  .  nada

Cambia el dibujo, guarda, y corre el juego de nuevo. Consejos:
- Los enemigos y el jugador necesitan un `#` debajo, si no se caen.
- Con doble salto llegas a unos 5 cuadritos de alto y unos 8 de largo.
- Al tocar la `M` pasas al siguiente nivel de la lista. Con `J` o `K` la meta se abre solo al vencer al jefe.
- La `K` necesita espacio libre arriba: la polilla flota 4 cuadritos por encima de donde la pongas.

## Para cambiar cómo se siente

Arriba de `silk.py` están los ajustes: `GRAVEDAD`, `SALTO`, `VELOCIDAD`,
`SALTOS_MAX` (¡pon 3 para triple salto!), `VIDAS`, `DASH_VEL`, `JEFE_VIDA`,
`JEFE2_VIDA`, `VEL_VOLADOR`, `VISTA_VOLADOR`...

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
