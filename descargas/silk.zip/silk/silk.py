"""
Silk — plataformas de Manu
==========================
Inspirado en juegos de bichitos con aguja, pero con dibujos propios.

Controles:
  FLECHAS         -> correr
  ESPACIO         -> saltar (aprieta otra vez en el aire = doble salto)
  X               -> atacar con la aguja
  SHIFT IZQ       -> dash (un impulso rápido; tiene un cooldown corto)
  R               -> reiniciar cuando ganaste o perdiste
  ESC             -> salir
  Todas las teclas se cambian en controles.txt (al lado de este archivo).

Los niveles están en nivel1.txt ... nivel5.txt (lista NIVELES abajo).
Al llegar a la meta pasas al siguiente. Se dibujan con letras:
  #  bloque      E  enemigo      V  volador     ^  pincho       C  checkpoint
  M  meta        P  donde empiezas   J  jefe saltarín   K  jefe polilla   .  nada
Tu mejor tiempo se guarda en record.txt.
"""

import math
import os
import random

import pygame

# ---------- Ajustes (cámbialos y prueba qué pasa) ----------
NIVELES = ["nivel1.txt", "nivel2.txt", "nivel3.txt", "nivel4.txt", "nivel5.txt"]
TILE = 40                       # tamaño de cada cuadrito del mapa
ANCHO, ALTO = 800, 560          # tamaño de la ventana
FPS = 60

VELOCIDAD = 5                   # qué tan rápido corre el personaje
GRAVEDAD = 0.6                  # cuánto cae cada cuadro
SALTO = -12                     # fuerza del salto (negativo = arriba)
SALTOS_MAX = 2                  # 2 = doble salto
VIDAS = 3                       # corazones

ATAQUE_DURA = 12                # cuadros que dura el golpe de aguja
ATAQUE_LARGO = 44               # largo de la aguja
INVULNERABLE = 60               # cuadros sin recibir daño después de un golpe
EMPUJON = 7                     # empujón hacia atrás al recibir daño

DASH_VEL = 14                   # velocidad del dash
DASH_DURA = 9                   # cuadros que dura el dash
DASH_COOLDOWN = 35              # cuadros de espera entre un dash y otro

VEL_ENEMIGO = 1.5
VEL_VOLADOR = 2.2               # velocidad del volador cuando te persigue
VISTA_VOLADOR = 320             # desde qué distancia te ve

JEFE_VIDA = 5                   # golpes para vencer al jefe
JEFE_CADA = 100                 # cuadros entre salto y salto del jefe
JEFE_SALTO = -14
JEFE_VEL = 4
JEFE2_VIDA = 6                  # la polilla aguanta más
JEFE2_CADA = 130                # cuadros entre picada y picada
JEFE2_VEL = 7                   # velocidad de la picada

# ---------- Colores ----------
FONDO = (28, 24, 44)
FONDO_LEJOS = (44, 38, 70)
FONDO_MEDIO = (60, 52, 95)
ESTRELLA = (200, 200, 230)
BLOQUE = (90, 80, 120)
BLOQUE_BORDE = (140, 125, 180)
PINCHO = (200, 200, 220)
PERSONAJE = (240, 240, 250)
CAPA = (200, 60, 80)
AGUJA = (255, 255, 255)
ENEMIGO = (120, 200, 90)
ENEMIGO_OJO = (20, 20, 20)
VOLADOR = (200, 140, 220)
POLILLA = (230, 190, 120)
POLILLA_ALA = (180, 120, 90)
JEFE = (170, 80, 200)
JEFE_HERIDO = (255, 255, 255)
META = (255, 210, 60)
META_APAGADA = (120, 110, 90)
CHECK_APAGADO = (110, 110, 140)
CHECK_PRENDIDO = (90, 220, 200)
CORAZON = (230, 60, 90)
CORAZON_VACIO = (70, 50, 70)
DASH_COLOR = (120, 220, 255)
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)


# ---------- Controles (se leen de controles.txt) ----------
CONTROLES_DEFECTO = {
    "izquierda": "left", "derecha": "right", "saltar": "space",
    "atacar": "x", "dash": "left shift", "reiniciar": "r", "salir": "escape",
}


def carpeta():
    """La carpeta donde está este archivo (para leer niveles, controles, récord)."""
    return os.path.dirname(os.path.abspath(__file__))


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una línea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(carpeta(), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}      # se llena en main(), después de pygame.init()


# ---------- Récord (se guarda en record.txt) ----------
def leer_record():
    """Devuelve el mejor tiempo en segundos, o None si no hay."""
    try:
        with open(os.path.join(carpeta(), "record.txt"), encoding="utf-8") as f:
            return float(f.read().strip())
    except (OSError, ValueError):
        return None


def guardar_record(segundos):
    with open(os.path.join(carpeta(), "record.txt"), "w", encoding="utf-8") as f:
        f.write(f"{segundos:.2f}\n")


def formato_tiempo(segundos):
    m = int(segundos // 60)
    s = segundos - m * 60
    return f"{m}:{s:05.2f}"


# ---------- Cargar un nivel desde el texto ----------
def cargar_nivel(ruta):
    with open(os.path.join(carpeta(), ruta), encoding="utf-8") as f:
        filas = [linea.rstrip("\n") for linea in f if linea.strip()]
    n = dict(bloques=[], pinchos=[], enemigos=[], voladores=[], checkpoints=[], jefe=None,
             jefe2=None, inicio=(TILE, TILE), meta=None)
    for fy, fila in enumerate(filas):
        for fx, letra in enumerate(fila):
            x, y = fx * TILE, fy * TILE
            if letra == "#":
                n["bloques"].append(pygame.Rect(x, y, TILE, TILE))
            elif letra == "^":
                n["pinchos"].append(pygame.Rect(x, y, TILE, TILE))
            elif letra == "E":
                n["enemigos"].append((x, y))
            elif letra == "V":
                n["voladores"].append((x, y))
            elif letra == "K":
                n["jefe2"] = (x, y)
            elif letra == "C":
                n["checkpoints"].append(pygame.Rect(x, y, TILE, TILE))
            elif letra == "J":
                n["jefe"] = (x, y)
            elif letra == "P":
                n["inicio"] = (x, y)
            elif letra == "M":
                n["meta"] = pygame.Rect(x, y, TILE, TILE)
    n["ancho"] = max(len(f) for f in filas) * TILE
    n["alto"] = len(filas) * TILE
    return n


# ---------- Mover un rect chocando con bloques ----------
def mover_con_choques(rect, dx, dy, bloques):
    """Mueve el rect y lo frena contra los bloques. Devuelve (toca_suelo, toca_pared)."""
    toca_suelo = toca_pared = False
    rect.x += dx
    for b in bloques:
        if rect.colliderect(b):
            toca_pared = True
            if dx > 0:
                rect.right = b.left
            elif dx < 0:
                rect.left = b.right
    rect.y += dy
    for b in bloques:
        if rect.colliderect(b):
            if dy > 0:
                rect.bottom = b.top
                toca_suelo = True
            elif dy < 0:
                rect.top = b.bottom
    return toca_suelo, toca_pared


# ---------- Partículas (chispitas al golpear) ----------
class Particula:
    def __init__(self, x, y, color):
        self.x, self.y = x, y
        self.vx = random.uniform(-4, 4)
        self.vy = random.uniform(-5, 1)
        self.vida = random.randint(15, 30)
        self.color = color

    def actualizar(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.3
        self.vida -= 1

    def dibujar(self, pantalla, cam):
        tam = max(1, self.vida // 6)
        pygame.draw.rect(pantalla, self.color, (int(self.x - cam), int(self.y), tam, tam))


def chispas(lista, x, y, color, cuantas=12):
    for _ in range(cuantas):
        lista.append(Particula(x, y, color))


# ---------- El personaje ----------
class Personaje:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x + 6, y, 28, 40)
        self.vel_y = 0
        self.mira_derecha = True
        self.saltos = 0             # cuántos saltos lleva en el aire
        self.en_suelo = False
        self.vidas = VIDAS
        self.atacando = 0           # cuadros que le quedan al ataque
        self.invulnerable = 0
        self.empujon_x = 0
        self.dash = 0               # cuadros que le quedan al dash
        self.dash_espera = 0        # cooldown del dash

    def saltar(self):
        if self.saltos < SALTOS_MAX:
            self.vel_y = SALTO
            self.saltos += 1

    def atacar(self):
        if self.atacando == 0:
            self.atacando = ATAQUE_DURA

    def hacer_dash(self):
        if self.dash == 0 and self.dash_espera == 0:
            self.dash = DASH_DURA
            self.dash_espera = DASH_COOLDOWN
            self.vel_y = 0

    def aguja(self):
        """El rect de la aguja cuando está atacando, o None."""
        if self.atacando == 0:
            return None
        y = self.rect.centery - 4
        if self.mira_derecha:
            return pygame.Rect(self.rect.right, y, ATAQUE_LARGO, 8)
        return pygame.Rect(self.rect.left - ATAQUE_LARGO, y, ATAQUE_LARGO, 8)

    def herir(self, desde_x):
        """Recibe un golpe que viene desde la posición desde_x."""
        if self.invulnerable > 0:
            return False
        self.vidas -= 1
        self.invulnerable = INVULNERABLE
        self.vel_y = -6
        self.dash = 0
        self.empujon_x = EMPUJON if self.rect.centerx > desde_x else -EMPUJON
        return True

    def reaparecer(self, pos):
        self.rect.topleft = (pos[0] + 6, pos[1])
        self.vel_y = 0
        self.dash = 0
        self.empujon_x = 0
        self.invulnerable = INVULNERABLE

    def actualizar(self, teclas, bloques):
        dx = 0
        if teclas[TECLA["izquierda"]]:
            dx = -VELOCIDAD
            self.mira_derecha = False
        if teclas[TECLA["derecha"]]:
            dx = VELOCIDAD
            self.mira_derecha = True
        if self.empujon_x != 0:
            dx = self.empujon_x
            self.empujon_x = int(self.empujon_x * 0.8)

        if self.dash > 0:
            # durante el dash: rapidísimo, sin gravedad
            dx = DASH_VEL if self.mira_derecha else -DASH_VEL
            self.vel_y = 0
            self.dash -= 1
        else:
            self.vel_y += GRAVEDAD
            self.vel_y = min(self.vel_y, 16)     # no caer infinitamente rápido

        dy = int(self.vel_y)
        if self.vel_y > 0 and dy == 0:
            dy = 1      # si cae despacito, igual baja 1 px para "sentir" el suelo
        if self.dash > 0:
            dy = 1
        self.en_suelo, _ = mover_con_choques(self.rect, dx, dy, bloques)
        if self.en_suelo:
            self.vel_y = 0
            self.saltos = 0
        elif self.saltos == 0 and self.vel_y > 1:
            self.saltos = 1     # si se cae de un borde, ya gastó un salto

        if self.atacando > 0:
            self.atacando -= 1
        if self.invulnerable > 0:
            self.invulnerable -= 1
        if self.dash_espera > 0:
            self.dash_espera -= 1

    def dibujar(self, pantalla, cam):
        # parpadea cuando es invulnerable
        if self.invulnerable > 0 and (self.invulnerable // 4) % 2 == 0:
            return
        r = self.rect.move(-cam, 0)
        # estela del dash
        if self.dash > 0:
            lado = -1 if self.mira_derecha else 1
            for i in range(1, 4):
                pygame.draw.ellipse(pantalla, DASH_COLOR, r.move(lado * i * 12, 0).inflate(-i * 6, -i * 6), 1)
        # capa roja
        capa = [(r.centerx, r.top + 8), (r.left - 4, r.bottom), (r.right + 4, r.bottom)]
        pygame.draw.polygon(pantalla, CAPA, capa)
        # cuerpo
        pygame.draw.ellipse(pantalla, PERSONAJE, (r.left, r.top + 8, r.width, r.height - 8))
        # cabeza con cuernitos
        cabeza = (r.centerx, r.top + 8)
        pygame.draw.circle(pantalla, PERSONAJE, cabeza, 11)
        lado = 1 if self.mira_derecha else -1
        pygame.draw.line(pantalla, PERSONAJE, (cabeza[0] - 6, cabeza[1] - 6), (cabeza[0] - 10, r.top - 8), 3)
        pygame.draw.line(pantalla, PERSONAJE, (cabeza[0] + 6, cabeza[1] - 6), (cabeza[0] + 10, r.top - 8), 3)
        # ojos
        pygame.draw.circle(pantalla, NEGRO, (cabeza[0] + 4 * lado, cabeza[1]), 2)
        pygame.draw.circle(pantalla, NEGRO, (cabeza[0] - 2 * lado, cabeza[1]), 2)
        # aguja
        ag = self.aguja()
        if ag:
            pygame.draw.rect(pantalla, AGUJA, ag.move(-cam, 0))


# ---------- Enemigos que patrullan ----------
class Enemigo:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x + 6, y + TILE - 28, 28, 28)
        self.dir = 1
        self.vivo = True

    def actualizar(self, bloques, objetivo=None):
        if not self.vivo:
            return
        dx = self.dir * VEL_ENEMIGO
        _, pared = mover_con_choques(self.rect, int(round(dx)), 0, bloques)
        # ¿hay suelo adelante? si no, se da vuelta (no se cae del borde)
        pie = pygame.Rect(self.rect.centerx + self.dir * 14, self.rect.bottom + 2, 4, 4)
        hay_suelo = any(pie.colliderect(b) for b in bloques)
        if pared or not hay_suelo:
            self.dir *= -1

    def dibujar(self, pantalla, cam):
        if not self.vivo:
            return
        r = self.rect.move(-cam, 0)
        pygame.draw.ellipse(pantalla, ENEMIGO, r)
        ojo_x = r.centerx + 6 * self.dir
        pygame.draw.circle(pantalla, ENEMIGO_OJO, (ojo_x, r.centery - 4), 3)
        # patitas
        for i in (-8, 0, 8):
            pygame.draw.line(pantalla, ENEMIGO, (r.centerx + i, r.bottom), (r.centerx + i, r.bottom + 5), 2)


# ---------- Volador: flota en su sitio y, si te ve, te persigue ----------
class Volador:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x + 8, y + 8, 24, 20)
        self.origen = (self.rect.centerx, self.rect.centery)
        self.vivo = True
        self.t = 0
        self.persiguiendo = False

    def actualizar(self, bloques, objetivo=None):
        if not self.vivo:
            return
        self.t += 1
        if objetivo is not None:
            dist = math.hypot(objetivo.centerx - self.rect.centerx, objetivo.centery - self.rect.centery)
            self.persiguiendo = dist < VISTA_VOLADOR
        if self.persiguiendo and objetivo is not None:
            dx = objetivo.centerx - self.rect.centerx
            dy = objetivo.centery - self.rect.centery
            d = max(1, math.hypot(dx, dy))
            self.rect.x += int(round(dx / d * VEL_VOLADOR))
            self.rect.y += int(round(dy / d * VEL_VOLADOR))
        else:
            # flota haciendo un 8 alrededor de donde nació
            self.rect.centerx = int(self.origen[0] + math.sin(self.t / 25) * 30)
            self.rect.centery = int(self.origen[1] + math.sin(self.t / 12) * 12)

    def dibujar(self, pantalla, cam):
        if not self.vivo:
            return
        r = self.rect.move(-cam, 0)
        aleteo = 6 if (self.t // 6) % 2 == 0 else -2
        pygame.draw.polygon(pantalla, VOLADOR, [(r.centerx, r.centery), (r.left - 8, r.top - aleteo), (r.left, r.bottom)])
        pygame.draw.polygon(pantalla, VOLADOR, [(r.centerx, r.centery), (r.right + 8, r.top - aleteo), (r.right, r.bottom)])
        pygame.draw.ellipse(pantalla, VOLADOR, (r.centerx - 7, r.top, 14, r.height))
        pygame.draw.circle(pantalla, CORAZON if self.persiguiendo else NEGRO, (r.centerx - 3, r.centery - 2), 2)
        pygame.draw.circle(pantalla, CORAZON if self.persiguiendo else NEGRO, (r.centerx + 3, r.centery - 2), 2)


# ---------- Jefe 2: la polilla. Vuela alto y se lanza en picada, 6 golpes ----------
class Jefe2:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x - 30, y - 160, 100, 60)
        self.techo_y = self.rect.centery        # altura donde flota
        self.origen_x = self.rect.centerx
        self.vida = JEFE2_VIDA
        self.timer = JEFE2_CADA
        self.herido = 0
        self.t = 0
        self.fase = "flotando"                  # "flotando", "picada", "subiendo"
        self.destino = None
        self.despierto = False

    @property
    def vivo(self):
        return self.vida > 0

    def golpear(self):
        if self.herido == 0:
            self.vida -= 1
            self.herido = 25
            return True
        return False

    def actualizar(self, bloques, objetivo):
        if not self.vivo:
            return
        self.t += 1
        if abs(objetivo.centerx - self.rect.centerx) < ANCHO * 0.7:
            self.despierto = True
        if self.fase == "flotando":
            # se mueve suave siguiendo tu x, allá arriba
            self.rect.centerx += int((objetivo.centerx - self.rect.centerx) * 0.03)
            self.rect.centery = int(self.techo_y + math.sin(self.t / 20) * 14)
            if self.despierto:
                self.timer -= 1
            if self.timer <= 0:
                self.fase = "picada"
                self.destino = (objetivo.centerx, objetivo.centery)
        elif self.fase == "picada":
            dx = self.destino[0] - self.rect.centerx
            dy = self.destino[1] - self.rect.centery
            d = math.hypot(dx, dy)
            if d < JEFE2_VEL:
                self.fase = "subiendo"
            else:
                self.rect.x += int(round(dx / d * JEFE2_VEL))
                self.rect.y += int(round(dy / d * JEFE2_VEL))
        elif self.fase == "subiendo":
            self.rect.y -= 3
            if self.rect.centery <= self.techo_y:
                self.fase = "flotando"
                self.timer = JEFE2_CADA
        if self.herido > 0:
            self.herido -= 1

    def dibujar(self, pantalla, cam):
        if not self.vivo:
            return
        r = self.rect.move(-cam, 0)
        color = JEFE_HERIDO if (self.herido // 3) % 2 == 1 else POLILLA
        ala = JEFE_HERIDO if (self.herido // 3) % 2 == 1 else POLILLA_ALA
        aleteo = 14 if (self.t // 5) % 2 == 0 else 0
        # alas
        pygame.draw.polygon(pantalla, ala, [(r.centerx, r.centery), (r.left - 20, r.top - aleteo), (r.left, r.bottom + 10)])
        pygame.draw.polygon(pantalla, ala, [(r.centerx, r.centery), (r.right + 20, r.top - aleteo), (r.right, r.bottom + 10)])
        # cuerpo peludo
        pygame.draw.ellipse(pantalla, color, (r.centerx - 18, r.top, 36, r.height))
        for i in range(3):
            pygame.draw.line(pantalla, ala, (r.centerx - 16, r.top + 15 + i * 14), (r.centerx + 16, r.top + 15 + i * 14), 2)
        # antenas y ojos
        pygame.draw.line(pantalla, color, (r.centerx - 6, r.top), (r.centerx - 16, r.top - 18), 2)
        pygame.draw.line(pantalla, color, (r.centerx + 6, r.top), (r.centerx + 16, r.top - 18), 2)
        for ox in (-7, 7):
            pygame.draw.circle(pantalla, CORAZON, (r.centerx + ox, r.top + 12), 5)
        # barra de vida
        ancho = 100 * self.vida / JEFE2_VIDA
        pygame.draw.rect(pantalla, NEGRO, (r.left, r.top - 34, 100, 8))
        pygame.draw.rect(pantalla, CORAZON, (r.left, r.top - 34, ancho, 8))


# ---------- El jefe: grande, salta hacia ti, 5 golpes ----------
class Jefe:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x - 20, y + TILE - 80, 80, 80)
        self.vida = JEFE_VIDA
        self.vel_y = 0
        self.vel_x = 0
        self.timer = JEFE_CADA
        self.herido = 0             # cuadros que parpadea blanco
        self.despierto = False      # empieza a atacar cuando te ve cerca

    @property
    def vivo(self):
        return self.vida > 0

    def golpear(self):
        if self.herido == 0:
            self.vida -= 1
            self.herido = 25
            return True
        return False

    def actualizar(self, bloques, objetivo):
        objetivo_x = objetivo.centerx
        if not self.vivo:
            return
        if abs(objetivo_x - self.rect.centerx) < ANCHO * 0.7:
            self.despierto = True
        if self.despierto:
            self.timer -= 1
        self.vel_y += GRAVEDAD
        self.vel_y = min(self.vel_y, 16)
        dy = int(self.vel_y)
        if self.vel_y > 0 and dy == 0:
            dy = 1      # igual que el personaje: sentir el suelo
        en_suelo, pared = mover_con_choques(self.rect, int(self.vel_x), dy, bloques)
        if en_suelo:
            self.vel_y = 0
            self.vel_x = 0
            if self.timer <= 0:
                # ¡salta hacia ti!
                self.vel_y = JEFE_SALTO
                self.vel_x = JEFE_VEL if objetivo_x > self.rect.centerx else -JEFE_VEL
                self.timer = JEFE_CADA
        if pared:
            self.vel_x = 0
        if self.herido > 0:
            self.herido -= 1

    def dibujar(self, pantalla, cam):
        if not self.vivo:
            return
        r = self.rect.move(-cam, 0)
        color = JEFE_HERIDO if (self.herido // 3) % 2 == 1 else JEFE
        pygame.draw.ellipse(pantalla, color, r)
        # cuernos
        pygame.draw.polygon(pantalla, color, [(r.left + 10, r.top + 15), (r.left + 5, r.top - 15), (r.left + 25, r.top + 8)])
        pygame.draw.polygon(pantalla, color, [(r.right - 10, r.top + 15), (r.right - 5, r.top - 15), (r.right - 25, r.top + 8)])
        # ojos enojados
        for ox in (-18, 18):
            pygame.draw.circle(pantalla, NEGRO, (r.centerx + ox, r.centery - 10), 6)
            pygame.draw.circle(pantalla, BLANCO, (r.centerx + ox + 2, r.centery - 12), 2)
        # barra de vida
        ancho = 80 * self.vida / JEFE_VIDA
        pygame.draw.rect(pantalla, NEGRO, (r.left, r.top - 30, 80, 8))
        pygame.draw.rect(pantalla, CORAZON, (r.left, r.top - 30, ancho, 8))


# ---------- Dibujos de ayuda ----------
def dibujar_corazones(pantalla, vidas):
    for i in range(VIDAS):
        color = CORAZON if i < vidas else CORAZON_VACIO
        x, y = 20 + i * 34, 20
        pygame.draw.circle(pantalla, color, (x + 6, y + 6), 7)
        pygame.draw.circle(pantalla, color, (x + 18, y + 6), 7)
        pygame.draw.polygon(pantalla, color, [(x - 1, y + 9), (x + 25, y + 9), (x + 12, y + 24)])


def dibujar_pincho(pantalla, r):
    for i in range(2):
        x = r.left + i * (TILE // 2)
        pygame.draw.polygon(pantalla, PINCHO, [(x, r.bottom), (x + TILE // 2, r.bottom), (x + TILE // 4, r.top + 8)])


def dibujar_bandera(pantalla, r, color):
    pygame.draw.rect(pantalla, color, (r.centerx - 3, r.top, 6, TILE))
    pygame.draw.polygon(pantalla, color, [(r.centerx + 3, r.top), (r.right + 10, r.top + 10), (r.centerx + 3, r.top + 20)])


def dibujar_fondo(pantalla, cam, estrellas):
    pantalla.fill(FONDO)
    # estrellas quietas (muy lejos)
    for (x, y, t) in estrellas:
        pygame.draw.rect(pantalla, ESTRELLA, (x, y, t, t))
    # montañas lejanas (se mueven lento) y cerros cercanos (más rápido)
    for i in range(-1, ANCHO // 200 + 2):
        x = i * 200 - (cam // 4) % 200
        pygame.draw.polygon(pantalla, FONDO_LEJOS, [(x, ALTO), (x + 100, ALTO - 240), (x + 200, ALTO)])
    for i in range(-1, ANCHO // 150 + 2):
        x = i * 150 - (cam // 2) % 150
        pygame.draw.polygon(pantalla, FONDO_MEDIO, [(x, ALTO), (x + 75, ALTO - 120), (x + 150, ALTO)])


def texto(pantalla, fuente, msg, y, color=BLANCO, x=None):
    cx = ANCHO // 2 if x is None else x
    s = fuente.render(msg, True, NEGRO)
    pantalla.blit(s, s.get_rect(center=(cx + 2, y + 2)))
    t = fuente.render(msg, True, color)
    pantalla.blit(t, t.get_rect(center=(cx, y)))


# ---------- Armar un nivel listo para jugar ----------
def armar_nivel(indice, vidas=VIDAS):
    n = cargar_nivel(NIVELES[indice])
    p = Personaje(*n["inicio"])
    p.vidas = vidas
    return dict(indice=indice, bloques=n["bloques"], pinchos=n["pinchos"],
                enemigos=[Enemigo(x, y) for x, y in n["enemigos"]] + [Volador(x, y) for x, y in n["voladores"]],
                checkpoints=n["checkpoints"], check_activo=None,
                jefe=Jefe(*n["jefe"]) if n["jefe"] else (Jefe2(*n["jefe2"]) if n["jefe2"] else None),
                inicio=n["inicio"], reaparecer=n["inicio"], meta=n["meta"],
                ancho=n["ancho"], alto=n["alto"], personaje=p, particulas=[])


def nuevo_juego():
    j = armar_nivel(0)
    j["estado"] = "jugando"     # "jugando", "ganaste" o "perdiste"
    j["cuadros"] = 0            # para el cronómetro
    j["nuevo_record"] = False
    return j


def siguiente_nivel(j):
    """Pasa al siguiente nivel conservando el cronómetro. Devuelve el juego nuevo."""
    nuevo = armar_nivel(j["indice"] + 1)
    nuevo["estado"] = "jugando"
    nuevo["cuadros"] = j["cuadros"]
    nuevo["nuevo_record"] = False
    return nuevo


def main():
    pygame.init()
    TECLA.update(cargar_controles())
    pantalla = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Silk — plataformas de Manu")
    reloj = pygame.time.Clock()
    fuente_grande = pygame.font.SysFont(None, 72)
    fuente_chica = pygame.font.SysFont(None, 32)
    estrellas = [(random.randint(0, ANCHO), random.randint(0, ALTO // 2), random.choice((1, 1, 2))) for _ in range(60)]

    record = leer_record()
    j = nuevo_juego()
    corriendo = True
    while corriendo:
        p = j["personaje"]

        # 1) Eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                corriendo = False
            elif e.type == pygame.KEYDOWN:
                if e.key == TECLA["salir"]:
                    corriendo = False
                elif j["estado"] == "jugando":
                    if e.key == TECLA["saltar"]:
                        p.saltar()
                    elif e.key == TECLA["atacar"]:
                        p.atacar()
                    elif e.key == TECLA["dash"]:
                        p.hacer_dash()
                elif e.key == TECLA["reiniciar"]:
                    j = nuevo_juego()
                    p = j["personaje"]

        # 2) Mover
        if j["estado"] == "jugando":
            j["cuadros"] += 1
            p.actualizar(pygame.key.get_pressed(), j["bloques"])
            for en in j["enemigos"]:
                en.actualizar(j["bloques"], p.rect)
            jefe = j["jefe"]
            if jefe:
                jefe.actualizar(j["bloques"], p.rect)

            # ataque contra enemigos y jefe
            ag = p.aguja()
            if ag:
                for en in j["enemigos"]:
                    if en.vivo and ag.colliderect(en.rect):
                        en.vivo = False
                        chispas(j["particulas"], en.rect.centerx, en.rect.centery, VOLADOR if isinstance(en, Volador) else ENEMIGO)
                if jefe and jefe.vivo and ag.colliderect(jefe.rect):
                    if jefe.golpear():
                        chispas(j["particulas"], ag.centerx, ag.centery, JEFE, 18)
                        if not jefe.vivo:
                            chispas(j["particulas"], jefe.rect.centerx, jefe.rect.centery, META, 40)

            # cosas que te hacen daño
            for en in j["enemigos"]:
                if en.vivo and p.rect.colliderect(en.rect):
                    if p.herir(en.rect.centerx):
                        chispas(j["particulas"], p.rect.centerx, p.rect.centery, CAPA)
            if jefe and jefe.vivo and p.rect.colliderect(jefe.rect):
                if p.herir(jefe.rect.centerx):
                    chispas(j["particulas"], p.rect.centerx, p.rect.centery, CAPA)
            for pin in j["pinchos"]:
                punta = pin.inflate(-12, -16).move(0, 8)
                if p.rect.colliderect(punta):
                    if p.herir(pin.centerx):
                        chispas(j["particulas"], p.rect.centerx, p.rect.centery, CAPA)

            # checkpoints: al tocar uno, ahí reapareces
            for c in j["checkpoints"]:
                if c is not j["check_activo"] and p.rect.colliderect(c):
                    j["check_activo"] = c
                    j["reaparecer"] = (c.x, c.y)
                    chispas(j["particulas"], c.centerx, c.centery, CHECK_PRENDIDO, 20)

            # caerse del mapa
            if p.rect.top > j["alto"] + 100:
                if p.invulnerable == 0:     # si venía herido por pinchos, no cobra doble
                    p.vidas -= 1
                p.reaparecer(j["reaparecer"])

            # partículas
            for part in j["particulas"]:
                part.actualizar()
            j["particulas"] = [q for q in j["particulas"] if q.vida > 0]

            # meta: si hay jefe, primero hay que vencerlo
            meta_abierta = not jefe or not jefe.vivo
            if j["meta"] and meta_abierta and p.rect.colliderect(j["meta"]):
                if j["indice"] + 1 < len(NIVELES):
                    j = siguiente_nivel(j)
                    p = j["personaje"]
                else:
                    j["estado"] = "ganaste"
                    segundos = j["cuadros"] / FPS
                    if record is None or segundos < record:
                        record = segundos
                        guardar_record(segundos)
                        j["nuevo_record"] = True
            if p.vidas <= 0:
                j["estado"] = "perdiste"

        # 3) Cámara: sigue al personaje sin salirse del nivel
        cam = p.rect.centerx - ANCHO // 2
        cam = max(0, min(cam, j["ancho"] - ANCHO))

        # 4) Dibujar
        dibujar_fondo(pantalla, cam, estrellas)
        for b in j["bloques"]:
            r = b.move(-cam, 0)
            if -TILE < r.x < ANCHO:
                pygame.draw.rect(pantalla, BLOQUE, r)
                pygame.draw.rect(pantalla, BLOQUE_BORDE, r, 2)
        for pin in j["pinchos"]:
            r = pin.move(-cam, 0)
            if -TILE < r.x < ANCHO:
                dibujar_pincho(pantalla, r)
        for c in j["checkpoints"]:
            color = CHECK_PRENDIDO if c is j["check_activo"] else CHECK_APAGADO
            dibujar_bandera(pantalla, c.move(-cam, 0), color)
        if j["meta"]:
            jefe = j["jefe"]
            color = META if (not jefe or not jefe.vivo) else META_APAGADA
            dibujar_bandera(pantalla, j["meta"].move(-cam, 0), color)
        for en in j["enemigos"]:
            en.dibujar(pantalla, cam)
        if j["jefe"]:
            j["jefe"].dibujar(pantalla, cam)
        p.dibujar(pantalla, cam)
        for part in j["particulas"]:
            part.dibujar(pantalla, cam)

        # HUD: corazones, nivel, tiempo, récord, dash listo
        dibujar_corazones(pantalla, p.vidas)
        texto(pantalla, fuente_chica, f"Nivel {j['indice'] + 1}/{len(NIVELES)}", 30, x=ANCHO // 2)
        texto(pantalla, fuente_chica, formato_tiempo(j["cuadros"] / FPS), 30, x=ANCHO - 90)
        if record is not None:
            texto(pantalla, fuente_chica, f"Récord {formato_tiempo(record)}", 58, META, x=ANCHO - 90)
        if p.dash_espera == 0:
            pygame.draw.circle(pantalla, DASH_COLOR, (135, 32), 8)
        else:
            pygame.draw.circle(pantalla, DASH_COLOR, (135, 32), 8, 2)

        if j["estado"] == "ganaste":
            texto(pantalla, fuente_grande, "¡GANASTE!", ALTO // 2 - 60, META)
            texto(pantalla, fuente_chica, f"Tiempo: {formato_tiempo(j['cuadros'] / FPS)}", ALTO // 2)
            if j["nuevo_record"]:
                texto(pantalla, fuente_chica, "¡NUEVO RÉCORD!", ALTO // 2 + 32, CHECK_PRENDIDO)
            texto(pantalla, fuente_chica, f"{pygame.key.name(TECLA['reiniciar']).upper()} para jugar de nuevo", ALTO // 2 + 70)
        elif j["estado"] == "perdiste":
            texto(pantalla, fuente_grande, "PERDISTE", ALTO // 2 - 40, CORAZON)
            texto(pantalla, fuente_chica, f"{pygame.key.name(TECLA['reiniciar']).upper()} para intentar de nuevo", ALTO // 2 + 20)

        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
