# Escape de la Fábrica

Un juego de escape hecho en Python con pygame. Estás encerrado en una fábrica
oscura: solo ves lo que alumbra tu **linterna**. Junta las **3 llaves** de cada
nivel, abre las **puertas de colores**, llega a la **puerta de salida** y escapa
de los **3 niveles** antes de que el **monstruo** te atrape.

## Cómo instalarlo en tu computador

1. Necesitas **Python 3** (en https://python.org si no lo tienes).
2. Instala pygame:

       pip install pygame

   (en Linux o Mac a veces es `pip3 install pygame` o `python3 -m pip install pygame`).

## Cómo jugar

    python3 escape.py

En Windows: `python escape.py`. En Linux/Mac también sirve `./jugar.sh`.

- Al empezar eliges la **dificultad** (arriba/abajo o 1-2-3, ESPACIO para empezar).
- **Flechas** para moverte · **F** prende/apaga la linterna · **ESPACIO** sigue al siguiente nivel · **R** reinicia · **ESC** cierra.
- La **linterna** gasta batería (la barra de arriba a la derecha). Las **pilas** verdes la recargan. Con la linterna prendida ves lejos... pero el monstruo también te ve más lejos.
- El **monstruo** patrulla. Si te ve, te persigue (sus ojos se ponen rojos). Cuando está cerca, la pantalla tiembla y suena un zumbido. ¡Escóndete detrás de una pared!
- Las **puertas de color** (roja, verde, azul) se abren con la llave de su color.
- En el nivel 3 aparece el **espectro**: es más rápido que tú y siempre sabe dónde estás, pero **se queda quieto mientras lo alumbras**. Si le das la espalda o se te acaba la batería... corre.
- Con las 3 llaves amarillas la puerta de salida se pone verde: entra y pasas de nivel.

## Haz tu propio laberinto

Los niveles están en `laberinto1.txt`, `laberinto2.txt` y `laberinto3.txt`. Son dibujos con letras:

    #  pared            .  piso
    P  tú               M  monstruo
    E  espectro         (se congela cuando lo alumbras)
    K  llave de salida  D  puerta de salida (se abre con TODAS las K)
    B  pila             (recarga la linterna)
    r  v  a             llave roja / verde / azul
    R  V  A             puerta roja / verde / azul

Edita uno (o copia el archivo con otro nombre) y córrelo así:

    python3 escape.py mi_laberinto.txt

Puedes pasar varios y se juegan en orden: `python3 escape.py uno.txt dos.txt`.
Tiene que haber **una P** y **una D**. El monstruo, el espectro, las pilas y las
puertas de color son opcionales.

## Cambiar los controles

Abre `controles.txt` y cambia la tecla después del `=`. Por ejemplo, para WASD:

```
izquierda = a
derecha   = d
arriba    = w
abajo     = s
linterna  = e
```

Nombres válidos: letras (`a`, `b`...), flechas (`up`, `down`, `left`, `right`),
`space`, `return`, `tab`, `left shift`, `left ctrl`, números (`1`, `2`...).
Si escribes una tecla que no existe, el juego te avisa en la terminal y usa la de siempre.

## Para cambiar cosas

Arriba de `escape.py` están los ajustes: `VEL_JUGADOR`, `RADIO_LINTERNA`,
`ANGULO_LINTERNA`, `RADIO_MIEDO`... y la tabla `DIFICULTADES` con la visión y
velocidad del monstruo, cuánto dura la batería y la velocidad del espectro.
Cambia un número, guarda, y vuelve a correrlo.

## Nota para el computador de Manu

Ahí no hay `pip` en el sistema, así que pygame vive en una "cajita" `.venv`
dentro de esta carpeta y `./jugar.sh` la usa sola.
