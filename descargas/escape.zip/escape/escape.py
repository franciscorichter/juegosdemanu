"""
ESCAPE DE LA FABRICA - un juego de Manu
========================================
Estas encerrado en una fabrica oscura. Solo ves lo que alumbra tu linterna.
Junta las llaves, abre las puertas y escapa de los 3 niveles... antes de que
el monstruo te atrape.

Controles (se cambian en controles.txt):
    flechas   moverte          F        prender / apagar la linterna
    ESPACIO   seguir           R        reiniciar        ESC  salir

Los laberintos estan en laberinto1.txt, laberinto2.txt y laberinto3.txt:
    #  pared            .  piso
    P  tu               M  monstruo (patrulla, y te caza si te ve)
    E  espectro         (nivel 3: es mas rapido, pero se queda quieto si lo alumbras)
    K  llave de salida  D  puerta de salida (se abre con TODAS las K)
    B  pila             (recarga la linterna)
    r  v  a             llave roja / verde / azul
    R  V  A             puerta roja / verde / azul (se abre con la llave de su color)

Tu propio laberinto:  python escape.py mi_laberinto.txt
"""

import math
import os
import random
import sys
from array import array
from collections import deque

import pygame

# ------------------------------------------------------------------ AJUSTES
# Cambia estos numeros, guarda, y vuelve a correr el juego.
TILE = 32                 # tamano de cada casilla en pixeles
VEL_JUGADOR = 3.2         # que tan rapido corres
VEL_PATRULLA = 1.5        # monstruo caminando tranquilo
RADIO_LINTERNA = 210      # hasta donde alumbra la linterna
ANGULO_LINTERNA = 70      # que tan ancho es el cono de luz (grados)
RADIO_AMBIENTE = 55       # lo poquito que ves sin linterna
RADIO_MIEDO = 220         # a esta distancia empieza a temblar la pantalla
FPS = 60
NIVELES = ["laberinto1.txt", "laberinto2.txt", "laberinto3.txt"]

# Cada dificultad cambia estos numeros:
#   vision = casillas a las que te ve el monstruo (con linterna prendida ve 2 mas)
#   caza = velocidad del monstruo cuando te persigue (tu vas a 3.2)
#   bateria = segundos que dura la linterna prendida
#   espectro = velocidad del espectro cuando no lo miras
DIFICULTADES = {
    "Facil":   {"vision": 5, "caza": 2.4, "bateria": 60, "espectro": 3.0},
    "Normal":  {"vision": 7, "caza": 2.9, "bateria": 40, "espectro": 3.6},
    "Dificil": {"vision": 9, "caza": 3.3, "bateria": 25, "espectro": 4.2},
}

# Colores (rojo, verde, azul)
COLOR_PISO = (46, 42, 50)
COLOR_PARED = (95, 85, 100)
COLOR_JUGADOR = (255, 220, 90)
COLOR_MONSTRUO = (120, 20, 40)
COLOR_OJOS = (255, 40, 40)
COLOR_ESPECTRO = (200, 210, 230)
COLOR_LLAVE = (255, 200, 40)
COLOR_PILA = (90, 220, 120)
COLOR_PUERTA_CERRADA = (110, 70, 40)
COLOR_PUERTA_ABIERTA = (60, 200, 90)
COLORES = {"r": (220, 50, 50), "v": (50, 190, 80), "a": (70, 120, 240)}
NOMBRES_COLOR = {"r": "roja", "v": "verde", "a": "azul"}


# ------------------------------------------------------------------ CONTROLES
# Se leen de controles.txt. Si el archivo no esta, se usan estas.
CONTROLES_DEFECTO = {
    "izquierda": "left", "derecha": "right", "arriba": "up", "abajo": "down",
    "linterna": "f", "continuar": "space", "reiniciar": "r", "salir": "escape",
}


def cargar_controles():
    """Lee controles.txt (al lado de este archivo). Si falta una linea o una
    tecla no existe, usa la de siempre."""
    nombres = dict(CONTROLES_DEFECTO)
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "controles.txt")
    try:
        with open(ruta, encoding="utf-8") as f:
            for linea in f:
                linea = linea.strip()
                if not linea or linea.startswith("#") or "=" not in linea:
                    continue
                accion, tecla = [x.strip().lower() for x in linea.split("=", 1)]
                if accion in nombres and tecla:
                    nombres[accion] = tecla
    except OSError:
        pass
    teclas = {}
    for accion, nombre in nombres.items():
        try:
            teclas[accion] = pygame.key.key_code(nombre)
        except ValueError:
            print(f"controles.txt: la tecla '{nombre}' para '{accion}' no existe, uso '{CONTROLES_DEFECTO[accion]}'")
            teclas[accion] = pygame.key.key_code(CONTROLES_DEFECTO[accion])
    return teclas


TECLA = {}   # se llena en main(), despues de pygame.init()


# ------------------------------------------------------------------ LABERINTO
def cargar_laberinto(ruta):
    """Lee el archivo de texto y lo convierte en una lista de filas."""
    with open(ruta, encoding="utf-8") as f:
        filas = [linea.rstrip("\n") for linea in f if linea.strip()]
    ancho = max(len(fila) for fila in filas)
    # Si una fila es mas corta, la rellenamos con pared
    return [fila.ljust(ancho, "#") for fila in filas]


class Mapa:
    """Sabe donde hay paredes y busca caminos (para que el monstruo no se pierda)."""

    def __init__(self, filas):
        self.filas = filas
        self.alto = len(filas)
        self.ancho = len(filas[0])
        self.puerta_abierta = False
        self.colores_abiertos = set()   # letras de las puertas de color ya abiertas

    def celda(self, cx, cy):
        if 0 <= cy < self.alto and 0 <= cx < self.ancho:
            return self.filas[cy][cx]
        return "#"

    def es_pared(self, cx, cy):
        c = self.celda(cx, cy)
        if c == "#":
            return True
        if c == "D":
            return not self.puerta_abierta
        if c in "RVA":                       # puerta de color
            return c.lower() not in self.colores_abiertos
        return False

    def choca(self, rect):
        """Devuelve True si el rectangulo toca alguna pared."""
        cx1, cy1 = rect.left // TILE, rect.top // TILE
        cx2, cy2 = (rect.right - 1) // TILE, (rect.bottom - 1) // TILE
        for cy in range(cy1, cy2 + 1):
            for cx in range(cx1, cx2 + 1):
                if self.es_pared(cx, cy):
                    return True
        return False

    def vecinos(self, celda):
        cx, cy = celda
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if not self.es_pared(cx + dx, cy + dy):
                yield (cx + dx, cy + dy)

    def camino(self, desde, hasta):
        """Busca el camino mas corto entre dos casillas (algoritmo BFS).
        Es como una inundacion: el agua sale de 'desde' y se expande hasta llegar a 'hasta'."""
        if desde == hasta:
            return []
        anterior = {desde: None}
        cola = deque([desde])
        while cola:
            actual = cola.popleft()
            if actual == hasta:
                break
            for v in self.vecinos(actual):
                if v not in anterior:
                    anterior[v] = actual
                    cola.append(v)
        if hasta not in anterior:
            return []
        # Volvemos hacia atras desde la meta para armar el camino
        ruta = []
        paso = hasta
        while paso != desde:
            ruta.append(paso)
            paso = anterior[paso]
        ruta.reverse()
        return ruta

    def hay_vision(self, a, b):
        """True si desde la casilla a se ve la casilla b sin paredes en medio."""
        (x0, y0), (x1, y1) = a, b
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while (x0, y0) != (x1, y1):
            if self.es_pared(x0, y0):
                return False
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy
        return True

    def casillas_de_piso(self):
        return [(cx, cy) for cy in range(self.alto) for cx in range(self.ancho)
                if not self.es_pared(cx, cy)]


def a_casilla(x, y):
    """Convierte pixeles a casilla del laberinto."""
    return (int(x // TILE), int(y // TILE))


def centro_de(celda):
    """Convierte casilla a pixeles (el centro de la casilla)."""
    return (celda[0] * TILE + TILE / 2, celda[1] * TILE + TILE / 2)


# ------------------------------------------------------------------ JUGADOR
class Jugador:
    RADIO = 11

    def __init__(self, celda, bateria_segundos):
        self.x, self.y = centro_de(celda)
        self.mira = (1, 0)               # hacia donde mira (la ultima direccion en que camino)
        self.linterna = True             # prendida o apagada
        self.bateria = 100.0             # de 0 a 100
        self.gasto = 100.0 / (bateria_segundos * FPS)   # cuanto gasta cada frame

    @property
    def rect(self):
        r = self.RADIO
        return pygame.Rect(int(self.x - r), int(self.y - r), r * 2, r * 2)

    @property
    def alumbra(self):
        """True si la linterna esta prendida y tiene bateria."""
        return self.linterna and self.bateria > 0

    def mover(self, dx, dy, mapa):
        if dx or dy:
            self.mira = (int(math.copysign(1, dx)) if dx else 0, int(math.copysign(1, dy)) if dy else 0)
        # Movemos primero en X y luego en Y, asi puedes deslizarte por las paredes
        if dx:
            self.x += dx
            if mapa.choca(self.rect):
                self.x -= dx
        if dy:
            self.y += dy
            if mapa.choca(self.rect):
                self.y -= dy

    def gastar_bateria(self):
        if self.alumbra:
            self.bateria = max(0.0, self.bateria - self.gasto)

    def esta_alumbrando(self, x, y, mapa):
        """True si el punto (x, y) esta dentro del cono de la linterna."""
        if not self.alumbra:
            return False
        dx, dy = x - self.x, y - self.y
        dist = math.hypot(dx, dy)
        if dist > RADIO_LINTERNA:
            return False
        if dist > 1:
            ang_mira = math.atan2(self.mira[1], self.mira[0])
            ang_punto = math.atan2(dy, dx)
            dif = abs((ang_punto - ang_mira + math.pi) % (2 * math.pi) - math.pi)
            if math.degrees(dif) > ANGULO_LINTERNA / 2:
                return False
        return mapa.hay_vision(a_casilla(self.x, self.y), a_casilla(x, y))

    def dibujar(self, sup):
        pygame.draw.circle(sup, COLOR_JUGADOR, (int(self.x), int(self.y)), self.RADIO)
        pygame.draw.circle(sup, (60, 40, 10), (int(self.x), int(self.y)), self.RADIO, 2)
        # la linterna: un puntito hacia donde miras
        px = int(self.x + self.mira[0] * 8)
        py = int(self.y + self.mira[1] * 8)
        pygame.draw.circle(sup, (255, 255, 200) if self.alumbra else (90, 90, 80), (px, py), 4)


# ------------------------------------------------------------------ MONSTRUO
class Monstruo:
    RADIO = 24  # es grande: mas que una casilla

    def __init__(self, celda, mapa, vision, vel_caza):
        self.x, self.y = centro_de(celda)
        self.mapa = mapa
        self.vision = vision
        self.vel_caza = vel_caza
        self.estado = "patrulla"      # "patrulla", "caza" o "busca"
        self.ruta = []                # lista de casillas por donde va a caminar
        self.ultimo_visto = None      # donde vio al jugador por ultima vez
        self.contador = 0
        self.paso_anim = 0.0

    @property
    def celda(self):
        return a_casilla(self.x, self.y)

    def elegir_paseo(self):
        """Elige un lugar al azar del laberinto y camina hacia alla."""
        opciones = [c for c in self.mapa.casillas_de_piso()
                    if abs(c[0] - self.celda[0]) + abs(c[1] - self.celda[1]) > 4]
        for _ in range(10):
            destino = random.choice(opciones)
            self.ruta = self.mapa.camino(self.celda, destino)
            if self.ruta:
                return

    def ve_al_jugador(self, jugador):
        mia, suya = self.celda, a_casilla(jugador.x, jugador.y)
        dist = math.hypot(mia[0] - suya[0], mia[1] - suya[1])
        alcance = self.vision + (2 if jugador.alumbra else 0)   # la luz te delata
        return dist <= alcance and self.mapa.hay_vision(mia, suya)

    def actualizar(self, jugador):
        self.contador += 1
        celda_jugador = a_casilla(jugador.x, jugador.y)

        if self.ve_al_jugador(jugador):
            self.estado = "caza"
            self.ultimo_visto = celda_jugador
            # Cada 10 frames recalcula el camino hacia ti (tu te mueves!)
            if self.contador % 10 == 0 or not self.ruta:
                self.ruta = self.mapa.camino(self.celda, celda_jugador)
        elif self.estado == "caza":
            # Te perdio de vista: va a mirar al ultimo lugar donde te vio
            self.estado = "busca"
            self.ruta = self.mapa.camino(self.celda, self.ultimo_visto)

        if not self.ruta:
            if self.estado == "busca":
                self.estado = "patrulla"
            self.elegir_paseo()

        vel = self.vel_caza if self.estado == "caza" else VEL_PATRULLA
        self.avanzar(vel)
        self.paso_anim += vel * 0.15

    def avanzar(self, vel):
        """Camina hacia la siguiente casilla de su ruta."""
        if not self.ruta:
            return
        ox, oy = centro_de(self.ruta[0])
        dx, dy = ox - self.x, oy - self.y
        dist = math.hypot(dx, dy)
        if dist <= vel:
            self.x, self.y = ox, oy
            self.ruta.pop(0)
        else:
            self.x += dx / dist * vel
            self.y += dy / dist * vel

    def dibujar(self, sup):
        x, y = int(self.x), int(self.y)
        r = self.RADIO
        balanceo = int(math.sin(self.paso_anim) * 4)
        # brazos largos
        pygame.draw.line(sup, COLOR_MONSTRUO, (x - r, y), (x - r - 18, y + 14 + balanceo), 7)
        pygame.draw.line(sup, COLOR_MONSTRUO, (x + r, y), (x + r + 18, y + 14 - balanceo), 7)
        # cuerpo
        pygame.draw.circle(sup, COLOR_MONSTRUO, (x, y), r)
        pygame.draw.circle(sup, (70, 10, 25), (x, y), r, 3)
        # ojos (mas brillantes cuando caza)
        color_ojos = COLOR_OJOS if self.estado == "caza" else (200, 120, 60)
        pygame.draw.circle(sup, color_ojos, (x - 8, y - 6), 5)
        pygame.draw.circle(sup, color_ojos, (x + 8, y - 6), 5)
        # dientes
        for i in range(-2, 3):
            pygame.draw.polygon(sup, (240, 240, 230),
                                [(x + i * 6 - 2, y + 8), (x + i * 6 + 2, y + 8), (x + i * 6, y + 15)])


class Espectro:
    """Siempre sabe donde estas y va directo hacia ti... pero si lo alumbras
    con la linterna se queda congelado. No lo pierdas de vista."""
    RADIO = 18

    def __init__(self, celda, mapa, velocidad):
        self.x, self.y = centro_de(celda)
        self.mapa = mapa
        self.velocidad = velocidad
        self.ruta = []
        self.contador = 0
        self.congelado = False
        self.flotar = 0.0

    @property
    def celda(self):
        return a_casilla(self.x, self.y)

    def actualizar(self, jugador):
        self.contador += 1
        self.flotar += 0.08
        self.congelado = jugador.esta_alumbrando(self.x, self.y, self.mapa)
        if self.congelado:
            return
        if self.contador % 15 == 0 or not self.ruta:
            self.ruta = self.mapa.camino(self.celda, a_casilla(jugador.x, jugador.y))
        Monstruo.avanzar(self, self.velocidad)

    def dibujar(self, sup):
        x, y = int(self.x), int(self.y + math.sin(self.flotar) * 3)
        r = self.RADIO
        color = (150, 160, 180) if self.congelado else COLOR_ESPECTRO
        # cuerpo de fantasma: circulo arriba y "flecos" abajo
        pygame.draw.circle(sup, color, (x, y - 4), r)
        pygame.draw.rect(sup, color, (x - r, y - 4, r * 2, r))
        for i in range(-2, 3):
            pygame.draw.circle(sup, color, (x + i * 8, y + r - 4), 5)
        # ojos negros y boca
        pygame.draw.circle(sup, (20, 20, 40), (x - 7, y - 8), 4)
        pygame.draw.circle(sup, (20, 20, 40), (x + 7, y - 8), 4)
        if not self.congelado:
            pygame.draw.ellipse(sup, (20, 20, 40), (x - 6, y, 12, 8))


# ------------------------------------------------------------------ SONIDO
def crear_zumbido():
    """Fabrica un sonido grave que 'late' (sin archivos: puros numeros).
    Si el computador no tiene audio, devuelve None y el juego sigue igual."""
    try:
        pygame.mixer.init(frequency=22050, size=-16, channels=1)
        muestras = array("h")
        n = 22050  # un segundo
        for i in range(n):
            t = i / 22050
            latido = 0.5 + 0.5 * math.sin(2 * math.pi * 2 * t)     # late 2 veces por segundo
            onda = math.sin(2 * math.pi * 55 * t)                    # nota muy grave
            muestras.append(int(onda * latido * 12000))
        return pygame.mixer.Sound(buffer=muestras.tobytes())
    except Exception:
        return None


# ------------------------------------------------------------------ LUCES
def crear_circulo_luz(radio, alpha_max=235):
    """Un circulo que va de transparente (centro) a oscuro (borde)."""
    d = radio * 2
    luz = pygame.Surface((d, d), pygame.SRCALPHA)
    luz.fill((0, 0, 0, 255))
    for r in range(radio, 0, -1):
        alpha = int(alpha_max * (r / radio) ** 1.5)
        pygame.draw.circle(luz, (0, 0, 0, alpha), (radio, radio), r)
    return luz


def crear_conos_luz():
    """Un cono de linterna para cada una de las 8 direcciones en que puedes mirar."""
    base = crear_circulo_luz(RADIO_LINTERNA)
    conos = {}
    for mx in (-1, 0, 1):
        for my in (-1, 0, 1):
            if (mx, my) == (0, 0):
                continue
            ang = math.atan2(my, mx)
            mitad = math.radians(ANGULO_LINTERNA / 2)
            largo = RADIO_LINTERNA * 1.5
            c = (RADIO_LINTERNA, RADIO_LINTERNA)
            puntos = [c]
            for i in range(-6, 7):        # el borde redondo del cono
                a = ang + mitad * i / 6
                puntos.append((c[0] + math.cos(a) * largo, c[1] + math.sin(a) * largo))
            # mascara: todo oscuro (255) menos el cono (0). Con BLEND_RGBA_MAX,
            # fuera del cono la luz queda tapada y adentro se mantiene
            mascara = pygame.Surface(base.get_size(), pygame.SRCALPHA)
            mascara.fill((0, 0, 0, 255))
            pygame.draw.polygon(mascara, (0, 0, 0, 0), puntos)
            cono = base.copy()
            cono.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MAX)
            conos[(mx, my)] = cono
    return conos


# ------------------------------------------------------------------ JUEGO
class Juego:
    def __init__(self, niveles):
        self.niveles = niveles
        self.fuente = pygame.font.SysFont(None, 28)
        self.fuente_grande = pygame.font.SysFont(None, 72)
        self.fuente_media = pygame.font.SysFont(None, 40)
        self.zumbido = crear_zumbido()
        self.canal = None
        self.luz_ambiente = crear_circulo_luz(RADIO_AMBIENTE, 200)
        self.conos = crear_conos_luz()
        self.dificultad = "Normal"
        self.opcion_menu = 1
        self.tiempo_total = 0
        self.nivel = 0
        self.cargar_nivel()
        self.estado = "menu"       # "menu", "jugando", "atrapado", "nivel_completo", "escapaste"

    @property
    def ajustes(self):
        return DIFICULTADES[self.dificultad]

    def cargar_nivel(self):
        filas = cargar_laberinto(self.niveles[self.nivel])
        self.mapa = Mapa(filas)
        self.objetos = {}          # casilla -> letra (K, B, r, v, a)
        self.puerta = None
        self.espectro = None
        self.monstruo = None
        for cy, fila in enumerate(filas):
            for cx, c in enumerate(fila):
                if c == "P":
                    self.jugador = Jugador((cx, cy), self.ajustes["bateria"])
                elif c == "M":
                    self.monstruo = Monstruo((cx, cy), self.mapa, self.ajustes["vision"], self.ajustes["caza"])
                elif c == "E":
                    self.espectro = Espectro((cx, cy), self.mapa, self.ajustes["espectro"])
                elif c == "D":
                    self.puerta = (cx, cy)
                elif c in "KBrva":
                    self.objetos[(cx, cy)] = c
        self.total_llaves = sum(1 for c in self.objetos.values() if c == "K")
        self.llaves_tomadas = 0
        self.llaves_color = []
        self.estado = "jugando"
        self.tiempo = 0
        self.temblor = 0
        self.aviso = ""
        self.aviso_hasta = 0
        self.mundo = pygame.Surface((self.mapa.ancho * TILE, self.mapa.alto * TILE))
        self.oscuridad = pygame.Surface(self.mundo.get_size(), pygame.SRCALPHA)

    def reiniciar(self):
        """Tecla R: vuelve a empezar el nivel (o el juego si ya escapaste)."""
        self.apagar_sonido()
        if self.estado == "escapaste":
            self.nivel = 0
            self.tiempo_total = 0
            self.cargar_nivel()
            self.estado = "menu"
        else:
            self.cargar_nivel()

    def continuar(self):
        """Tecla ESPACIO: elige en el menu, o pasa al siguiente nivel."""
        if self.estado == "menu":
            self.dificultad = list(DIFICULTADES)[self.opcion_menu]
            self.nivel = 0
            self.tiempo_total = 0
            self.cargar_nivel()
        elif self.estado == "nivel_completo":
            self.nivel += 1
            self.cargar_nivel()

    def tecla(self, key):
        """Teclas que se aprietan una vez (no las de moverse)."""
        if key == TECLA["reiniciar"]:
            self.reiniciar()
        elif key == TECLA["continuar"]:
            self.continuar()
        elif self.estado == "menu":
            if key == TECLA["arriba"]:
                self.opcion_menu = (self.opcion_menu - 1) % len(DIFICULTADES)
            elif key == TECLA["abajo"]:
                self.opcion_menu = (self.opcion_menu + 1) % len(DIFICULTADES)
            elif key in (pygame.K_1, pygame.K_2, pygame.K_3):
                self.opcion_menu = key - pygame.K_1
                self.continuar()
        elif self.estado == "jugando" and key == TECLA["linterna"]:
            self.jugador.linterna = not self.jugador.linterna

    def avisar(self, texto):
        self.aviso = texto
        self.aviso_hasta = self.tiempo + FPS * 3

    # ---- logica
    def actualizar(self, teclas):
        if self.estado != "jugando":
            return
        self.tiempo += 1
        dx = dy = 0
        if teclas[TECLA["izquierda"]]:
            dx -= VEL_JUGADOR
        if teclas[TECLA["derecha"]]:
            dx += VEL_JUGADOR
        if teclas[TECLA["arriba"]]:
            dy -= VEL_JUGADOR
        if teclas[TECLA["abajo"]]:
            dy += VEL_JUGADOR
        self.jugador.mover(dx, dy, self.mapa)
        self.jugador.gastar_bateria()

        # ¿Pise algo?
        mi_celda = a_casilla(self.jugador.x, self.jugador.y)
        objeto = self.objetos.pop(mi_celda, None)
        if objeto == "K":
            self.llaves_tomadas += 1
            if self.llaves_tomadas == self.total_llaves:
                self.mapa.puerta_abierta = True
                self.avisar("¡La puerta de salida se abrio!")
            else:
                self.avisar(f"Llave {self.llaves_tomadas} de {self.total_llaves}")
        elif objeto == "B":
            self.jugador.bateria = 100.0
            self.avisar("Pila: linterna recargada")
        elif objeto in ("r", "v", "a"):
            self.llaves_color.append(objeto)
            self.mapa.colores_abiertos.add(objeto)
            self.avisar(f"Llave {NOMBRES_COLOR[objeto]}: se abrio la puerta {NOMBRES_COLOR[objeto]}")

        # ¿Llegue a la puerta abierta?
        if self.mapa.puerta_abierta and mi_celda == self.puerta:
            self.tiempo_total += self.tiempo
            self.estado = "escapaste" if self.nivel == len(self.niveles) - 1 else "nivel_completo"
            self.apagar_sonido()
            return

        # Los monstruos
        dist = 9999
        if self.monstruo:
            self.monstruo.actualizar(self.jugador)
            dist = self.distancia(self.monstruo)
            if dist < self.monstruo.RADIO + self.jugador.RADIO - 6:
                self.atrapado()
                return
        if self.espectro:
            self.espectro.actualizar(self.jugador)
            d2 = self.distancia(self.espectro)
            dist = min(dist, d2)
            if d2 < self.espectro.RADIO + self.jugador.RADIO - 4:
                self.atrapado()
                return

        # Miedo: mientras mas cerca, mas tiembla y mas fuerte suena
        miedo = max(0.0, 1 - dist / RADIO_MIEDO)
        self.temblor = miedo * 9
        self.sonar(miedo)

    def distancia(self, bicho):
        return math.hypot(bicho.x - self.jugador.x, bicho.y - self.jugador.y)

    def atrapado(self):
        self.estado = "atrapado"
        self.apagar_sonido()

    def sonar(self, volumen):
        if self.zumbido is None:
            return
        if volumen <= 0:
            self.apagar_sonido()
            return
        if self.canal is None:
            self.canal = self.zumbido.play(loops=-1)
        if self.canal is not None:
            self.canal.set_volume(volumen)

    def apagar_sonido(self):
        if self.canal is not None:
            self.canal.stop()
            self.canal = None

    # ---- dibujo
    def dibujar_mapa(self):
        m = self.mapa
        for cy in range(m.alto):
            for cx in range(m.ancho):
                r = pygame.Rect(cx * TILE, cy * TILE, TILE, TILE)
                c = m.celda(cx, cy)
                if c == "#":
                    pygame.draw.rect(self.mundo, COLOR_PARED, r)
                    pygame.draw.rect(self.mundo, (60, 52, 66), r, 2)
                else:
                    pygame.draw.rect(self.mundo, COLOR_PISO, r)
                    # rejilla sutil del piso de fabrica
                    pygame.draw.line(self.mundo, (52, 48, 58), r.topleft, r.topright)
                if c in "RVA":
                    self.dibujar_puerta_color(r, c.lower())
        # puerta de salida
        if self.puerta:
            r = pygame.Rect(self.puerta[0] * TILE, self.puerta[1] * TILE, TILE, TILE)
            color = COLOR_PUERTA_ABIERTA if m.puerta_abierta else COLOR_PUERTA_CERRADA
            pygame.draw.rect(self.mundo, color, r)
            pygame.draw.rect(self.mundo, (30, 20, 10), r, 3)
            if not m.puerta_abierta:
                pygame.draw.circle(self.mundo, (240, 220, 80), r.center, 5)
        # objetos
        for (cx, cy), c in self.objetos.items():
            x, y = cx * TILE + TILE // 2, cy * TILE + TILE // 2
            if c == "B":
                pygame.draw.rect(self.mundo, COLOR_PILA, (x - 6, y - 10, 12, 20))
                pygame.draw.rect(self.mundo, (30, 80, 40), (x - 6, y - 10, 12, 20), 2)
                pygame.draw.rect(self.mundo, (30, 80, 40), (x - 3, y - 13, 6, 3))
            else:
                self.dibujar_llave(self.mundo, x, y, COLOR_LLAVE if c == "K" else COLORES[c])

    def dibujar_llave(self, sup, x, y, color):
        pygame.draw.circle(sup, color, (x - 5, y), 6, 3)
        pygame.draw.line(sup, color, (x, y), (x + 10, y), 3)
        pygame.draw.line(sup, color, (x + 7, y), (x + 7, y + 5), 3)

    def dibujar_puerta_color(self, r, c):
        color = COLORES[c]
        if c in self.mapa.colores_abiertos:
            # abierta: solo el marco
            pygame.draw.rect(self.mundo, color, r, 3)
        else:
            pygame.draw.rect(self.mundo, color, r)
            pygame.draw.rect(self.mundo, (30, 30, 30), r, 3)
            pygame.draw.circle(self.mundo, (240, 240, 240), r.center, 5)

    def dibujar_oscuridad(self):
        self.oscuridad.fill((0, 0, 0, 235))
        j = self.jugador
        # BLEND_RGBA_MIN: donde la luz es transparente, la oscuridad tambien
        pos = (int(j.x - RADIO_AMBIENTE), int(j.y - RADIO_AMBIENTE))
        self.oscuridad.blit(self.luz_ambiente, pos, special_flags=pygame.BLEND_RGBA_MIN)
        if j.alumbra:
            pos = (int(j.x - RADIO_LINTERNA), int(j.y - RADIO_LINTERNA))
            self.oscuridad.blit(self.conos[j.mira], pos, special_flags=pygame.BLEND_RGBA_MIN)
        # Los ojos brillan en la oscuridad aunque esten lejos
        if self.monstruo and self.monstruo.estado == "caza":
            for ox in (-8, 8):
                pygame.draw.circle(self.oscuridad, (255, 40, 40, 255),
                                   (int(self.monstruo.x + ox), int(self.monstruo.y - 6)), 5)
        if self.espectro:
            for ox in (-7, 7):
                pygame.draw.circle(self.oscuridad, (120, 140, 200, 255),
                                   (int(self.espectro.x + ox), int(self.espectro.y - 8)), 3)
        self.mundo.blit(self.oscuridad, (0, 0))

    def dibujar(self, pantalla):
        if self.estado == "menu":
            self.dibujar_menu(pantalla)
            return
        self.dibujar_mapa()
        if self.monstruo:
            self.monstruo.dibujar(self.mundo)
        if self.espectro:
            self.espectro.dibujar(self.mundo)
        self.jugador.dibujar(self.mundo)
        self.dibujar_oscuridad()

        # temblor: movemos el mundo un poquito al azar
        sx = sy = 0
        if self.estado == "jugando" and self.temblor > 0:
            sx = random.uniform(-self.temblor, self.temblor)
            sy = random.uniform(-self.temblor, self.temblor)
        pantalla.fill((0, 0, 0))
        pantalla.blit(self.mundo, (sx, sy))
        self.dibujar_hud(pantalla)

        if self.estado == "atrapado":
            self.pantalla_final(pantalla, "TE ATRAPO", (255, 60, 60),
                                "R para volver a intentar  -  ESC para salir")
        elif self.estado == "nivel_completo":
            self.pantalla_final(pantalla, "¡ESCAPASTE!", (80, 255, 120),
                                f"Nivel {self.nivel + 1} listo. ESPACIO para el nivel {self.nivel + 2}")
        elif self.estado == "escapaste":
            self.pantalla_final(pantalla, "¡ESCAPASTE DE LA FABRICA!", (80, 255, 120),
                                f"Tiempo total: {self.tiempo_total // FPS} s  -  R para jugar de nuevo")

    def dibujar_hud(self, pantalla):
        seg = self.tiempo // FPS
        texto = f"Nivel {self.nivel + 1}/{len(self.niveles)}   Llaves: {self.llaves_tomadas}/{self.total_llaves}   Tiempo: {seg} s"
        self.texto(pantalla, texto, self.fuente, (255, 255, 255), (10, 8))
        # llaves de color que tienes
        x = 10 + self.fuente.size(texto)[0] + 20
        for c in self.llaves_color:
            self.dibujar_llave(pantalla, x, 18, COLORES[c])
            x += 26
        # bateria de la linterna
        ancho = pantalla.get_width()
        j = self.jugador
        pygame.draw.rect(pantalla, (200, 200, 200), (ancho - 120, 10, 100, 16), 2)
        color = COLOR_PILA if j.bateria > 30 else (240, 80, 60)
        pygame.draw.rect(pantalla, color, (ancho - 118, 12, int(96 * j.bateria / 100), 12))
        estado = "ON" if j.alumbra else ("VACIA" if j.bateria <= 0 else "OFF")
        self.texto(pantalla, estado, self.fuente, (255, 255, 255), (ancho - 175, 8))
        # aviso
        if self.aviso and self.tiempo < self.aviso_hasta:
            self.texto(pantalla, self.aviso, self.fuente, (255, 240, 150),
                       (ancho // 2, pantalla.get_height() - 22), centrado=True)

    def dibujar_menu(self, pantalla):
        pantalla.fill((12, 10, 14))
        cx, cy = pantalla.get_width() // 2, pantalla.get_height() // 2
        self.texto(pantalla, "ESCAPE DE LA FABRICA", self.fuente_grande, (255, 220, 90), (cx, cy - 130), centrado=True)
        self.texto(pantalla, "Elige la dificultad:", self.fuente, (220, 220, 220), (cx, cy - 60), centrado=True)
        for i, (nombre, aj) in enumerate(DIFICULTADES.items()):
            elegido = i == self.opcion_menu
            color = (255, 255, 255) if elegido else (140, 140, 140)
            linea = f"{'> ' if elegido else '   '}{i + 1}. {nombre}   (linterna dura {aj['bateria']} s)"
            self.texto(pantalla, linea, self.fuente_media, color, (cx, cy - 15 + i * 40), centrado=True)
        self.texto(pantalla, "Arriba/abajo o 1-2-3 para elegir, ESPACIO para empezar",
                   self.fuente, (180, 180, 180), (cx, cy + 120), centrado=True)
        self.texto(pantalla, "F prende y apaga la linterna. Al espectro, mantenlo alumbrado.",
                   self.fuente, (140, 140, 160), (cx, cy + 150), centrado=True)

    def pantalla_final(self, pantalla, titulo, color, ayuda):
        velo = pygame.Surface(pantalla.get_size(), pygame.SRCALPHA)
        velo.fill((0, 0, 0, 170))
        pantalla.blit(velo, (0, 0))
        cx, cy = pantalla.get_width() // 2, pantalla.get_height() // 2
        fuente = self.fuente_grande if len(titulo) < 16 else self.fuente_media
        self.texto(pantalla, titulo, fuente, color, (cx, cy - 30), centrado=True)
        self.texto(pantalla, ayuda, self.fuente, (230, 230, 230), (cx, cy + 30), centrado=True)

    def texto(self, pantalla, cadena, fuente, color, pos, centrado=False):
        img = fuente.render(cadena, True, color)
        r = img.get_rect()
        if centrado:
            r.center = pos
        else:
            r.topleft = pos
        pantalla.blit(img, r)


# ------------------------------------------------------------------ ARRANQUE
def main():
    global TECLA
    carpeta = os.path.dirname(os.path.abspath(__file__))
    if len(sys.argv) > 1:
        niveles = sys.argv[1:]                       # tus propios laberintos
    else:
        niveles = [os.path.join(carpeta, n) for n in NIVELES]
    pygame.init()
    TECLA = cargar_controles()
    pygame.display.set_caption("Escape de la Fabrica")
    juego = Juego(niveles)
    pantalla = pygame.display.set_mode(juego.mundo.get_size())
    reloj = pygame.time.Clock()

    corriendo = True
    while corriendo:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                corriendo = False
            elif evento.type == pygame.KEYDOWN:
                if evento.key == TECLA["salir"]:
                    corriendo = False
                else:
                    juego.tecla(evento.key)

        # si el nivel nuevo es de otro tamano, cambiamos la ventana
        if pantalla.get_size() != juego.mundo.get_size():
            pantalla = pygame.display.set_mode(juego.mundo.get_size())

        juego.actualizar(pygame.key.get_pressed())
        juego.dibujar(pantalla)
        pygame.display.flip()
        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()
